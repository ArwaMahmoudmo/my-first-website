"""Makes assets/character/princess_face.png (the small round avatar) from princess.png.
Usage: python3 tools/make_face.py        (re-run after replacing princess.png)
Crops the top part of the picture, where the face is. Adjust TOP/LEFT/RIGHT if your picture is different."""
import os
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOP, LEFT, RIGHT = 0.24, 0.30, 0.80          # fractions of the picture: bottom edge, left edge, right edge
im = Image.open(os.path.join(ROOT, 'assets/character/princess.png')).convert('RGBA')
w, h = im.size
face = im.crop((int(w * LEFT), 0, int(w * RIGHT), int(h * TOP)))
face = face.resize((360, round(360 * face.height / face.width)), Image.LANCZOS)
face.save(os.path.join(ROOT, 'assets/character/princess_face.png'), optimize=True)
print('princess_face.png written', face.size)
