"""Builds ONE self-contained HTML file (all images + sounds embedded) for private testing on a phone.
Usage: python3 tools/build_single_file.py [output.html]   (run from the project folder)"""
import re, base64, os, json, sys
out_path = sys.argv[1] if len(sys.argv) > 1 else 'princess-lolo-phone-private.html'
h = open('index.html', encoding='utf8').read()
css = open('css/style.css', encoding='utf8').read().replace('../assets', 'assets')
mt = {'.svg': 'image/svg+xml', '.png': 'image/png', '.mp3': 'audio/mpeg'}
A = {}
for r, _, fs in os.walk('assets'):
    for f in fs:
        p = os.path.join(r, f).replace(os.sep, '/'); e = os.path.splitext(f)[1]
        if e in mt: A[p] = 'data:%s;base64,%s' % (mt[e], base64.b64encode(open(p, 'rb').read()).decode())
def sub(t): return re.sub(r'(?<=["\'(])(assets/[A-Za-z0-9_/.\-]+)(?=["\')])', lambda m: A.get(m.group(1), m.group(1)), t)
title = re.search(r'<title>.*?</title>', h).group(0)
body = re.search(r'<body>(.*?)</body>', h, re.S).group(1)
body = re.sub(r'<script src="[^"]*" defer></script>\n?', '', body)
body = re.sub(r'<noscript>.*?</noscript>', '', body, flags=re.S)
srcs = re.findall(r'<script src="((?:data|js)/[^"]+)"', h)
js = '\n;\n'.join(open(s, encoding='utf8').read() for s in srcs)
shim = '''(function(){var AS=%s;
function R(u){try{return (typeof u==='string'&&AS[u])||u}catch(e){return u}}
var NA=window.Audio;window.Audio=function(s){var a=new NA();if(s)a.src=R(s);return a};window.Audio.prototype=NA.prototype;
var d=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'src');
Object.defineProperty(HTMLMediaElement.prototype,'src',{get:d.get,set:function(v){d.set.call(this,R(v))},configurable:true});
var di=Object.getOwnPropertyDescriptor(HTMLImageElement.prototype,'src');
Object.defineProperty(HTMLImageElement.prototype,'src',{get:di.get,set:function(v){di.set.call(this,R(v))},configurable:true});
var sa=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){if(n==='src'&&(this instanceof HTMLImageElement||this instanceof HTMLMediaElement))v=R(v);return sa.call(this,n,v)};
})();''' % json.dumps(A)
fonts = '<link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@500;700;900&family=Baloo+Bhaijaan+2:wght@600;800&display=swap" rel="stylesheet">'
out = f'''<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<meta name="theme-color" content="#ffb3dc">{title}
{fonts}
<style>
{sub(css)}
</style></head><body>
{sub(body)}
<script>{shim}</script>
<script>
{js}
</script></body></html>'''
open(out_path, 'w', encoding='utf8').write(out)
print(len(out) // 1024, 'KB', len(A), 'assets ->', out_path)
