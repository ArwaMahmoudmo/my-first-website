"""Headless QA: python3 tools/test_game.py   (needs playwright + chrome)
Walks every screen and every game on phone / tablet / desktop sizes,
reports JS errors, horizontal overflow and screenshots to /tmp/claude-0/shots."""
import sys, os, time, threading, http.server, socketserver, functools, json
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = '/tmp/claude-0/shots'; os.makedirs(OUT, exist_ok=True)
Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=ROOT)
class Q(Handler.func):
    def log_message(self,*a): pass
Handler = functools.partial(Q, directory=ROOT)
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', 0), Handler); PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
errors = []; notes = []
def run(size, name, deep):
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
        ctx = b.new_context(viewport={'width': size[0], 'height': size[1]}, device_scale_factor=1, has_touch=size[0] < 800, is_mobile=size[0] < 800)
        pg = ctx.new_page()
        pg.on('pageerror', lambda e: errors.append(f'[{name}] pageerror: {e}'))
        pg.on('console', lambda m: errors.append(f'[{name}] console.{m.type}: {m.text}') if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
        pg.goto(f'http://127.0.0.1:{PORT}/index.html'); pg.wait_for_timeout(600)
        # instant speech so the test is fast (real audio paths are tested separately)
        pg.evaluate("LOLO.Audio.say=function(k,t){LOLO.Audio.lastVoice={key:k,text:t};return new Promise(function(r){setTimeout(function(){r(true)},60)})}")
        def C(sel, **k): pg.locator(sel).first.click(force=True, timeout=8000)
        def shot(n): pg.screenshot(path=f'{OUT}/{name}_{n}.png')
        def overflow(tag):
            w = pg.evaluate("(()=>{const r=Array.from(document.querySelectorAll('.screen:not(.leave) *')).map(e=>e.getBoundingClientRect()).filter(b=>b.width>0);return [document.documentElement.scrollWidth, window.innerWidth, Math.max(...r.map(b=>b.right)), Math.min(...r.map(b=>b.left))]})()")
            if w[0] > w[1] + 1 or w[2] > w[1] + 2 or w[3] < -2: notes.append(f'[{name}] horizontal overflow at {tag}: {w}')
            if pg.evaluate("document.body.innerText.includes('[object')"): notes.append(f'[{name}] "[object" text bug at {tag}')
        shot('01_splash'); C('.gate-btn'); pg.wait_for_timeout(1400); shot('02_home'); overflow('home')
        def go(sel, tag, wait=900):
            C(sel); pg.wait_for_timeout(wait); shot(tag); overflow(tag)
        def home(): C('#btnHome'); pg.wait_for_timeout(700)
        menu = pg.query_selector_all('.menu-btn')
        # letters kingdom -> letter lesson
        menu[1].click(); pg.wait_for_timeout(800); shot('03_letters'); overflow('letters')
        C('.letter-tile >> nth=1'); pg.wait_for_timeout(900); shot('04_letter_ba'); overflow('letter')
        if deep:
            for k in range(27):
                pg.evaluate("document.querySelectorAll('.nav-row .btn')[1].click()"); pg.wait_for_timeout(120)
            pg.wait_for_timeout(500)
            n = pg.evaluate("LOLO.Progress.get().lettersLearned.length"); notes.append(f'[{name}] letters learned after walk-through: {n}')
        home()
        # vowels
        C('.menu-btn >> nth=2'); pg.wait_for_timeout(800); shot('05_vowels'); overflow('vowels')
        C('.k-card >> nth=0'); pg.wait_for_timeout(1500); shot('06_fatha_demo'); overflow('fatha demo')
        C('.row-btns .btn.primary'); pg.wait_for_timeout(600); shot('07_fatha_grid'); overflow('fatha grid')
        C('.row-btns .btn.primary'); pg.wait_for_timeout(800); shot('08_fatha_quiz'); overflow('fatha quiz')
        def play_choice(rounds, tag):
            for r in range(rounds):
                pg.wait_for_selector('.opt', timeout=8000)
                tries = 0
                while tries < 4:
                    opts = pg.query_selector_all('.opt:not(.nope)')
                    if not opts: break
                    opts[0].click(force=True); pg.wait_for_timeout(150); tries += 1
                    if pg.query_selector('.opt.right'): break
                if r == 0: shot(tag)
                pg.wait_for_timeout(1700)
        play_choice(5, '09_quiz_round'); pg.wait_for_timeout(900); shot('10_vowel_done')
        notes.append(f"[{name}] vowelsDone={pg.evaluate('LOLO.Progress.get().vowelsDone')}")
        home()
        C('.menu-btn >> nth=3'); pg.wait_for_timeout(800); shot('11_longs'); overflow('longs')
        C('.k-card >> nth=0'); pg.wait_for_timeout(1000); shot('12_long_demo'); overflow('long demo')
        home()
        # games
        C('.menu-btn >> nth=4'); pg.wait_for_timeout(800); shot('13_games'); overflow('games')
        ids = ['find', 'listen', 'harakat', 'word', 'match', 'hunt', 'challenge', 'repeat']
        for gi, gid in enumerate(ids):
            if not deep and gid not in ('find', 'word', 'match', 'hunt', 'repeat'): continue
            C(f'.game-card >> nth={gi}'); pg.wait_for_timeout(700); overflow(gid + ' intro')
            C('.card.result .btn.primary'); pg.wait_for_timeout(900); shot(f'20_{gid}')
            overflow(gid)
            if gid in ('find', 'listen', 'harakat', 'word', 'challenge'):
                play_choice(6 if gid != 'challenge' else 10, f'21_{gid}_r1')
            elif gid == 'match':
                for rd in range(2):
                    pg.wait_for_selector('.m-card')
                    for k in range(4):
                        letters = pg.evaluate("Array.from(document.querySelectorAll('.match-row')[0].querySelectorAll('.m-card')).map(c=>[c.className,c.textContent.trim()])")
                        pics = pg.evaluate("Array.from(document.querySelectorAll('.match-row')[1].querySelectorAll('.m-card')).map(c=>(c.querySelector('img')||{}).src||'')")
                        idx = [i for i, (c, t) in enumerate(letters) if 'locked' not in c][0]
                        img = [l[1] for l in pg.evaluate("LOLO.LETTERS.map(l=>[l.ch,l.img])") if l[0] == letters[idx][1]][0].split('/')[-1]
                        pg.locator('.match-row').nth(0).locator('.m-card').nth(idx).click(force=True); pg.wait_for_timeout(150)
                        pi = [i for i, src in enumerate(pics) if src.endswith(img)][0]
                        pg.locator('.match-row').nth(1).locator('.m-card').nth(pi).click(force=True); pg.wait_for_timeout(450)
                        if os.environ.get('DBG'): print('match', rd, k, 'letter', letters[idx][1], 'idx', idx, 'pic', pi, 'state', pg.evaluate("Array.from(document.querySelectorAll('.m-card')).map(c=>c.className.replace('m-card','').trim()||'-').join(',')"))
                    pg.wait_for_timeout(900)
            elif gid == 'hunt':
                for rd in range(3):
                    pg.wait_for_selector('.flower')
                    target = pg.evaluate("document.querySelector('.q-prompt').textContent")
                    ch = target.split('«')[1][0]
                    fl = pg.query_selector_all('.flower')
                    fl[0].click(force=True) if ch not in fl[0].inner_text() else None
                    for f in fl:
                        if ch in f.inner_text(): f.click(force=True); pg.wait_for_timeout(120)
                    pg.wait_for_timeout(1200)
            elif gid == 'repeat':
                for rd in range(6):
                    pg.wait_for_selector('.repeat-card'); C('.btn.mint'); pg.wait_for_timeout(500)
                    pg.wait_for_timeout(300)
            pg.wait_for_timeout(1000); shot(f'22_{gid}_result')
            if not pg.query_selector('.card.result'): notes.append(f'[{name}] game {gid}: NO RESULT SCREEN')
            else: overflow(gid + ' result')
            C('#btnBack'); pg.wait_for_timeout(500)
        home()
        # map + level 1
        C('.menu-btn >> nth=0'); pg.wait_for_timeout(900); shot('30_map'); overflow('map')
        C('.m-node >> nth=0'); pg.wait_for_timeout(900); shot('31_level1'); overflow('level1')
        if deep:
            for k in range(7):
                C('.nav-row .btn.primary'); pg.wait_for_timeout(250)
            pg.wait_for_timeout(600); shot('32_level1_quiz')
            play_choice(5, '33_lvl_round'); pg.wait_for_timeout(1000); shot('34_level_complete')
            notes.append(f"[{name}] level1 done={pg.evaluate('LOLO.Progress.isLevelDone(\"L1\")')}  stars={pg.evaluate('LOLO.Progress.get().stars')}")
        home()
        C('.menu-btn >> nth=5'); pg.wait_for_timeout(800); shot('40_achievements'); overflow('achievements')
        pg.evaluate("LOLO.Nav.go('parent')"); pg.wait_for_timeout(800); shot('41_parent'); overflow('parent')

        if deep:
            # ---- princess image + animation states ----
            nat = pg.evaluate("document.getElementById('gFigure').naturalWidth")
            notes.append(f'[{name}] princess image natural width: {nat}')
            anims = pg.evaluate("""(()=>{const f=document.getElementById('gFigure'),out={};
              for(const st of ['idle','greet','walk','jump','clap','think','celebrate','encourage','smile']){LOLO.UI.Guide.setState(st);out[st]=getComputedStyle(f).animationName;}
              LOLO.UI.Guide.setState('idle');return out})()""")
            notes.append(f'[{name}] princess animation names: {anims}')
            # ---- all 28 word illustrations load ----
            imgs = pg.evaluate("""Promise.all(LOLO.LETTERS.map(l=>new Promise(r=>{const i=new Image();i.onload=()=>r(i.naturalWidth>0);i.onerror=()=>r(false);i.src=l.img})))""")
            notes.append(f'[{name}] illustrations loaded: {sum(imgs)}/28')
            # ---- long vowels full lesson ----
            home(); C('.menu-btn >> nth=3'); pg.wait_for_timeout(600); C('.k-card >> nth=1'); pg.wait_for_timeout(900); shot('50_long_u_step1'); overflow('long u step1')
            C('.row-btns .btn.primary'); pg.wait_for_timeout(500); shot('51_long_u_step2'); overflow('long u step2')
            C('.row-btns .btn.primary'); pg.wait_for_timeout(700); shot('52_long_u_quiz'); overflow('long u quiz')
            play_choice(5, '53_long_round'); pg.wait_for_timeout(1000); shot('54_long_done')
            notes.append(f"[{name}] longsDone={pg.evaluate('LOLO.Progress.get().longsDone')}")
            # ---- compare screen ----
            home(); C('.menu-btn >> nth=2'); pg.wait_for_timeout(600); C('.k-card >> nth=3'); pg.wait_for_timeout(900); shot('55_compare'); overflow('compare')
            # ---- level unlocking + final challenge ----
            notes.append(f"[{name}] unlock L2 after L1: {pg.evaluate('LOLO.Progress.isLevelUnlocked(1)')} ; L3 still locked: {not pg.evaluate('LOLO.Progress.isLevelUnlocked(2)')}")
            pg.evaluate("LOLO.Nav.go('level',{idx:10})"); pg.wait_for_timeout(800); shot('56_final_intro'); overflow('final intro')
            C('.card.result .btn.primary'); pg.wait_for_timeout(900)
            play_choice(10, '57_final_round'); pg.wait_for_timeout(1200); shot('58_final_done')
            notes.append(f"[{name}] L11 done={pg.evaluate('LOLO.Progress.isLevelDone(\"L11\")')} badges={pg.evaluate('LOLO.Progress.get().badges')}")
            # ---- all 28 letter lessons render without error: sample every letter's lesson ----
            bad = pg.evaluate("""(()=>{const bad=[];for(const l of LOLO.LETTERS){try{LOLO.Nav.go('letter',{ids:[l.id],start:0});}catch(e){bad.push(l.id)}}return bad})()""")
            pg.wait_for_timeout(600); notes.append(f'[{name}] letter lessons failing to open: {bad}')
            for lid in (1, 10, 16, 26): 
                pg.evaluate(f"LOLO.Nav.go('letter',{{ids:[{lid}],start:0}})"); pg.wait_for_timeout(700); shot(f'60_letter_{lid}')
        # persistence
        before = pg.evaluate("JSON.stringify(LOLO.Progress.get())")
        pg.reload(); pg.wait_for_timeout(600)
        after = pg.evaluate("JSON.stringify(LOLO.Progress.get())")
        notes.append(f'[{name}] progress persisted after reload: {before == after}')
        b.close()
import sys
SIZES = {'phone': ((360, 640), True), 'iphone': ((390, 844), False), 'tablet': ((768, 1024), False), 'desktop': ((1366, 768), False)}
for nm in (sys.argv[1:] or SIZES):
    run(SIZES[nm][0], nm, SIZES[nm][1])
srv.shutdown()
print('\n'.join(notes)); print('--- errors ---'); print('\n'.join(sorted(set(errors))) or 'none')
