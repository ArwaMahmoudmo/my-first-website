"""Draws the 28 vocabulary illustrations as SVG files in assets/images/words/.
Edit a drawing here and re-run:  python3 tools/make_illustrations.py
(Or simply replace any SVG/PNG file and point `img` in data/letters.js at it.)"""
import os, math
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets/images/words')
os.makedirs(OUT, exist_ok=True)
INK = '#4a2c5e'
def eye(x, y, r=7):
    return (f'<circle cx="{x}" cy="{y}" r="{r}" fill="#fff"/><circle cx="{x}" cy="{y}" r="{r*0.58:.1f}" fill="#3b2a4d"/>'
            f'<circle cx="{x-r*0.22:.1f}" cy="{y-r*0.28:.1f}" r="{r*0.24:.1f}" fill="#fff"/>')
def cheek(x, y, r=6): return f'<ellipse cx="{x}" cy="{y}" rx="{r}" ry="{r*0.7:.1f}" fill="#ff8fb5" opacity=".55"/>'
def smile(x, y, w=12): return f'<path d="M{x-w} {y} Q{x} {y+w*0.9:.0f} {x+w} {y}" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
def wrap(body, shadow=True):
    sh = '<ellipse cx="100" cy="186" rx="62" ry="8" fill="#000" opacity=".10"/>' if shadow else ''
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">{sh}{body}</svg>'
S = 'stroke-linejoin="round" stroke-linecap="round"'

D = {}
D['arnab'] = wrap(f'''
<ellipse cx="78" cy="48" rx="15" ry="42" fill="#fff" stroke="#d9c7e8" stroke-width="3" transform="rotate(-8 78 48)"/><ellipse cx="78" cy="52" rx="7" ry="30" fill="#ffc2dc" transform="rotate(-8 78 52)"/>
<ellipse cx="124" cy="48" rx="15" ry="42" fill="#fff" stroke="#d9c7e8" stroke-width="3" transform="rotate(8 124 48)"/><ellipse cx="124" cy="52" rx="7" ry="30" fill="#ffc2dc" transform="rotate(8 124 52)"/>
<ellipse cx="100" cy="152" rx="48" ry="36" fill="#fff" stroke="#d9c7e8" stroke-width="3"/>
<circle cx="100" cy="106" r="40" fill="#fff" stroke="#d9c7e8" stroke-width="3"/>
{eye(85,100)}{eye(115,100)}<ellipse cx="100" cy="114" rx="6" ry="4.5" fill="#ff7aa8"/>{smile(100,119,9)}{cheek(74,114)}{cheek(126,114)}
<polygon points="128,150 166,156 138,184" fill="#ff9a2e" stroke="#e57a00" stroke-width="2" {S}/><path d="M160 156 l8 -14 M160 156 l14 -6 M160 156 l4 -16" stroke="#3fb15a" stroke-width="5" {S}/>''')
D['batta'] = wrap(f'''
<polygon points="40,128 22,114 46,108" fill="#ffd23f"/>
<ellipse cx="92" cy="128" rx="56" ry="38" fill="#ffd23f" stroke="#f0b400" stroke-width="3"/>
<path d="M62 122 Q86 156 118 118 Q96 112 62 122Z" fill="#ffbf1f"/>
<circle cx="132" cy="80" r="31" fill="#ffd23f" stroke="#f0b400" stroke-width="3"/>
<ellipse cx="164" cy="88" rx="19" ry="9" fill="#ff8a2a" stroke="#e66e00" stroke-width="2"/>{eye(138,72,7)}{cheek(130,92)}
<ellipse cx="100" cy="172" rx="76" ry="13" fill="#7cc8ff" opacity=".7"/><path d="M40 172 q10 -6 20 0 t20 0 t20 0 t20 0" stroke="#fff" stroke-width="3" fill="none" opacity=".8"/>''')
D['tuffaha'] = wrap('''
<rect x="96" y="28" width="8" height="30" rx="4" fill="#8a5a2b"/>
<path d="M104 40 C 120 18 150 22 156 30 C 144 50 118 52 104 40Z" fill="#4cc260" stroke="#2f9a45" stroke-width="2"/>
<path d="M100 62 C 70 40 28 60 33 112 C 38 162 78 182 100 170 C 122 182 162 162 167 112 C 172 60 130 40 100 62Z" fill="#ee3b3b" stroke="#c42222" stroke-width="3"/>
<ellipse cx="68" cy="94" rx="11" ry="20" fill="#fff" opacity=".45" transform="rotate(18 68 94)"/>''')
D['thaalab'] = wrap(f'''
<path d="M150 150 C 190 140 198 96 176 78 C 176 112 158 126 130 134Z" fill="#ff8a3d" stroke="#e5651a" stroke-width="3"/><path d="M176 78 C 183 92 182 104 176 112 C 170 100 172 90 176 78Z" fill="#fff"/>
<ellipse cx="100" cy="160" rx="44" ry="28" fill="#ff8a3d" stroke="#e5651a" stroke-width="3"/>
<polygon points="48,34 82,70 52,96" fill="#ff8a3d" stroke="#e5651a" stroke-width="3" {S}/><polygon points="152,34 118,70 148,96" fill="#ff8a3d" stroke="#e5651a" stroke-width="3" {S}/>
<polygon points="54,50 72,70 56,82" fill="#3b2a4d"/><polygon points="146,50 128,70 144,82" fill="#3b2a4d"/>
<path d="M44 92 Q100 58 156 92 L150 124 Q100 172 50 124Z" fill="#ff8a3d" stroke="#e5651a" stroke-width="3" {S}/>
<path d="M50 118 Q74 112 100 140 Q126 112 150 118 Q100 176 50 118Z" fill="#fff"/>
{eye(78,104,7)}{eye(122,104,7)}<ellipse cx="100" cy="138" rx="8" ry="6" fill="#3b2a4d"/>{cheek(64,124)}{cheek(136,124)}''')
D['jamal'] = wrap(f'''
<rect x="62" y="140" width="12" height="40" rx="5" fill="#c98a4b"/><rect x="88" y="142" width="12" height="38" rx="5" fill="#b9793b"/><rect x="118" y="142" width="12" height="38" rx="5" fill="#c98a4b"/><rect x="142" y="140" width="12" height="40" rx="5" fill="#b9793b"/>
<ellipse cx="100" cy="128" rx="62" ry="30" fill="#e0a566" stroke="#b9793b" stroke-width="3"/>
<ellipse cx="82" cy="94" rx="22" ry="26" fill="#e0a566" stroke="#b9793b" stroke-width="3"/><ellipse cx="120" cy="96" rx="22" ry="24" fill="#e0a566" stroke="#b9793b" stroke-width="3"/>
<path d="M150 112 C 160 80 160 56 168 44 L 188 52 C 180 66 180 90 172 126Z" fill="#e0a566" stroke="#b9793b" stroke-width="3" {S}/>
<ellipse cx="180" cy="44" rx="20" ry="14" fill="#e0a566" stroke="#b9793b" stroke-width="3"/><ellipse cx="192" cy="46" rx="7" ry="9" fill="#d09050"/>{eye(176,40,5)}
<path d="M38 124 q-12 14 -6 40" stroke="#b9793b" stroke-width="6" fill="none" {S}/><rect x="60" y="116" width="76" height="14" rx="7" fill="#ff6fae"/>''')
D['hisan'] = wrap(f'''
<rect x="56" y="140" width="12" height="40" rx="5" fill="#9a5a2e"/><rect x="80" y="142" width="12" height="38" rx="5" fill="#7a431f"/><rect x="116" y="142" width="12" height="38" rx="5" fill="#9a5a2e"/><rect x="138" y="140" width="12" height="40" rx="5" fill="#7a431f"/>
<path d="M44 118 C 18 124 18 150 30 168 C 40 150 42 134 50 126Z" fill="#3b2418"/>
<ellipse cx="96" cy="124" rx="56" ry="32" fill="#b9733a" stroke="#8a5025" stroke-width="3"/>
<path d="M126 108 L 142 52 L 176 62 L 164 112Z" fill="#b9733a" stroke="#8a5025" stroke-width="3" {S}/>
<ellipse cx="166" cy="56" rx="26" ry="17" fill="#b9733a" stroke="#8a5025" stroke-width="3" transform="rotate(18 166 56)"/><ellipse cx="184" cy="64" rx="7" ry="10" fill="#8a5025"/>
<polygon points="140,40 150,22 158,44" fill="#b9733a" stroke="#8a5025" stroke-width="3" {S}/>{eye(164,50,5.5)}
<path d="M126 108 C 118 80 128 56 142 40 C 150 60 142 84 144 112Z" fill="#3b2418"/>''')
D['kharouf'] = wrap(f'''
<rect x="68" y="140" width="11" height="40" rx="5" fill="#5a4a63"/><rect x="92" y="142" width="11" height="38" rx="5" fill="#5a4a63"/><rect x="118" y="142" width="11" height="38" rx="5" fill="#5a4a63"/><rect x="138" y="140" width="11" height="40" rx="5" fill="#5a4a63"/>
<g fill="#fff" stroke="#d9c7e8" stroke-width="3"><circle cx="62" cy="116" r="26"/><circle cx="92" cy="98" r="30"/><circle cx="128" cy="104" r="30"/><circle cx="152" cy="128" r="22"/><circle cx="84" cy="136" r="26"/><circle cx="120" cy="140" r="26"/></g>
<ellipse cx="46" cy="104" rx="11" ry="7" fill="#5a4a63" transform="rotate(-25 46 104)"/>
<ellipse cx="36" cy="112" rx="26" ry="30" fill="#5a4a63" transform="rotate(8 36 112)"/><ellipse cx="14" cy="96" rx="14" ry="7" fill="#5a4a63" transform="rotate(-30 14 96)"/>
{eye(32,106,6)}<ellipse cx="22" cy="126" rx="5" ry="3.5" fill="#ff9ec4"/>''')
D['dubb'] = wrap(f'''
<circle cx="56" cy="52" r="19" fill="#9a6a3d" stroke="#7a4f27" stroke-width="3"/><circle cx="56" cy="52" r="9" fill="#d9a56e"/>
<circle cx="144" cy="52" r="19" fill="#9a6a3d" stroke="#7a4f27" stroke-width="3"/><circle cx="144" cy="52" r="9" fill="#d9a56e"/>
<ellipse cx="100" cy="158" rx="46" ry="30" fill="#9a6a3d" stroke="#7a4f27" stroke-width="3"/><ellipse cx="100" cy="162" rx="26" ry="20" fill="#d9a56e"/>
<circle cx="100" cy="98" r="52" fill="#9a6a3d" stroke="#7a4f27" stroke-width="3"/>
<ellipse cx="100" cy="116" rx="26" ry="20" fill="#e8c08a"/><ellipse cx="100" cy="106" rx="10" ry="7" fill="#3b2a4d"/>{smile(100,122,9)}
{eye(78,88,7)}{eye(122,88,7)}{cheek(68,108)}{cheek(132,108)}''')
D['dhura'] = wrap('''
<path d="M100 178 C 60 160 42 120 46 92 C 62 110 88 130 100 178Z" fill="#4cc260" stroke="#2f9a45" stroke-width="3"/>
<path d="M100 178 C 140 160 158 120 154 92 C 138 110 112 130 100 178Z" fill="#43b856" stroke="#2f9a45" stroke-width="3"/>
<path d="M100 178 C 52 150 56 70 100 26 C 144 70 148 150 100 178Z" fill="#ffd93d" stroke="#e5b500" stroke-width="3"/>
<g stroke="#e5b500" stroke-width="2.5" fill="none"><path d="M70 60 Q100 70 130 60 M62 84 Q100 96 138 84 M62 108 Q100 120 138 108 M70 132 Q100 142 130 132 M100 28 V170 M82 40 V160 M118 40 V160"/></g>
<path d="M100 26 C 90 10 88 -2 96 -6 C 104 4 104 14 100 26Z" fill="#8bd45e" transform="translate(0,12)"/>''')
D['risha'] = wrap('''
<defs><linearGradient id="f" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5fd6e6"/><stop offset="1" stop-color="#7b6cf0"/></linearGradient></defs>
<path d="M150 22 C 188 74 150 150 66 168 C 52 120 82 52 150 22Z" fill="url(#f)" stroke="#5a4ec8" stroke-width="3" {S}/>
<path d="M156 28 L 40 190" stroke="#fff" stroke-width="5" {S}/>
<g stroke="#fff" stroke-width="2.5" opacity=".7" {S}><path d="M130 52 L 108 62 M116 76 L 92 86 M100 100 L 78 108 M138 70 L 126 98 M118 100 L 106 126 M98 122 L 90 142"/></g>'''.replace('{S}','stroke-linejoin="round" stroke-linecap="round"'))
D['zarafa'] = wrap(f'''
<rect x="76" y="136" width="12" height="44" rx="5" fill="#f2b84a"/><rect x="112" y="136" width="12" height="44" rx="5" fill="#f2b84a"/>
<ellipse cx="100" cy="150" rx="40" ry="24" fill="#ffd25c" stroke="#e09e22" stroke-width="3"/>
<path d="M84 150 L 90 56 L 114 56 L 116 150Z" fill="#ffd25c" stroke="#e09e22" stroke-width="3" {S}/>
<ellipse cx="102" cy="42" rx="30" ry="22" fill="#ffd25c" stroke="#e09e22" stroke-width="3"/><ellipse cx="124" cy="50" rx="15" ry="12" fill="#ffe7a3"/>
<rect x="86" y="14" width="5" height="16" rx="2.5" fill="#b5651d"/><circle cx="88.5" cy="12" r="5" fill="#b5651d"/><rect x="108" y="14" width="5" height="16" rx="2.5" fill="#b5651d"/><circle cx="110.5" cy="12" r="5" fill="#b5651d"/>
<ellipse cx="72" cy="38" rx="9" ry="6" fill="#ffd25c" stroke="#e09e22" stroke-width="2" transform="rotate(-24 72 38)"/>
{eye(98,40,5.5)}<circle cx="126" cy="50" r="2" fill="#b5651d"/><circle cx="132" cy="48" r="2" fill="#b5651d"/>
<g fill="#c9772b"><circle cx="98" cy="76" r="7"/><circle cx="106" cy="100" r="8"/><circle cx="96" cy="124" r="7"/><circle cx="76" cy="150" r="7"/><circle cx="114" cy="152" r="8"/><circle cx="100" cy="158" r="6"/></g>''')
D['samaka'] = wrap(f'''
<path d="M146 100 L 186 64 L 186 136Z" fill="#ff8a3d" stroke="#e5651a" stroke-width="3" {S}/>
<path d="M90 64 Q104 36 128 62Z" fill="#ff9d57" stroke="#e5651a" stroke-width="3" {S}/><path d="M92 138 Q106 164 124 140Z" fill="#ff9d57" stroke="#e5651a" stroke-width="3" {S}/>
<ellipse cx="96" cy="100" rx="58" ry="40" fill="#ffa24d" stroke="#e5651a" stroke-width="3"/>
<g fill="none" stroke="#ff7a1f" stroke-width="3" opacity=".7"><path d="M92 78 q10 10 0 22 M112 78 q10 10 0 22 M132 84 q8 8 0 16"/></g>
<path d="M44 106 Q60 114 70 100" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>{eye(66,92,8)}{cheek(60,112,5)}
<circle cx="30" cy="62" r="8" fill="#bfe8ff" stroke="#7cc8ff" stroke-width="2"/><circle cx="46" cy="40" r="5" fill="#bfe8ff" stroke="#7cc8ff" stroke-width="2"/><circle cx="26" cy="36" r="4" fill="#bfe8ff" stroke="#7cc8ff" stroke-width="2"/>''')
rays = ''.join(f'<rect x="96" y="14" width="8" height="26" rx="4" fill="#ffb800" transform="rotate({a} 100 100)"/>' for a in range(0, 360, 30))
D['shams'] = wrap(rays + f'''<circle cx="100" cy="100" r="50" fill="#ffd93d" stroke="#ffb800" stroke-width="4"/>{eye(82,94,7)}{eye(118,94,7)}{smile(100,110,14)}{cheek(70,112,7)}{cheek(130,112,7)}''', shadow=False)
D['sarokh'] = wrap('''
<path d="M72 150 L 44 176 L 52 120 Z" fill="#ff5a6e" stroke="#d63a50" stroke-width="3" stroke-linejoin="round"/><path d="M128 150 L 156 176 L 148 120 Z" fill="#ff5a6e" stroke="#d63a50" stroke-width="3" stroke-linejoin="round"/>
<path d="M100 16 C 140 52 140 112 128 154 L 72 154 C 60 112 60 52 100 16Z" fill="#fff" stroke="#c9b5e0" stroke-width="3"/>
<path d="M100 16 C 118 34 128 52 132 68 L 68 68 C 72 52 82 34 100 16Z" fill="#ff5a6e" stroke="#d63a50" stroke-width="3" stroke-linejoin="round"/>
<circle cx="100" cy="96" r="17" fill="#8fd4ff" stroke="#6a8fe0" stroke-width="5"/><circle cx="94" cy="90" r="5" fill="#fff" opacity=".8"/>
<path d="M82 154 L 100 190 L 118 154Z" fill="#ffb800"/><path d="M90 154 L 100 178 L 110 154Z" fill="#ff7a1f"/>''')
D['difda'] = wrap(f'''
<ellipse cx="100" cy="146" rx="62" ry="34" fill="#5fcf6a" stroke="#38a244" stroke-width="3"/><ellipse cx="100" cy="158" rx="40" ry="18" fill="#c8f5a0"/>
<ellipse cx="100" cy="102" rx="58" ry="40" fill="#5fcf6a" stroke="#38a244" stroke-width="3"/>
<circle cx="64" cy="66" r="24" fill="#5fcf6a" stroke="#38a244" stroke-width="3"/><circle cx="136" cy="66" r="24" fill="#5fcf6a" stroke="#38a244" stroke-width="3"/>
{eye(64,64,15)}{eye(136,64,15)}
<path d="M54 112 Q100 150 146 112" fill="#d63a50" stroke="#38a244" stroke-width="3" {S}/><path d="M70 124 Q100 140 130 124" fill="#ff8fa0"/>
<circle cx="90" cy="92" r="3" fill="#38a244"/><circle cx="110" cy="92" r="3" fill="#38a244"/>{cheek(58,100,7)}{cheek(142,100,7)}''')
D['taira'] = wrap('''
<path d="M20 96 L 12 62 L 40 62 L 58 92Z" fill="#6aa8ff" stroke="#3f7ee0" stroke-width="3" stroke-linejoin="round"/>
<path d="M112 108 L 82 170 L 108 170 L 150 108Z" fill="#6aa8ff" stroke="#3f7ee0" stroke-width="3" stroke-linejoin="round"/>
<path d="M18 104 C 18 84 60 82 130 84 C 168 86 190 98 190 106 C 190 116 168 126 130 126 L 40 126 C 24 126 18 118 18 104Z" fill="#fff" stroke="#c9b5e0" stroke-width="3"/>
<path d="M22 112 L 188 112" stroke="#6aa8ff" stroke-width="5"/>
<g fill="#8fd4ff" stroke="#6aa8ff" stroke-width="2"><circle cx="60" cy="100" r="6"/><circle cx="82" cy="100" r="6"/><circle cx="104" cy="100" r="6"/><path d="M142 90 q16 2 26 14 l-26 0z"/></g>
<path d="M110 96 L 88 52 L 114 52 L 138 96Z" fill="#6aa8ff" stroke="#3f7ee0" stroke-width="3" stroke-linejoin="round" opacity="0"/>''', shadow=False)
D['zarf'] = wrap('''
<rect x="26" y="54" width="148" height="100" rx="10" fill="#fff" stroke="#c9b5e0" stroke-width="3"/>
<path d="M26 150 L 82 100 M174 150 L 118 100" stroke="#e3d6f1" stroke-width="3" fill="none" stroke-linecap="round"/>
<path d="M26 62 Q100 128 174 62 L 174 56 Q 174 54 168 54 L 32 54 Q 26 54 26 60Z" fill="#ffe3f0" stroke="#c9b5e0" stroke-width="3" stroke-linejoin="round"/>
<path d="M100 120 C 84 106 82 92 92 88 C 98 86 100 92 100 92 C 100 92 102 86 108 88 C 118 92 116 106 100 120Z" fill="#ff5fa2"/>''')
D['inab'] = wrap('''
<rect x="97" y="22" width="7" height="26" rx="3" fill="#8a5a2b"/><path d="M104 34 C 122 14 152 18 158 28 C 146 48 120 50 104 34Z" fill="#4cc260" stroke="#2f9a45" stroke-width="2"/>
<g fill="#8e5bd6" stroke="#6a3db8" stroke-width="2.5"><circle cx="62" cy="68" r="16"/><circle cx="92" cy="66" r="16"/><circle cx="122" cy="66" r="16"/><circle cx="150" cy="70" r="16"/><circle cx="76" cy="96" r="16"/><circle cx="106" cy="94" r="16"/><circle cx="136" cy="96" r="16"/><circle cx="90" cy="124" r="16"/><circle cx="122" cy="124" r="16"/><circle cx="106" cy="152" r="16"/></g>
<g fill="#fff" opacity=".6"><circle cx="56" cy="62" r="4"/><circle cx="86" cy="60" r="4"/><circle cx="116" cy="60" r="4"/><circle cx="144" cy="64" r="4"/><circle cx="70" cy="90" r="4"/><circle cx="100" cy="88" r="4"/><circle cx="130" cy="90" r="4"/><circle cx="84" cy="118" r="4"/><circle cx="116" cy="118" r="4"/><circle cx="100" cy="146" r="4"/></g>''')
D['ghayma'] = wrap(f'''
<g fill="#fff" stroke="#bcd8f5" stroke-width="3"><circle cx="64" cy="94" r="30"/><circle cx="104" cy="70" r="40"/><circle cx="146" cy="96" r="28"/><rect x="44" y="94" width="122" height="30" rx="15" stroke="none"/><ellipse cx="105" cy="108" rx="62" ry="26" stroke="none"/></g>
<ellipse cx="105" cy="118" rx="62" ry="12" fill="#fff"/>
{eye(86,92,7)}{eye(124,92,7)}{smile(105,108,11)}{cheek(74,106)}{cheek(136,106)}
<g fill="#6fb8ff"><path d="M70 146 q-7 14 0 20 q7 -6 0 -20Z"/><path d="M104 150 q-7 14 0 20 q7 -6 0 -20Z"/><path d="M138 146 q-7 14 0 20 q7 -6 0 -20Z"/></g>''', shadow=False)
D['farasha'] = wrap('''
<path d="M100 98 C 70 30 22 34 26 84 C 28 112 70 116 100 100Z" fill="#ff7eb6" stroke="#e0458a" stroke-width="3"/><path d="M100 100 C 76 112 52 140 68 160 C 86 172 98 134 100 100Z" fill="#ffb3d6" stroke="#e0458a" stroke-width="3"/>
<path d="M100 98 C 130 30 178 34 174 84 C 172 112 130 116 100 100Z" fill="#8f7bff" stroke="#6a52e0" stroke-width="3"/><path d="M100 100 C 124 112 148 140 132 160 C 114 172 102 134 100 100Z" fill="#c1b6ff" stroke="#6a52e0" stroke-width="3"/>
<circle cx="56" cy="76" r="11" fill="#fff" opacity=".85"/><circle cx="144" cy="76" r="11" fill="#fff" opacity=".85"/><circle cx="72" cy="136" r="6" fill="#fff" opacity=".85"/><circle cx="128" cy="136" r="6" fill="#fff" opacity=".85"/>
<rect x="93" y="64" width="14" height="86" rx="7" fill="#5a3a7a"/><circle cx="100" cy="62" r="11" fill="#5a3a7a"/>
<path d="M96 54 Q86 30 70 24 M104 54 Q114 30 130 24" stroke="#5a3a7a" stroke-width="3.5" fill="none" stroke-linecap="round"/><circle cx="70" cy="24" r="4" fill="#5a3a7a"/><circle cx="130" cy="24" r="4" fill="#5a3a7a"/>''')
D['qamar'] = wrap(f'''
<path d="M122 22 A 78 78 0 1 0 178 118 A 62 62 0 1 1 122 22Z" fill="#ffd93d" stroke="#ffb800" stroke-width="4" stroke-linejoin="round"/>
{eye(70,104,6)}{smile(78,128,9)}{cheek(60,120,6)}
<path d="M170 44 l4 10 10 1 -8 7 3 10 -9 -6 -9 6 3 -10 -8 -7 10 -1z" fill="#fff4a8" stroke="#ffb800" stroke-width="2" stroke-linejoin="round"/>''', shadow=False)
D['kalb'] = wrap(f'''
<ellipse cx="100" cy="162" rx="44" ry="26" fill="#d9a066" stroke="#a8713a" stroke-width="3"/>
<ellipse cx="46" cy="98" rx="20" ry="38" fill="#7a4a24" stroke="#5a3418" stroke-width="3" transform="rotate(12 46 98)"/><ellipse cx="154" cy="98" rx="20" ry="38" fill="#7a4a24" stroke="#5a3418" stroke-width="3" transform="rotate(-12 154 98)"/>
<circle cx="100" cy="92" r="48" fill="#e8b27a" stroke="#a8713a" stroke-width="3"/><circle cx="76" cy="76" r="14" fill="#c98a4b" opacity=".6"/>
<ellipse cx="100" cy="114" rx="28" ry="22" fill="#fff0dc"/><ellipse cx="100" cy="102" rx="11" ry="8" fill="#3b2a4d"/>
<path d="M100 110 V 122 M86 124 Q100 136 114 124" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round"/><path d="M94 128 q6 20 12 0Z" fill="#ff7aa8"/>
{eye(80,80,7)}{eye(120,80,7)}''')
D['laymoun'] = wrap('''
<path d="M104 40 C 124 18 154 22 158 34 C 144 54 118 56 104 40Z" fill="#4cc260" stroke="#2f9a45" stroke-width="2"/>
<path d="M30 104 L 22 100 Q 20 96 26 96 L 38 98 C 50 62 80 48 104 48 C 134 48 164 70 170 98 L 180 96 Q 186 96 184 102 L 172 106 C 166 142 136 162 104 162 C 74 162 42 144 36 108Z" fill="#ffe23d" stroke="#e5b500" stroke-width="3" stroke-linejoin="round"/>
<ellipse cx="76" cy="84" rx="12" ry="22" fill="#fff" opacity=".45" transform="rotate(30 76 84)"/>
<g fill="#e5b500" opacity=".55"><circle cx="110" cy="100" r="2.5"/><circle cx="130" cy="120" r="2.5"/><circle cx="96" cy="130" r="2.5"/><circle cx="140" cy="92" r="2.5"/></g>''')
D['mawza'] = wrap('''
<path d="M70 150 C 36 100 60 50 110 38 C 128 34 150 32 160 40 C 166 46 160 52 152 54 C 118 66 108 100 118 128 C 124 146 100 168 70 150Z" fill="#ffe23d" stroke="#e5b500" stroke-width="3" stroke-linejoin="round"/>
<path d="M82 152 C 52 106 68 62 108 50" fill="none" stroke="#ffc800" stroke-width="3" opacity=".7" stroke-linecap="round"/>
<path d="M156 36 L 168 28 L 176 38 L 162 48Z" fill="#8a5a2b" stroke="#6a421d" stroke-width="2" stroke-linejoin="round"/><path d="M62 144 q12 18 28 10 q-8 -10 -28 -10Z" fill="#8a5a2b"/>
<path d="M98 66 C 84 90 82 116 92 138" fill="none" stroke="#fff" stroke-width="5" opacity=".5" stroke-linecap="round"/>''')
D['najma'] = wrap(f'''
<path d="M100 14 l24 52 56 6 -42 38 12 56 -50 -29 -50 29 12 -56 -42 -38 56 -6z" fill="#ffd93d" stroke="#ffb800" stroke-width="4" stroke-linejoin="round" transform="translate(0,4)"/>
{eye(84,96,7)}{eye(116,96,7)}{smile(100,112,11)}{cheek(74,110,6)}{cheek(126,110,6)}''', shadow=False)
D['hadiya'] = wrap('''
<rect x="42" y="92" width="116" height="88" rx="8" fill="#ff7eb6" stroke="#e0458a" stroke-width="3"/>
<rect x="34" y="68" width="132" height="32" rx="8" fill="#ff9ccb" stroke="#e0458a" stroke-width="3"/>
<rect x="90" y="68" width="20" height="112" fill="#ffd93d" stroke="#e5b500" stroke-width="2"/>
<ellipse cx="76" cy="52" rx="26" ry="16" fill="#ffd93d" stroke="#e5b500" stroke-width="3" transform="rotate(-24 76 52)"/><ellipse cx="124" cy="52" rx="26" ry="16" fill="#ffd93d" stroke="#e5b500" stroke-width="3" transform="rotate(24 124 52)"/>
<circle cx="100" cy="62" r="11" fill="#ffc800" stroke="#e5b500" stroke-width="3"/>
<g fill="#fff" opacity=".6"><circle cx="62" cy="120" r="4"/><circle cx="140" cy="140" r="4"/><circle cx="66" cy="156" r="4"/><circle cx="138" cy="112" r="4"/></g>''')
D['warda'] = wrap('''
<rect x="96" y="108" width="8" height="76" rx="4" fill="#3fb15a"/>
<path d="M100 150 C 70 150 58 128 58 118 C 82 120 98 132 100 150Z" fill="#4cc260" stroke="#2f9a45" stroke-width="2"/><path d="M100 168 C 130 168 144 148 144 138 C 120 138 102 150 100 168Z" fill="#4cc260" stroke="#2f9a45" stroke-width="2"/>
<path d="M100 28 C 128 18 156 40 150 70 C 160 96 130 118 100 112 C 70 118 40 96 50 70 C 44 40 72 18 100 28Z" fill="#ee3b5b" stroke="#c42244" stroke-width="3"/>
<g fill="none" stroke="#c42244" stroke-width="3.5" stroke-linecap="round"><path d="M100 50 C 120 46 128 68 108 76 C 92 80 84 64 96 58 C 104 54 110 62 104 66"/><path d="M70 62 C 78 90 96 98 118 94"/><path d="M130 62 C 126 86 114 96 100 98"/></g>
<ellipse cx="72" cy="48" rx="8" ry="14" fill="#fff" opacity=".4" transform="rotate(30 72 48)"/>''')
D['yad'] = wrap('''
<g fill="#ffcf9e" stroke="#e0a066" stroke-width="3" stroke-linejoin="round">
<rect x="48" y="62" width="22" height="64" rx="11" transform="rotate(-8 59 94)"/><rect x="74" y="34" width="22" height="86" rx="11" transform="rotate(-2 85 77)"/><rect x="100" y="28" width="22" height="92" rx="11" transform="rotate(3 111 74)"/><rect x="126" y="40" width="22" height="82" rx="11" transform="rotate(9 137 81)"/>
<rect x="150" y="104" width="20" height="62" rx="10" transform="rotate(-52 160 135)"/>
<path d="M50 112 H 150 V 142 C 150 170 128 186 100 186 C 72 186 50 170 50 142Z"/></g>
<path d="M62 150 Q100 170 138 150" fill="none" stroke="#e0a066" stroke-width="3" stroke-linecap="round" opacity=".7"/>''', shadow=False)

if __name__ == '__main__':
    import re
    FIT = {'jamal': 'translate(8 14) scale(.86)', 'taira': 'translate(16 18) scale(.84)'}   # keep these inside the frame
    for k, v in D.items():
        v = v.replace('{S}', 'stroke-linejoin="round" stroke-linecap="round"')
        if k in FIT: v = re.sub(r'(<svg[^>]*>)(.*)(</svg>)', lambda m: m.group(1) + '<g transform="' + FIT[k] + '">' + m.group(2) + '</g>' + m.group(3), v, flags=re.S)
        open(os.path.join(OUT, k + '.svg'), 'w', encoding='utf-8').write(v)
    print(len(D), 'illustrations written to', OUT)
