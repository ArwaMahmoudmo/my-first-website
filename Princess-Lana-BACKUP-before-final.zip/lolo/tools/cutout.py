import cv2, numpy as np
from PIL import Image
src = cv2.imread('assets/character/original.jpeg')
S = 1280
small = cv2.resize(src, (S, S), interpolation=cv2.INTER_AREA)
mask = np.zeros((S, S), np.uint8)
rect = (235, 35, 710, 1215)
# prior: inside rect probable fg, outside bg
mask[:] = cv2.GC_BGD
x, y, w, h = rect
mask[y:y+h, x:x+w] = cv2.GC_PR_FGD
# strong hints: pink dungarees / body core is definitely foreground
mask[560:760, 480:640] = cv2.GC_FGD    # pink overalls
mask[240:330, 500:620] = cv2.GC_FGD    # face
mask[900:1000, 330:380] = cv2.GC_FGD   # leg
# definite background seeds (sea / ground / fog) in 1280-space
mask[470:850, 0:440] = cv2.GC_BGD
mask[430:900, 755:1280] = cv2.GC_BGD
mask[0:1280, 940:1280] = cv2.GC_BGD
mask[870:1280, 640:1280] = cv2.GC_BGD
mask[870:1280, 0:250] = cv2.GC_BGD
mask[1215:1280, :] = cv2.GC_BGD
mask[0:45, :] = cv2.GC_BGD
bg = np.zeros((1, 65), np.float64); fg = np.zeros((1, 65), np.float64)
cv2.grabCut(small, mask, rect, bg, fg, 8, cv2.GC_INIT_WITH_MASK)
m = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)
m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
if n > 1:
    k = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA]); m = np.where(lab == k, 255, 0).astype(np.uint8)
m = cv2.GaussianBlur(m, (5, 5), 0)
full = cv2.resize(m, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_CUBIC)
rgba = cv2.cvtColor(src, cv2.COLOR_BGR2BGRA); rgba[:, :, 3] = full
ys, xs = np.where(full > 20)
x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
pad = 20
rgba = rgba[max(0, y0-pad):y1+pad, max(0, x0-pad):x1+pad]
cv2.imwrite('assets/character/_cut_full.png', rgba)
im = Image.open('assets/character/_cut_full.png'); print(im.size)
# preview on pink
bgim = Image.new('RGBA', im.size, (255, 200, 230, 255)); bgim.alpha_composite(im)
bgim.convert('RGB').resize((im.width//3, im.height//3)).save('/tmp/claude-0/preview_cut.png')

# ---- cleanup pass (preview-space coords x3) ----
import cv2, numpy as np
a = cv2.imread('assets/character/_cut_full.png', cv2.IMREAD_UNCHANGED)
H, W = a.shape[:2]
def poly(pts):
    m = np.zeros((H, W), np.uint8)
    cv2.fillPoly(m, [np.array([(x*3, y*3) for x, y in pts], np.int32)], 255); return m > 0
kill = poly([(40,540),(165,540),(95,655),(40,655)]) | poly([(198,540),(222,540),(222,600),(198,600)])
kill |= poly([(158,108),(188,108),(188,182),(158,182)])
b, g, r = a[:,:,0].astype(int), a[:,:,1].astype(int), a[:,:,2].astype(int)
bluish = (b >= r - 8)
zone = poly([(138,318),(178,318),(178,448),(138,448)]) | poly([(305,495),(330,495),(330,540),(305,540)])
kill |= zone & bluish
a[:,:,3][kill] = 0
# keep biggest component again, soften edge
al = a[:,:,3]
n, lab, st, _ = cv2.connectedComponentsWithStats((al > 30).astype(np.uint8))
k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA]); al = np.where(lab == k, al, 0).astype(np.uint8)
al = cv2.erode(al, np.ones((3,3), np.uint8)); al = cv2.GaussianBlur(al, (3,3), 0)
a[:,:,3] = al
ys, xs = np.where(al > 20); a = a[ys.min():ys.max()+1, xs.min():xs.max()+1]
cv2.imwrite('assets/character/_cut2.png', a)
im = Image.open('assets/character/_cut2.png').convert('RGBA')
h = 1400; w = round(im.width * h / im.height)
big = im.resize((w, h), Image.LANCZOS); big.save('assets/character/princess.png', optimize=True)
# face avatar (head + hands heart)
fw, fh = im.size
face = im.crop((int(fw*0.30), 0, int(fw*0.80), int(fh*0.24)))
face = face.resize((360, round(360*face.height/face.width)), Image.LANCZOS); face.save('assets/character/princess_face.png', optimize=True)
pv = Image.new('RGBA', big.size, (255,200,230,255)); pv.alpha_composite(big)
pv.convert('RGB').resize((w//3, h//3)).save('/tmp/claude-0/preview_cut.png')
print(big.size, face.size)
