"""Synthesises all sound effects + background music (no external assets, no TTS).
Run:  python3 tools/make_audio.py   (needs numpy + ffmpeg)"""
import numpy as np, subprocess, os, wave, random
SR = 44100
OUT_SFX = 'assets/audio/sfx'; OUT_MUS = 'assets/music'
os.makedirs(OUT_SFX, exist_ok=True); os.makedirs(OUT_MUS, exist_ok=True)
def t(d): return np.arange(int(SR*d))/SR
def env(n, a=0.005, r=0.2, curve=3.0):
    e = np.ones(n); na = max(1,int(a*SR)); e[:na] = np.linspace(0,1,na)
    nr = min(n, int(r*SR)); e[-nr:] *= np.linspace(1,0,nr)**curve if nr>0 else 1
    return e
def bell(f, d=0.6, amp=0.5, decay=5.0):
    x = t(d); s = np.zeros_like(x)
    for k,(m,a) in enumerate([(1,1),(2.0,0.35),(3.01,0.18),(4.2,0.08)]):
        s += a*np.sin(2*np.pi*f*m*x)*np.exp(-x*decay*(1+0.6*k))
    s *= np.minimum(1, x/0.004)
    return amp*s/ max(1e-6, np.abs(s).max())
def soft(f, d=0.4, amp=0.4):
    x = t(d); s = np.sin(2*np.pi*f*x)+0.3*np.sin(2*np.pi*2*f*x)
    return amp*s*env(len(x),0.02,d*0.7,1.5)/1.3
def mix(parts, total):
    out = np.zeros(int(SR*total))
    for off, sig in parts:
        i = int(off*SR); j = min(len(out), i+len(sig))
        if i < len(out): out[i:j] += sig[:j-i]
    return out
def save(name, sig, folder=OUT_SFX, gain=0.85):
    sig = sig/ max(1e-6, np.abs(sig).max()) * gain
    wav = f'/tmp/claude-0/{name}.wav'
    with wave.open(wav,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((sig*32767).astype(np.int16).tobytes())
    subprocess.run(['ffmpeg','-y','-loglevel','error','-i',wav,'-codec:a','libmp3lame','-q:a','4',f'{folder}/{name}.mp3'],check=True)
    os.remove(wav)
N = {'C5':523.25,'D5':587.33,'E5':659.25,'G5':783.99,'A5':880.0,'C6':1046.5,'E6':1318.5,'G4':392.0,'A4':440.0,'E4':329.63,'C4':261.63,'D6':1174.7,'G6':1568.0}
# --- effects ---
save('click', mix([(0,bell(1200,0.12,0.6,18))],0.12))
save('pop', mix([(0,bell(700,0.15,0.7,16)),(0.03,bell(1050,0.12,0.5,18))],0.2))
x = t(0.45); sw = np.sin(2*np.pi*(300*x+900*x**2))*np.sin(np.pi*x/0.45)**2*0.4
save('whoosh', sw)
save('step', mix([(0,bell(220,0.1,0.7,30))],0.12))
save('correct', mix([(i*0.11,bell(f,0.7,0.5,4.5)) for i,f in enumerate([N['C5'],N['E5'],N['G5'],N['C6']])],1.2))
save('wrong', mix([(0,soft(392,0.28,0.45)),(0.2,soft(330,0.42,0.4))],0.7))   # soft, friendly "oops"
save('star', mix([(i*0.07,bell(f,0.6,0.45,5)) for i,f in enumerate([N['G5'],N['C6'],N['E6'],N['G6']])],1.0))
save('magic', mix([(i*0.045,bell(N['C5']*2**(i/5),0.5,0.35,6)) for i in range(14)],1.4))
save('unlock', mix([(0,bell(N['E5'],0.5,0.5,5)),(0.15,bell(N['A5'],0.5,0.5,5)),(0.3,bell(N['D6'],0.9,0.55,4))],1.4))
save('flip', mix([(0,bell(900,0.08,0.5,25)),(0.05,bell(1300,0.1,0.4,25))],0.2))
fan = [(0,'C5'),(0.14,'E5'),(0.28,'G5'),(0.42,'C6'),(0.7,'G5'),(0.84,'C6'),(1.0,'E6')]
parts = [(o,bell(N[n],1.1,0.5,3.5)) for o,n in fan]
parts += [(1.0,bell(N['G6'],1.5,0.35,3)),(1.0,bell(N['C6'],1.6,0.35,3))]
fan_sig = mix(parts,2.8)
rng = np.random.default_rng(3)
for k in range(30):  # sparkle confetti
    parts_sp = bell(rng.uniform(1500,3500),0.25,0.12,14); i = int(rng.uniform(0.9,2.4)*SR); fan_sig[i:i+len(parts_sp)] += parts_sp[:len(fan_sig)-i]
save('celebrate', fan_sig)
save('levelup', mix([(0,bell(N['C5'],0.6,.5,4)),(0.18,bell(N['E5'],0.6,.5,4)),(0.36,bell(N['G5'],0.6,.5,4)),(0.54,bell(N['C6'],0.6,.5,4)),(0.8,bell(N['E6'],1.4,.55,3)),(0.8,bell(N['G5'],1.4,.4,3)),(0.8,bell(N['C6'],1.4,.4,3))],2.4))
# --- background music: gentle music-box loop, C major pentatonic ---
random.seed(7)
bpm = 92; beat = 60/bpm; bars = 16; total = bars*4*beat
prog = [('C',[130.81,164.81,196.0]),('A',[110.0,164.81,220.0]),('F',[87.31,130.81,174.61]),('G',[98.0,146.83,196.0])]
scale = [523.25,587.33,659.25,783.99,880.0,1046.5]
tail = 3.0
buf = np.zeros(int((total+tail)*SR))
def put(off, sig):
    i=int(off*SR); buf[i:i+len(sig)] += sig[:len(buf)-i]
for bar in range(bars):
    name, ch = prog[bar%4]; b0 = bar*4*beat
    # soft pad (arpeggiated bass)
    for k,f in enumerate(ch*2):
        put(b0+k*beat*0.5, soft(f, beat*1.6, 0.16))
    # melody: stepwise random walk, mostly 8th notes with rests
    idx = random.randint(1,4)
    for step in range(8):
        if random.random() < 0.28: continue
        idx = min(5, max(0, idx + random.choice([-2,-1,-1,0,1,1,2])))
        put(b0+step*beat*0.5, bell(scale[idx], 1.4, 0.34, 3.4))
    if bar%4==3:  # gentle ending sparkle each phrase
        put(b0+3.5*beat, bell(scale[5],1.6,0.25,3))
loop = buf[:int(total*SR)].copy(); wrap = buf[int(total*SR):]
loop[:len(wrap)] += wrap  # overlap tail onto start -> seamless
save('lolo_theme', loop, OUT_MUS, 0.6)
print('done')
