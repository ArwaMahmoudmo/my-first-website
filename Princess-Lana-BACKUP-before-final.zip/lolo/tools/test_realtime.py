"""Smoke test WITHOUT audio stubs: real timings, real sound files.
Checks: every sfx/music file loads, speech never hangs the game, a game round advances on its own."""
import threading, http.server, socketserver, functools, os, json, time
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
s = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(H, directory=ROOT)); threading.Thread(target=s.serve_forever, daemon=True).start()
out = {}; errs = []
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--autoplay-policy=no-user-gesture-required'])
    ctx = b.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True); pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(f'http://127.0.0.1:{s.server_address[1]}/index.html'); pg.wait_for_timeout(500)
    out['sound files'] = pg.evaluate("""Promise.all(['click','pop','whoosh','step','correct','wrong','star','magic','unlock','flip','celebrate','levelup'].map(n=>new Promise(r=>{const a=new Audio('assets/audio/sfx/'+n+'.mp3');a.onloadedmetadata=()=>r([n,Math.round(a.duration*100)/100]);a.onerror=()=>r([n,'ERROR']);})).concat([new Promise(r=>{const a=new Audio('assets/music/lolo_theme.mp3');a.onloadedmetadata=()=>r(['music',Math.round(a.duration)]);a.onerror=()=>r(['music','ERROR']);})]))""")
    pg.locator('.gate-btn').click(force=True); pg.wait_for_timeout(1200)
    out['arabic device voice'] = pg.evaluate('LOLO.Audio.hasArabicVoice')
    t0 = time.time()
    r = pg.evaluate("""new Promise(res=>{const t=Date.now();LOLO.Audio.say('letter_2','باء').then(ok=>res({ok,ms:Date.now()-t}));setTimeout(()=>res({hang:true}),9000)})""")
    out['speech line resolves (no voice => timed fallback)'] = r
    pg.evaluate("LOLO.Nav.go('game',{id:'find'})"); pg.wait_for_timeout(500)
    pg.locator('.card.result .btn.primary').click(force=True); pg.wait_for_selector('.opt', timeout=8000)
    first = pg.inner_text('.q-prompt'); done = False
    for _ in range(4):
        o = pg.query_selector_all('.opt:not(.nope)')[0]; o.click(force=True); pg.wait_for_timeout(300)
        if pg.query_selector('.opt.right'): break
    pg.wait_for_function("document.querySelectorAll('.opt.right').length===0 && document.querySelectorAll('.opt').length===3", timeout=12000)
    out['round advanced by itself in real time'] = True
    out['stars after one correct answer'] = pg.evaluate('LOLO.Progress.get().stars')
    out['js errors'] = errs; b.close()
print(json.dumps(out, ensure_ascii=False, indent=1))
