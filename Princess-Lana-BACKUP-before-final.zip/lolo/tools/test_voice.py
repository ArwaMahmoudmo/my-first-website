"""Voice pipeline test: record with a fake microphone -> download ZIP -> unzip over a copy of the game -> game plays the recording."""
import os, shutil, zipfile, threading, http.server, socketserver, functools, tempfile, json
from playwright.sync_api import sync_playwright
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP = tempfile.mkdtemp(prefix='lolo_voice_'); COPY = os.path.join(TMP, 'game')
shutil.copytree(ROOT, COPY, ignore=shutil.ignore_patterns('*.zip', '.git'))
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
def serve(d):
    socketserver.TCPServer.allow_reuse_address = True
    s = socketserver.TCPServer(('127.0.0.1', 0), functools.partial(H, directory=d)); threading.Thread(target=s.serve_forever, daemon=True).start(); return s
res = {}
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required'])
    s1 = serve(COPY); url = f'http://127.0.0.1:{s1.server_address[1]}'
    ctx = b.new_context(permissions=['microphone'], accept_downloads=True); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto(url + '/recorder.html'); pg.wait_for_timeout(800)
    res['recorder lines listed'] = pg.evaluate('document.querySelectorAll(".row").length')
    pg.locator('.row').nth(0).locator('.rec').click(force=True); pg.wait_for_timeout(1800); pg.locator('.row').nth(0).locator('.rec').click(force=True); pg.wait_for_timeout(600)
    pg.locator('.row').nth(1).locator('.rec').click(force=True); pg.wait_for_timeout(1200); pg.locator('.row').nth(1).locator('.rec').click(force=True); pg.wait_for_timeout(600)
    st = pg.evaluate('Object.keys(window.__recorder.store())'); res['recorded keys'] = st
    with pg.expect_download() as d: pg.click('#dl')
    zp = os.path.join(TMP, 'out.zip'); d.value.save_as(zp)
    z = zipfile.ZipFile(zp); res['zip test (None = valid)'] = z.testzip(); res['zip entries'] = z.namelist()
    z.extractall(COPY)
    pg2 = ctx.new_page(); pg2.on('pageerror', lambda e: errs.append(str(e)))
    pg2.goto(url + '/index.html'); pg2.wait_for_timeout(700)
    key = st[0]
    res['manifest loaded'] = pg2.evaluate('Object.keys(LOLO.VOICE_FILES)')
    pg2.click('.gate-btn', force=True); pg2.wait_for_timeout(800)
    r = pg2.evaluate("""(k) => new Promise(res => { LOLO.Audio.say(k, 'x').then(()=>res({file: LOLO.Audio.voiceFiles[k]})); setTimeout(()=>res({file:LOLO.Audio.voiceFiles[k],timeout:true}),6000) })""", key)
    res['game played recorded file'] = r
    res['voiceStatus'] = pg2.evaluate('LOLO.Audio.voiceStatus()')
    res['js errors'] = errs
    b.close()
print(json.dumps(res, ensure_ascii=False, indent=1))
shutil.rmtree(TMP, ignore_errors=True)
