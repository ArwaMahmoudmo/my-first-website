# مغامرات الأميرة لانا في مملكة الحروف
## Princess Lana – The Magical Kingdom of Arabic Letters

A complete Arabic-letters learning game for children, built with plain HTML5 + CSS3 + JavaScript.
No installation, no build step, no server code. It runs in any modern browser on Android, iPhone, tablets and computers.

**Contents:** 28 letters (names, sounds, 4 shapes, drawn vocabulary pictures) · 3 short vowels · 3 long vowels · 8 games ·
11-level adventure map · stars + 12 badges · parent/teacher progress page · princess guide with 8 animation states ·
sound effects + music (real MP3 files) · voice-recording tool.

---

## 1. Run it on your laptop

**Easiest:** unzip the folder, then double-click **`index.html`**. Tap the magic gate – the game starts.

**Recommended (works exactly like a website, needed for the recorder tool):**

```bash
cd princess-lana          # the unzipped folder
python3 -m http.server 8000
# open  http://localhost:8000   in Chrome / Edge / Safari
```
(Windows without Python: install Python from python.org, or use the free "Live Server" extension in VS Code.)

> The first tap on the gate is required – browsers do not allow sound before the user touches the page.

**Internet:** the Arabic fonts (Amiri, Cairo, Baloo Bhaijaan 2) load from Google Fonts. Offline, the game still works
and uses the device's own Arabic font. See §8 to bundle fonts for 100 % offline use.

---

## 2. Put it online and share a link

The game is a **static website** – any static host works. Upload the **contents of the folder** (the folder that contains `index.html`), not the ZIP.
HTTPS is automatic on all of these, which is also what the microphone feature needs.

**Netlify Drop (fastest, free, 2 minutes)**
1. Go to <https://app.netlify.com/drop> (create a free account).
2. Drag the whole unzipped folder onto the page.
3. You get a link like `https://something.netlify.app` – send it to customers. You can rename it or attach your own domain in *Site settings → Domain management*.

**GitHub Pages (free)**
1. Create a repository, upload all files (keep `index.html` at the top level).
2. *Settings → Pages → Deploy from branch → main / root.* Your link: `https://<user>.github.io/<repo>/`.

**Cloudflare Pages / Vercel / any web hosting (cPanel):** upload the folder, set "no build command" and the output folder to the root.

**One customer = one copy.** Progress is saved in each child's own browser (localStorage); nothing is sent to any server.
To brand a copy for a customer: edit `data/config.js` (title) and the colours in `css/style.css` (`:root`), optionally swap the princess image.

---

## 3. Replace the princess image

The princess is `assets/character/princess.png`.

1. Prepare a **PNG with a transparent background**, one standing figure, portrait (about 800 × 1400 px, 1 MB or less).
   Remove the photo background with remove.bg, Canva "Background Remover", Photoshop, or similar.
   (`tools/cutout.py` is the rough script used for the original photo – it has coordinates specific to that picture, so use it only as a reference.)
2. Overwrite `assets/character/princess.png` (keep the same name).
3. Make the small round face avatar (used on the map and the "find the letter" path):
   `python3 tools/make_face.py` – or simply overwrite `assets/character/princess_face.png` with a square-ish crop of the face (~360 px wide).
4. Reload the page (hard refresh: Ctrl+Shift+R).

All animations (greet, walk, jump, clap, think, celebrate, encourage, smile) are movements applied to the picture, so they work with any new image.
Their speed and style are in `css/style.css`, search for `.g-figure.st-`.

> **Rights:** if the picture shows a real person, make sure you (or the child's guardian) have the right to use that likeness commercially.

---

## 4. Edit letters, lessons, questions, branding

Everything educational lives in `data/` – no JavaScript knowledge needed for normal edits.

| File | What it controls |
|---|---|
| `data/config.js` | Game title shown on the home screen, browser-tab title, parent-button hold time |
| `data/letters.js` | The 28 letters: name, vocabulary word (`word`, with vowel marks), the word split letter-by-letter (`chunks`), picture (`img`, emoji fallback), look-alike groups |
| `data/lessons.js` | Short vowels, long vowels, the 11 **adventure levels** (order, titles, which letters), the 8 games' names/intros, **every sentence the princess says** (`LOLO.SAY`, several variants each), badges |
| `data/questions.js` | Hand-written concept questions (`CONCEPT_QUESTIONS`) and **how many rounds** each game has (`LOLO.ROUNDS`) |
| `css/style.css` | Colours (top of file, `:root`), sizes, animations |

**Change a vocabulary word / picture** – in `data/letters.js` edit the letter's line, e.g.
```js
{ id: 2, ch: 'ب', name: 'بَاء', join: 'dual', word: 'بَطَّة', chunks: ['بَ','طَّ','ة'], plain: 'بطة', emoji: '🦆', img: 'assets/images/words/batta.svg' }
```
Rules: `chunks` must be the word split into letters, each with its own marks, and joined they must equal `word`.
`join` is `'right'` only for the letters that do not connect to the next one (ا أ د ذ ر ز و ة).
Put your own picture (SVG or PNG, square) in `assets/images/words/` and point `img` to it. If the file is missing the game shows the `emoji`.

**Add a question** – append to `LOLO.CONCEPT_QUESTIONS` in `data/questions.js`:
```js
{ q: 'كَمْ نُقْطَةً تَحْتَ البَاء؟', opts: ['وَاحِدَة', 'اثْنَتَان', 'ثَلَاث'], a: 0, hint: 'تحت الباء نقطة واحدة.' }
```
(`a` = index of the correct option; options are shuffled automatically.) Letter, sound, vowel and word questions are generated from `letters.js`.

**Change the adventure** – edit `LOLO.LEVELS` in `data/lessons.js` (e.g. give a level only 5 letters, reorder levels). Levels unlock one after another.

**Redraw the 28 pictures** – edit `tools/make_illustrations.py` and run `python3 tools/make_illustrations.py`.

---

## 5. Audio

### Sound effects and music (real files)
`assets/audio/sfx/*.mp3` (click, pop, whoosh, step, correct, wrong, star, magic, unlock, flip, celebrate, levelup) and `assets/music/lolo_theme.mp3`.
Replace any file with your own, keeping the same name. They were synthesised by `tools/make_audio.py` (re-runnable, needs numpy + ffmpeg).
Controls (🔊 button, top bar): volume, mute, music on/off, replay last voice.

### Automatic voice (no recording needed)
Out of the box the princess speaks everything automatically:
1. The game scans the device's Arabic voices and **picks a female one automatically** (known female names such as Hoda/Zariyah/Salma/Laila are preferred, known male voices such as Naayf/Hamed/Majed are avoided; ar-SA, then ar-EG preferred). Tested with simulated voice lists only.
2. If the device has **no Arabic voice** (common on some Android phones), the game tries an **online Arabic voice** (needs internet). It uses the unofficial Google Translate speech address, which can change, be rate-limited or be blocked. It could **not** be tested from the build environment (no internet there), so test it on your phone. Switch it off with `onlineVoice: false` in `data/config.js`.
3. If both fail, the sentence still appears in the speech bubble.
**Android tip:** to get a good voice on the phone, install/update **"Speech Services by Google"** and download Arabic: Settings → System → Languages → Text-to-speech output → Google → ⚙ → Install voice data → Arabic.
For a *reliable* commercial voice without recording yourself, generate the 463 files once with a paid text-to-speech service (Azure, Google Cloud, ElevenLabs) and put the files in `assets/audio/voice/`; the game then prefers them over everything else.

**Voice diagnostics:** Parent area → "تشخيص الصوت" lists every voice the browser reports (name + language code), whether the page runs in a frame, and has buttons that really try to speak (ar-SA / ar / chosen voice) and the online voice, showing the browser's own result (started / error code such as `language-unavailable` or `not-allowed`).

### Princess voice – what is real and what is not (please read)
The game speaks every line (letter names, letter+vowel syllables, long-vowel syllables, words, instructions, praise) in this order:

1. **A recording you provide** – `assets/audio/voice/<key>.mp3` (or .m4a/.ogg/.webm/.wav) listed in `data/voice-manifest.js`.
2. **The device's built-in Arabic text-to-speech** (Web Speech API) if no recording exists.
3. Nothing – the sentence is always shown in the princess's speech bubble anyway.

**No recorded voice files are included.** Real Arabic speech could not be produced in the environment where this game was built, so out of the box *every* line uses option 2 (or 3).
That means:
- Quality depends on the child's phone/computer. Android/Chrome and Windows usually have an Arabic voice; some devices have none; iPhone Arabic voices are usually male.
- Device TTS can mispronounce **isolated letters and letter+vowel syllables** (e.g. بَ / بُ / بِ, short vs long vowels). This is exactly what a teaching product needs to get right, so
  **for commercial use, record the voice** (it takes about an hour – see below).
- The parent page (long-press "منطقة الأهل والمعلمين" on the achievements screen) shows how many lines are really recorded.

### Record the voice (no technical skills needed)
There are **463 lines** (28 letter names, 28×6 syllables, 28 words, instructions, praise…).
1. Open **`recorder.html`** through `http://localhost:8000/recorder.html` (or your https site) – the microphone needs localhost/https.
2. For each line press **⏺ تسجيل**, read the Arabic text clearly, press **⏹**, check with **▶**. Work group by group (use the filter). Recordings are kept in your browser, so you can stop and continue.
   Already have studio files? Press **📂 استيراد** – the file name must equal the line key, e.g. `letter_2.mp3`.
3. Press **⬇️ تنزيل الملف المضغوط**. Unzip it **into the game's main folder** – it adds `assets/audio/voice/…` and `data/voice-manifest.js`.
4. Reload the game. Recorded lines now play your voice; the rest still use the device voice.

Key names (all listed inside the recorder): `letter_<1-28>` letter name · `fatha_/damma_/kasra_<id>` short-vowel syllables ·
`longa_/longu_/longi_<id>` long-vowel syllables · `word_<id>` vocabulary · `intro_<id>` "this is the letter…" · `say_<phrase>_<n>` princess dialogue · `game_…`, `ask_…`, `hint_…` instructions.

Tip: recorded files may be a few hundred KB each; the full set is ~20–40 MB, fine for hosting. Record in a quiet room, same distance from the microphone.

### Optional: pronunciation recognition (game 8)
"Listen and repeat" shows a 🎤 button **only** if the browser supports speech recognition (mainly Chrome/Android). It is lenient and never required – the child can always press "قلتها!".

---

## 6. For parents and teachers

Achievements screen → press and hold **"منطقة الأهل والمعلمين"** (about 1.4 s, so children do not open it by accident).
It shows letters learned, vowels and long vowels completed, games played, stars, levels, a progress %, and has Print and Reset buttons.
Progress lives in the browser on that device; clearing browser data or using another device starts fresh.

---

## 7. Project structure

```
index.html            the game page
recorder.html         voice-recording tool for teachers
css/style.css         all styling + animations
js/main.js            screens, princess guide, effects, lessons
js/games.js           the 8 games and question generators
js/audio.js           sound effects, music, voice playback
js/navigation.js      screen router
js/progress.js        saved progress, stars, badges
js/voicemap.js        every spoken line: key + Arabic text
data/                 config.js  letters.js  lessons.js  questions.js  voice-manifest.js
assets/character/     princess.png, princess_face.png
assets/images/        castle, garden, clouds, butterfly, star, crown, gate (SVG) + words/ (28 vocabulary illustrations)
assets/audio/sfx/     12 sound effects      assets/music/   background music
assets/audio/voice/   (empty) your recordings
tools/                make_audio.py, make_illustrations.py, make_face.py, cutout.py, test_game.py, test_voice.py, test_realtime.py
```

## 8. Fonts for 100 % offline use (optional)
Download **Amiri** and **Cairo** (free, SIL Open Font License) from fonts.google.com, put the `.woff2`/`.ttf` files in `assets/fonts/`, and add to `css/style.css`:
```css
@font-face { font-family: 'Amiri'; src: url('../assets/fonts/Amiri-Regular.ttf'); font-weight: 400; }
@font-face { font-family: 'Amiri'; src: url('../assets/fonts/Amiri-Bold.ttf'); font-weight: 700; }
@font-face { font-family: 'Cairo'; src: url('../assets/fonts/Cairo-Bold.ttf'); font-weight: 700; }
```
and remove the Google Fonts `<link>` from `index.html`. (GSAP is also loaded from a CDN but is optional – every animation works without it.)

## 9. Automated tests (optional, for developers)
Needs Python, `pip install playwright` and Chrome:
```bash
python3 tools/test_game.py       # walks every screen + all 8 games on phone/iPhone/tablet/desktop sizes, checks overflow, JS errors, saving
python3 tools/test_voice.py      # recorder -> zip -> game plays the recording
python3 tools/test_realtime.py   # real timings, all sound files load
```
Edit the Chrome path inside the scripts if yours differs.

## 10. Known limitations
- No recorded Arabic voice is shipped (see §5). Device TTS pronunciation of isolated letters/syllables is **not guaranteed**.
- Tested in desktop Chrome with emulated phone/tablet screens. **Not tested on physical Android/iOS devices or Safari/Firefox.**
- The princess is one still photo made to move (bounce, sway, spin, particles) – there are no separate drawn poses (hands clapping, mouth moving).
- Vocabulary pictures are simple flat SVG drawings made for this project; you may want a professional illustrator for premium editions.
- Needs internet only for the fonts and the optional GSAP script; otherwise fully offline-capable if opened from files/hosted, but it is not an installable PWA.
