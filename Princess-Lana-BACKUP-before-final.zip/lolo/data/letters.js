/* ==========================================================
   data/letters.js  —  the 28 Arabic letters (correct order)
   Edit this file to change vocabulary / illustrations.

   Fields
   id      1..28
   ch      the letter
   name    letter name (shown + spoken)
   join    'dual'  = connects on both sides
           'right' = connects only to the previous letter (ا د ذ ر ز و)
   word    vocabulary word WITH short vowels (shown + spoken)
   chunks  the word split letter-by-letter (letter + its marks) — used by
           "Complete the word" so every letter keeps its correct shape
   plain   the word without marks
   emoji   illustration shown on the picture card
   img     OPTIONAL path to your own illustration, e.g. 'assets/images/words/bata.svg'
           (if set it replaces the emoji)
   ========================================================== */
window.LOLO = window.LOLO || {};
LOLO.LETTERS = [
  { id: 1,  ch: 'أ', name: 'أَلِف',  join: 'right', word: 'أَرْنَب',   chunks: ['أَ','رْ','نَ','ب'],       plain: 'أرنب',  emoji: '🐰', img: 'assets/images/words/arnab.svg' },
  { id: 2,  ch: 'ب', name: 'بَاء',   join: 'dual',  word: 'بَطَّة',    chunks: ['بَ','طَّ','ة'],           plain: 'بطة',   emoji: '🦆', img: 'assets/images/words/batta.svg' },
  { id: 3,  ch: 'ت', name: 'تَاء',   join: 'dual',  word: 'تُفَّاحَة', chunks: ['تُ','فَّ','ا','حَ','ة'],  plain: 'تفاحة', emoji: '🍎', img: 'assets/images/words/tuffaha.svg' },
  { id: 4,  ch: 'ث', name: 'ثَاء',   join: 'dual',  word: 'ثَعْلَب',   chunks: ['ثَ','عْ','لَ','ب'],       plain: 'ثعلب',  emoji: '🦊', img: 'assets/images/words/thaalab.svg' },
  { id: 5,  ch: 'ج', name: 'جِيم',   join: 'dual',  word: 'جَمَل',     chunks: ['جَ','مَ','ل'],            plain: 'جمل',   emoji: '🐪', img: 'assets/images/words/jamal.svg' },
  { id: 6,  ch: 'ح', name: 'حَاء',   join: 'dual',  word: 'حِصَان',    chunks: ['حِ','صَ','ا','ن'],        plain: 'حصان',  emoji: '🐴', img: 'assets/images/words/hisan.svg' },
  { id: 7,  ch: 'خ', name: 'خَاء',   join: 'dual',  word: 'خَرُوف',    chunks: ['خَ','رُ','و','ف'],        plain: 'خروف',  emoji: '🐑', img: 'assets/images/words/kharouf.svg' },
  { id: 8,  ch: 'د', name: 'دَال',   join: 'right', word: 'دُبّ',      chunks: ['دُ','بّ'],                plain: 'دب',    emoji: '🐻', img: 'assets/images/words/dubb.svg' },
  { id: 9,  ch: 'ذ', name: 'ذَال',   join: 'right', word: 'ذُرَة',     chunks: ['ذُ','رَ','ة'],            plain: 'ذرة',   emoji: '🌽', img: 'assets/images/words/dhura.svg' },
  { id: 10, ch: 'ر', name: 'رَاء',   join: 'right', word: 'رِيشَة',    chunks: ['رِ','ي','شَ','ة'],        plain: 'ريشة',  emoji: '🪶', img: 'assets/images/words/risha.svg' },
  { id: 11, ch: 'ز', name: 'زَاي',   join: 'right', word: 'زَرَافَة',  chunks: ['زَ','رَ','ا','فَ','ة'],   plain: 'زرافة', emoji: '🦒', img: 'assets/images/words/zarafa.svg' },
  { id: 12, ch: 'س', name: 'سِين',   join: 'dual',  word: 'سَمَكَة',   chunks: ['سَ','مَ','كَ','ة'],       plain: 'سمكة',  emoji: '🐟', img: 'assets/images/words/samaka.svg' },
  { id: 13, ch: 'ش', name: 'شِين',   join: 'dual',  word: 'شَمْس',     chunks: ['شَ','مْ','س'],            plain: 'شمس',   emoji: '☀️', img: 'assets/images/words/shams.svg' },
  { id: 14, ch: 'ص', name: 'صَاد',   join: 'dual',  word: 'صَارُوخ',   chunks: ['صَ','ا','رُ','و','خ'],    plain: 'صاروخ', emoji: '🚀', img: 'assets/images/words/sarokh.svg' },
  { id: 15, ch: 'ض', name: 'ضَاد',   join: 'dual',  word: 'ضِفْدَع',   chunks: ['ضِ','فْ','دَ','ع'],       plain: 'ضفدع',  emoji: '🐸', img: 'assets/images/words/difda.svg' },
  { id: 16, ch: 'ط', name: 'طَاء',   join: 'dual',  word: 'طَائِرَة', chunks: ['طَ','ا','ئِ','رَ','ة'],   plain: 'طائرة', emoji: '✈️', img: 'assets/images/words/taira.svg' },
  { id: 17, ch: 'ظ', name: 'ظَاء',   join: 'dual',  word: 'ظَرْف',     chunks: ['ظَ','رْ','ف'],            plain: 'ظرف',   emoji: '✉️', img: 'assets/images/words/zarf.svg' },
  { id: 18, ch: 'ع', name: 'عَيْن',  join: 'dual',  word: 'عِنَب',     chunks: ['عِ','نَ','ب'],            plain: 'عنب',   emoji: '🍇', img: 'assets/images/words/inab.svg' },
  { id: 19, ch: 'غ', name: 'غَيْن',  join: 'dual',  word: 'غَيْمَة',   chunks: ['غَ','يْ','مَ','ة'],       plain: 'غيمة',  emoji: '☁️', img: 'assets/images/words/ghayma.svg' },
  { id: 20, ch: 'ف', name: 'فَاء',   join: 'dual',  word: 'فَرَاشَة',  chunks: ['فَ','رَ','ا','شَ','ة'],   plain: 'فراشة', emoji: '🦋', img: 'assets/images/words/farasha.svg' },
  { id: 21, ch: 'ق', name: 'قَاف',   join: 'dual',  word: 'قَمَر',     chunks: ['قَ','مَ','ر'],            plain: 'قمر',   emoji: '🌙', img: 'assets/images/words/qamar.svg' },
  { id: 22, ch: 'ك', name: 'كَاف',   join: 'dual',  word: 'كَلْب',     chunks: ['كَ','لْ','ب'],            plain: 'كلب',   emoji: '🐶', img: 'assets/images/words/kalb.svg' },
  { id: 23, ch: 'ل', name: 'لَام',   join: 'dual',  word: 'لَيْمُون',  chunks: ['لَ','يْ','مُ','و','ن'],   plain: 'ليمون', emoji: '🍋', img: 'assets/images/words/laymoun.svg' },
  { id: 24, ch: 'م', name: 'مِيم',   join: 'dual',  word: 'مَوْزَة',   chunks: ['مَ','وْ','زَ','ة'],       plain: 'موزة',  emoji: '🍌', img: 'assets/images/words/mawza.svg' },
  { id: 25, ch: 'ن', name: 'نُون',   join: 'dual',  word: 'نَجْمَة',   chunks: ['نَ','جْ','مَ','ة'],       plain: 'نجمة',  emoji: '⭐', img: 'assets/images/words/najma.svg' },
  { id: 26, ch: 'ه', name: 'هَاء',   join: 'dual',  word: 'هَدِيَّة',  chunks: ['هَ','دِ','يَّ','ة'],      plain: 'هدية',  emoji: '🎁', img: 'assets/images/words/hadiya.svg' },
  { id: 27, ch: 'و', name: 'وَاو',   join: 'right', word: 'وَرْدَة',   chunks: ['وَ','رْ','دَ','ة'],       plain: 'وردة',  emoji: '🌹', img: 'assets/images/words/warda.svg' },
  { id: 28, ch: 'ي', name: 'يَاء',   join: 'dual',  word: 'يَد',       chunks: ['يَ','د'],                 plain: 'يد',    emoji: '✋', img: 'assets/images/words/yad.svg' }
];

/* Letters that look alike — used to build "tricky but fair" wrong answers */
LOLO.SIMILAR = [[2,3,4,25,28],[5,6,7],[8,9],[10,11],[12,13],[14,15],[16,17],[18,19],[20,21]];

LOLO.ZWJ = '‍';
LOLO.MARKS = { fatha: 'َ', damma: 'ُ', kasra: 'ِ' };

/* ---- helpers shared by all screens -------------------------------- */
LOLO.byId = function (id) { return LOLO.LETTERS.find(function (l) { return l.id === id; }); };

/* the four shapes of a letter. Uses ZWJ so the browser picks the right glyph */
LOLO.forms = function (l) {
  var Z = LOLO.ZWJ;
  if (l.join === 'right') {
    return { isolated: l.ch, initial: l.ch, medial: Z + l.ch, final: Z + l.ch, noInitial: true };
  }
  return { isolated: l.ch, initial: l.ch + Z, medial: Z + l.ch + Z, final: Z + l.ch };
};

/* short-vowel syllable e.g. بَ  / long-vowel syllable e.g. بَا */
LOLO.syllable = function (l, vowel) {
  var M = LOLO.MARKS;
  switch (vowel) {
    case 'fatha': return l.ch + M.fatha;
    case 'damma': return l.ch + M.damma;
    case 'kasra': return l.ch + M.kasra;
    case 'longa': return l.ch + M.fatha + 'ا';
    case 'longu': return l.ch + M.damma + 'و';
    case 'longi': return l.ch + M.kasra + 'ي';
  }
  return l.ch;
};

/* word chunks -> array of shaped strings (joins correctly, optional blank) */
LOLO.shapeChunks = function (l) {
  var Z = LOLO.ZWJ, c = l.chunks, out = [];
  var rightOnly = { 'ا':1, 'أ':1, 'د':1, 'ذ':1, 'ر':1, 'ز':1, 'و':1, 'ة':1 };
  function base(s) { return s.charAt(0); }
  for (var i = 0; i < c.length; i++) {
    var joinPrev = i > 0 && !rightOnly[base(c[i - 1])];
    var joinNext = i < c.length - 1 && !rightOnly[base(c[i])];
    out.push((joinPrev ? Z : '') + c[i] + (joinNext ? Z : ''));
  }
  return out;
};
