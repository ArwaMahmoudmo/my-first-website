/* ==========================================================
   data/config.js — branding & switches for each customer.
   Change the texts below; no other file needs editing for a rebrand.
   ========================================================== */
window.LOLO = window.LOLO || {};
LOLO.CONFIG = {
  pageTitle: 'مغامرات الأميرة لانا في مملكة الحروف',   // browser tab title
  title: 'مُغَامَرَاتُ الأَمِيرَة لَانَا',               // big title on the home screen
  subtitle: 'فِي مَمْلَكَةِ الحُرُوف',                   // line under the title
  parentHoldMs: 1400,                                   // how long (ms) the parent button must be held
  // Voice when the phone has NO Arabic voice: true/'auto' = try an online Arabic voice (needs internet),
  // false = never go online, 'always' = prefer the online voice unless the device voice is a known female voice.
  onlineVoice: 'auto'
};
