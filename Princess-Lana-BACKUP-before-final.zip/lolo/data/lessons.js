/* ==========================================================
   data/lessons.js — vowels, long vowels, levels, dialogue, badges
   Every spoken line has an id. If you add recordings, name them
   assets/audio/voice/<key>.mp3  (see README → "Voice recordings").
   ========================================================== */
window.LOLO = window.LOLO || {};

/* ---------- Short vowels ---------- */
LOLO.VOWELS = [
  { id: 'fatha', name: 'الفَتْحَة', mark: 'َ', place: 'above', color: '#ff5fa2',
    where: 'فَوْقَ الحَرْف', sound: 'أَ',
    intro: 'هذه الفتحة. هي خطّ صغير نضعه فوق الحرف. ونقول معها صوت «أَ» ونفتح فمنا.',
    tip: 'الفتحة فوق الحرف، وفمنا مفتوح.' },
  { id: 'damma', name: 'الضَّمَّة', mark: 'ُ', place: 'above', color: '#7b5cff',
    where: 'فَوْقَ الحَرْف', sound: 'أُ',
    intro: 'هذه الضمة. هي واو صغيرة نضعها فوق الحرف. ونقول معها صوت «أُ» ونضمّ شفاهنا.',
    tip: 'الضمة واو صغيرة فوق الحرف، وشفاهنا مضمومة.' },
  { id: 'kasra', name: 'الكَسْرَة', mark: 'ِ', place: 'below', color: '#18a999',
    where: 'تَحْتَ الحَرْف', sound: 'إِ',
    intro: 'هذه الكسرة. هي خطّ صغير نضعه تحت الحرف. ونقول معها صوت «إِ» ونبتسم.',
    tip: 'الكسرة خط صغير تحت الحرف، ونحن نبتسم.' }
];

/* ---------- Long vowels (المدود) ---------- */
LOLO.LONGS = [
  { id: 'longa', name: 'المَدُّ بِالأَلِف', helper: 'ا', short: 'fatha', mark: 'َ', color: '#ff5fa2',
    rule: 'إذا جاءت الألف بعد الفتحة صار الصوت طويلاً: بَا',
    intro: 'هذا المدّ بالألف. الألف تأتي بعد الفتحة، فنطيل الصوت: بَـــا.' },
  { id: 'longu', name: 'المَدُّ بِالوَاو', helper: 'و', short: 'damma', mark: 'ُ', color: '#7b5cff',
    rule: 'إذا جاءت الواو بعد الضمة صار الصوت طويلاً: بُو',
    intro: 'هذا المدّ بالواو. الواو تأتي بعد الضمة، فنطيل الصوت: بُـــو.' },
  { id: 'longi', name: 'المَدُّ بِاليَاء', helper: 'ي', short: 'kasra', mark: 'ِ', color: '#18a999',
    rule: 'إذا جاءت الياء بعد الكسرة صار الصوت طويلاً: بِي',
    intro: 'هذا المدّ بالياء. الياء تأتي بعد الكسرة، فنطيل الصوت: بِـــي.' }
];

/* ---------- Adventure levels (sequential, unlock one by one) ---------- */
LOLO.LEVELS = [
  { id: 'L1',  kind: 'letters', title: 'حديقة الأَلِف',      letters: [1, 2, 3, 4, 5, 6, 7],       emoji: '🌷' },
  { id: 'L2',  kind: 'letters', title: 'بُسْتَان الدَّال',  letters: [8, 9, 10, 11, 12, 13, 14],  emoji: '🌼' },
  { id: 'L3',  kind: 'letters', title: 'غابَة الضَّاد',      letters: [15, 16, 17, 18, 19, 20, 21], emoji: '🌳' },
  { id: 'L4',  kind: 'letters', title: 'قَصْر الكَاف',      letters: [22, 23, 24, 25, 26, 27, 28], emoji: '🏰' },
  { id: 'L5',  kind: 'vowel',   title: 'بَوَّابَة الفَتْحَة', vowel: 'fatha', emoji: '🚪' },
  { id: 'L6',  kind: 'vowel',   title: 'بَوَّابَة الضَّمَّة', vowel: 'damma', emoji: '🔮' },
  { id: 'L7',  kind: 'vowel',   title: 'بَوَّابَة الكَسْرَة', vowel: 'kasra', emoji: '💎' },
  { id: 'L8',  kind: 'long',    title: 'جِسْر الأَلِف',      long: 'longa', emoji: '🌈' },
  { id: 'L9',  kind: 'long',    title: 'جِسْر الوَاو',       long: 'longu', emoji: '🌉' },
  { id: 'L10', kind: 'long',    title: 'جِسْر اليَاء',       long: 'longi', emoji: '🪄' },
  { id: 'L11', kind: 'final',   title: 'تَحَدِّي الأَمِيرَة', emoji: '👑' }
];

/* ---------- The 8 games ---------- */
LOLO.GAMES = [
  { id: 'find',    title: 'جِدِ الحَرْف',        icon: '🔍', color: '#ff7eb6', intro: 'سأمشي على الطريق السحري. ساعدوني لنجد الحرف الصحيح!' },
  { id: 'listen',  title: 'اسْتَمِعْ وَاخْتَرْ',  icon: '👂', color: '#8f7bff', intro: 'استمعوا جيداً إلى الصوت، ثم اختاروا الحرف الذي سمعتموه.' },
  { id: 'harakat', title: 'جِدِ الحَرَكَة',      icon: '✨', color: '#20c0ae', intro: 'سأقول لكم حرفاً مع حركة. اختاروا الحرف الصحيح مع حركته.' },
  { id: 'word',    title: 'أَكْمِلِ الكَلِمَة',   icon: '🧩', color: '#ffb23e', intro: 'انظروا إلى الصورة، ثم اختاروا الحرف الناقص في الكلمة.' },
  { id: 'match',   title: 'صِلِ الحَرْفَ بِالصُّورَة', icon: '🔗', color: '#4aa8ff', intro: 'اختاروا حرفاً، ثم اختاروا الصورة التي تبدأ به.' },
  { id: 'hunt',    title: 'صَيْد الحُرُوف',       icon: '🌸', color: '#ff8fd2', intro: 'نحن في الحديقة السحرية! ابحثوا عن الحرف بين الزهور.' },
  { id: 'challenge', title: 'تَحَدِّي الأَمِيرَة', icon: '👑', color: '#ffc531', intro: 'هذا تحدّي الأميرة! أسئلة من كل الدروس. هل أنتم مستعدون؟' },
  { id: 'repeat',  title: 'اسْتَمِعْ وَكَرِّرْ',  icon: '🎤', color: '#ff6d6d', intro: 'استمعوا إلى الصوت، ثم كرّروه بصوت عالٍ مثلي.' }
];

/* ---------- Princess Lana's dialogue (several variants avoid repetition) ---------- */
LOLO.SAY = {
  welcome:   ['مرحباً يا أصدقائي! أنا الأميرة لانا، وسنخوض معاً مغامرة ممتعة في مملكة الحروف. هل أنتم مستعدون؟'],
  start:     ['هيا بنا نبدأ مغامرتنا!', 'ما أجمل هذه المغامرة! هيا بنا!', 'أنا متحمسة جداً! هيا نبدأ!'],
  correct:   ['رائع! أحسنتم يا أبطال!', 'ممتاز! إجابة صحيحة!', 'برافو! أنتم مبدعون!', 'ما شاء الله! أحسنت!', 'يا للروعة! استمروا!'],
  wrong:     ['محاولة جميلة! لا بأس، هيا نحاول مرة أخرى.', 'قريب جداً! جرّب مرة ثانية.', 'لا بأس! الأبطال يحاولون دائماً.'],
  retryok:   ['أحسنت! لقد نجحت بعد المحاولة، وهذا رائع!', 'ممتاز! المحاولة تصنع الأبطال!'],
  levelDone: ['واااو! لقد نجحتم! أنا فخورة بكم!', 'أنتم أبطال حقيقيون! أنا فخورة بكم جداً!'],
  starEarned:['حصلتم على نجمة جديدة!', 'نجمة جميلة للأبطال!'],
  listenNow: ['استمعوا جيداً.', 'افتحوا آذانكم الصغيرة.'],
  sayTogether: ['هيا ننطقه معاً!'],
  tryAgain:  ['هيا مرة أخرى!'],
  next:      ['هيا إلى الدرس التالي!', 'ننتقل إلى المغامرة التالية!'],
  home:      ['أهلاً بكم من جديد! ماذا نفعل اليوم؟'],
  lettersK:  ['هذه مملكة الحروف. اختاروا حرفاً لنتعلمه معاً!'],
  vowelsK:   ['هذه مملكة الحركات. سنتعلم الفتحة والضمة والكسرة.'],
  longK:     ['هذه مملكة المدود. هنا نطيل الصوت مع الألف والواو والياء.'],
  gamesK:    ['هذه الألعاب والتحديات! اختاروا لعبة ممتعة.'],
  mapK:      ['هذه خريطة المغامرة. اتبعوا الطريق السحري خطوة خطوة.'],
  achieveK:  ['انظروا إلى نجومكم وأوسمتكم! ما أجملها!'],
  badge:     ['وسام جديد! أنتم رائعون!'],
  hintLetter:['تلميح: ابحثوا عن الحرف الذي تبدأ به كلمة'],
  thinking:  ['همم... دعونا نفكر معاً.'],
  encourage: ['أنتم تستطيعون! أنا أؤمن بكم.', 'لا تستسلموا! أنتم أذكياء.'],
  shortLong: ['استمعوا: الصوت القصير... ثم الصوت الطويل.'],
  micIntro:  ['إذا أحببتم، اضغطوا على الميكروفون وكرّروا. وإذا لم تريدوا فاضغطوا: قلتها!'],
  repeatOk:  ['أحسنتم! نطقٌ جميل!', 'ما أجمل صوتكم!']
};

/* ---------- Achievements ---------- */
LOLO.BADGES = [
  { id: 'first_star', icon: '⭐', title: 'النَّجْمَة الأُولَى',  desc: 'احصل على أول نجمة',          test: function (p) { return p.stars >= 1; } },
  { id: 'stars_25',   icon: '🌟', title: 'جامِع النُّجُوم',     desc: 'اجمع 25 نجمة',                 test: function (p) { return p.stars >= 25; } },
  { id: 'stars_100',  icon: '💫', title: 'سَمَاء مِن نُجُوم',   desc: 'اجمع 100 نجمة',               test: function (p) { return p.stars >= 100; } },
  { id: 'letters_7',  icon: '🌷', title: 'سَبْعَة حُرُوف',      desc: 'تعلّم 7 حروف',                 test: function (p) { return p.lettersLearned.length >= 7; } },
  { id: 'letters_14', icon: '🌼', title: 'نِصْف الأَبْجَدِيَّة', desc: 'تعلّم 14 حرفاً',               test: function (p) { return p.lettersLearned.length >= 14; } },
  { id: 'letters_28', icon: '👑', title: 'مَلِكَة الحُرُوف',    desc: 'تعلّم الحروف الثمانية والعشرين', test: function (p) { return p.lettersLearned.length >= 28; } },
  { id: 'vowels',     icon: '✨', title: 'سَيِّد الحَرَكَات',   desc: 'أتمّ الفتحة والضمة والكسرة',    test: function (p) { return p.vowelsDone.length >= 3; } },
  { id: 'longs',      icon: '🌈', title: 'بَطَل المُدُود',      desc: 'أتمّ المدود الثلاثة',          test: function (p) { return p.longsDone.length >= 3; } },
  { id: 'level_1',    icon: '🚩', title: 'أَوَّل خُطْوَة',      desc: 'أتمّ أول مرحلة',               test: function (p) { return Object.keys(p.levels).filter(function (k) { return p.levels[k].done; }).length >= 1; } },
  { id: 'level_all',  icon: '🏆', title: 'بَطَلَة المَمْلَكَة', desc: 'أتمّ كل المراحل',              test: function (p) { return Object.keys(p.levels).filter(function (k) { return p.levels[k].done; }).length >= LOLO.LEVELS.length; } },
  { id: 'explorer',   icon: '🧭', title: 'المُسْتَكْشِف',       desc: 'العب كل الألعاب الثمانية',      test: function (p) { return Object.keys(p.gamesPlayed).length >= 8; } },
  { id: 'perfect',    icon: '💯', title: 'بِلا أَخْطَاء',        desc: 'أتمّ لعبة بدون أي خطأ',         test: function (p) { return p.perfectGames >= 1; } }
];
