/* ==========================================================
   js/voicemap.js — ONE place that defines every spoken line:
   its file name (key) and its Arabic text.
   - The game speaks   assets/audio/voice/<key>.mp3  when the file exists,
     otherwise the device's Arabic text-to-speech reads <text>.
   - recorder.html uses V.all() to list every line you can record.
   ========================================================== */
(function () {
  var V = {};
  V.the = function (l) { return 'ال' + l.name; };

  V.name = function (l) { return { key: 'letter_' + l.id, text: l.name }; };
  V.syl = function (l, v) { return { key: v + '_' + l.id, text: LOLO.syllable(l, v) }; };
  V.word = function (l) { return { key: 'word_' + l.id, text: l.word }; };
  V.intro = function (l) { return { key: 'intro_' + l.id, text: 'هَذَا حَرْفُ ' + V.the(l) + '، هَيَّا نَنْطِقُهُ مَعاً!' }; };
  V.askFind = function (l) { return { key: 'ask_find_' + l.id, text: 'أَيْنَ حَرْفُ ' + V.the(l) + '؟' }; };
  V.hunt = function (l) { return { key: 'ask_hunt_' + l.id, text: 'ابْحَثُوا عَنْ حَرْفِ ' + V.the(l) + ' بَيْنَ الزُّهُور!' }; };
  V.notThis = function (l) { return { key: 'notthis_' + l.id, text: 'لَيْسَ هَذَا، هَذَا حَرْفُ ' + V.the(l) + '.' }; };
  V.hintLetter = function (l) { return { key: 'hint_' + l.id, text: 'تَلْمِيح: هُوَ الحَرْفُ الَّذِي تَبْدَأُ بِهِ كَلِمَةُ ' + l.word + '.' }; };
  V.game = function (g) { return { key: 'game_' + g.id, text: g.intro }; };
  V.vowel = function (v) { return { key: 'vowel_' + v.id, text: v.intro }; };
  V.vowelTip = function (v) { return { key: 'voweltip_' + v.id, text: v.tip }; };
  V.long = function (v) { return { key: 'long_' + v.id, text: v.intro }; };
  V.longRule = function (v) { return { key: 'longrule_' + v.id, text: v.rule }; };
  V.concept = function (i) { var q = LOLO.CONCEPT_QUESTIONS[i]; return { key: 'q_' + i, text: q.q }; };
  V.conceptHint = function (i) { var q = LOLO.CONCEPT_QUESTIONS[i]; return { key: 'qhint_' + i, text: q.hint }; };
  V.fixed = {
    listen:  { key: 'ask_listen',   text: 'اسْتَمِعُوا جَيِّداً، ثُمَّ اخْتَارُوا مَا سَمِعْتُم.' },
    harakat: { key: 'ask_harakat',  text: 'اسْتَمِعُوا، ثُمَّ اخْتَارُوا الحَرْفَ مَعَ حَرَكَتِهِ.' },
    word:    { key: 'ask_word',     text: 'أَيُّ حَرْفٍ يَنْقُصُ فِي الكَلِمَة؟' },
    long:    { key: 'ask_long',     text: 'اسْتَمِعُوا إِلَى الصَّوْت: هَلْ هُوَ قَصِيرٌ أَمْ طَوِيل؟' },
    longHint:{ key: 'hint_long',    text: 'تَلْمِيح: فِي الصَّوْتِ الطَّوِيلِ حَرْفُ مَدٍّ: أَلِفٌ أَوْ وَاوٌ أَوْ يَاء.' },
    harakatHint: { key: 'hint_harakat', text: 'تَلْمِيح: انْتَبِهُوا إِلَى مَكَانِ الحَرَكَةِ وَشَكْلِهَا.' },
    listenHint:  { key: 'hint_listen',  text: 'تَلْمِيح: اضْغَطُوا عَلَى السَّمَّاعَةِ وَاسْتَمِعُوا مَرَّةً أُخْرَى.' },
    matchFirst:  { key: 'match_first',  text: 'اخْتَارُوا حَرْفاً أَوَّلاً، ثُمَّ اخْتَارُوا صُورَتَهُ.' },
    matchHint:   { key: 'match_hint',   text: 'لَيْسَتْ هَذِهِ الصُّورَة. انْتَبِهُوا إِلَى أَوَّلِ الكَلِمَة.' },
    shortLong:   { key: 'shortlong',    text: 'اسْتَمِعُوا: الصَّوْتُ القَصِير... ثُمَّ الصَّوْتُ الطَّوِيل.' },
    tapToHear:   { key: 'tap_hear',     text: 'اضْغَطُوا عَلَى أَيِّ حَرْفٍ لِتَسْمَعُوهُ.' },
    exercise:    { key: 'exercise',     text: 'هَيَّا نَتَدَرَّبْ مَعاً!' },
    findHint:    { key: 'find_hint',    text: 'ابْحَثُوا جَيِّداً، أَنْتُمْ تَسْتَطِيعُون!' }
  };
  V.say = function (id, idx) {
    var arr = LOLO.SAY[id]; if (idx === undefined) idx = Math.floor(Math.random() * arr.length);
    return { key: 'say_' + id + '_' + idx, text: arr[idx] };
  };

  /* every line in the game, for the recorder tool */
  V.all = function () {
    var out = [], seen = {};
    function add(o, group) { if (o && !seen[o.key]) { seen[o.key] = 1; out.push({ key: o.key, text: o.text, group: group }); } }
    Object.keys(LOLO.SAY).forEach(function (id) { LOLO.SAY[id].forEach(function (_, i) { add(V.say(id, i), 'حوار الأميرة'); }); });
    LOLO.LETTERS.forEach(function (l) {
      add(V.name(l), 'أسماء الحروف'); add(V.intro(l), 'تقديم الحرف');
      ['fatha', 'damma', 'kasra'].forEach(function (v) { add(V.syl(l, v), 'الحركات'); });
      ['longa', 'longu', 'longi'].forEach(function (v) { add(V.syl(l, v), 'المدود'); });
      add(V.word(l), 'الكلمات'); add(V.askFind(l), 'تعليمات الألعاب'); add(V.hunt(l), 'تعليمات الألعاب');
      add(V.notThis(l), 'تعليمات الألعاب'); add(V.hintLetter(l), 'تلميحات');
    });
    LOLO.GAMES.forEach(function (g) { add(V.game(g), 'تعليمات الألعاب'); });
    LOLO.VOWELS.forEach(function (v) { add(V.vowel(v), 'شرح الدروس'); add(V.vowelTip(v), 'شرح الدروس'); });
    LOLO.LONGS.forEach(function (v) { add(V.long(v), 'شرح الدروس'); add(V.longRule(v), 'شرح الدروس'); });
    LOLO.CONCEPT_QUESTIONS.forEach(function (_, i) { add(V.concept(i), 'أسئلة'); add(V.conceptHint(i), 'تلميحات'); });
    Object.keys(V.fixed).forEach(function (k) { add(V.fixed[k], 'تعليمات الألعاب'); });
    return out;
  };
  window.LOLO = window.LOLO || {}; LOLO.V = V;
})();
