/* ==========================================================
   js/main.js — UI helpers, Princess Lana (Guide), effects, all screens
   ========================================================== */
(function () {
  var Progress, Audio, Nav, V;
  var UI = {};

  /* ---------- tiny DOM helper ---------- */
  function addKids(el, kids) {
    kids.forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      if (Array.isArray(c)) addKids(el, c);
      else el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    });
  }
  function h(tag, props) {
    var el = document.createElement(tag);
    if (props) for (var k in props) {
      var v = props[k];
      if (v === false || v === null || v === undefined) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style') el.style.cssText = v;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v);
    }
    addKids(el, Array.prototype.slice.call(arguments, 2));
    return el;
  }
  function $(s, r) { return (r || document).querySelector(s); }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function glyph(t, cls) { return h('span', { class: 'glyph' + (cls ? ' ' + cls : '') }, t); }
  function click(fn, sound) { return function (e) { Audio.sfx(sound || 'click'); fn(e); }; }
  UI.h = h; UI.glyph = glyph; UI.shuffle = shuffle; UI.delay = delay;

  /* ==========================================================
     PRINCESS LOLO — the guide
     ========================================================== */
  var Guide = { fig: null, bubble: null, text: null, fx: null, timer: null };
  var EMOJI = { greet: '👋', clap: '👏', think: '💭', celebrate: '🎉', jump: '✨', encourage: '💪', smile: '💖' };
  Guide.init = function () {
    Guide.fig = $('#gFigure'); Guide.bubble = $('#gBubble'); Guide.text = $('#gText'); Guide.fx = $('#gFx');
    $('#gReplay').addEventListener('click', function () { Audio.sfx('pop'); Guide.setState('smile'); Audio.replay(); });
    Guide.fig.addEventListener('click', function () { Audio.sfx('pop'); Guide.setState(['jump', 'greet', 'smile', 'clap'][Math.floor(Math.random() * 4)]); });
  };
  Guide.setState = function (s) {
    var f = Guide.fig; f.className = 'g-figure'; void f.offsetWidth;
    clearTimeout(Guide.timer);
    if (!s || s === 'idle') return;
    f.classList.add('st-' + s);
    if (EMOJI[s]) {
      var sp = h('span', { style: 'left:' + (20 + Math.random() * 55) + '%' }, EMOJI[s]);
      Guide.fx.appendChild(sp); setTimeout(function () { sp.remove(); }, 1700);
    }
    if (s !== 'walk' && s !== 'think') Guide.timer = setTimeout(function () { f.className = 'g-figure'; }, 2600);
  };
  Guide.show = function (text) {
    Guide.text.textContent = text; Guide.bubble.classList.remove('pop'); void Guide.bubble.offsetWidth; Guide.bubble.classList.add('pop');
  };
  /* say(): shows the line + speaks it. Resolves true when finished, false if interrupted */
  Guide.say = function (text, opts) {
    opts = opts || {};
    Guide.show(text); Guide.setState(opts.state || 'smile');
    return Audio.say(opts.key, text).then(function (ok) { if (ok && (opts.state === 'walk' || opts.state === 'think')) Guide.setState('idle'); return ok; });
  };
  Guide.phrase = function (id, opts) { var p = V.say(id); return Guide.say(p.text, Object.assign({ key: p.key }, opts || {})); };
  UI.Guide = Guide;

  /* ==========================================================
     EFFECTS
     ========================================================== */
  var FX = {};
  FX.burst = function (x, y, emojis, n) {
    var layer = $('#fx'); n = n || 10;
    for (var i = 0; i < n; i++) {
      var p = h('span', { class: 'particle', style: 'left:' + x + 'px;top:' + y + 'px' }, emojis[Math.floor(Math.random() * emojis.length)]);
      layer.appendChild(p);
      var a = Math.random() * Math.PI * 2, d = 50 + Math.random() * 90;
      var anim = p.animate([{ transform: 'translate(-50%,-50%) scale(.4)', opacity: 1 }, { transform: 'translate(' + (Math.cos(a) * d - 12) + 'px,' + (Math.sin(a) * d - 30) + 'px) rotate(' + (Math.random() * 360) + 'deg) scale(1.1)', opacity: 0 }], { duration: 800 + Math.random() * 500, easing: 'cubic-bezier(.2,.8,.3,1)' });
      anim.onfinish = (function (el) { return function () { el.remove(); }; })(p);
    }
  };
  FX.burstAt = function (el, emojis) { if (!el || !el.getBoundingClientRect) return; var r = el.getBoundingClientRect(); FX.burst(r.left + r.width / 2, r.top + r.height / 2, emojis || ['⭐', '✨'], 10); };
  FX.confetti = function () {
    var layer = $('#fx'), W = window.innerWidth, H = window.innerHeight, em = ['🎉', '⭐', '🌸', '💖', '✨', '🦋', '🎊'];
    for (var i = 0; i < 36; i++) {
      var p = h('span', { class: 'particle', style: 'left:' + Math.random() * W + 'px;top:-30px' }, em[i % em.length]);
      layer.appendChild(p);
      var a = p.animate([{ transform: 'translateY(0) rotate(0)', opacity: 1 }, { transform: 'translateY(' + (H + 60) + 'px) translateX(' + (Math.random() * 120 - 60) + 'px) rotate(' + (Math.random() * 720 - 360) + 'deg)', opacity: .9 }], { duration: 1800 + Math.random() * 1800, delay: Math.random() * 700, easing: 'ease-in', fill: 'backwards' });
      a.onfinish = (function (el) { return function () { el.remove(); }; })(p);
    }
    if (window.gsap) { try { window.gsap.fromTo('#gFigure', { rotation: -4 }, { rotation: 4, duration: .18, repeat: 5, yoyo: true, ease: 'sine.inOut', clearProps: 'rotation' }); } catch (e) {} }
  };
  UI.FX = FX;

  UI.updateStars = function () { $('#starCount').textContent = Progress.get().stars; };
  UI.awardStar = function (fromEl) {
    var badges = Progress.addStars(1), counter = $('#starCounter'), target = counter.getBoundingClientRect();
    if (fromEl && fromEl.getBoundingClientRect) {
      var r = fromEl.getBoundingClientRect(), s = h('div', { class: 'fly-star', style: 'left:' + (r.left + r.width / 2 - 22) + 'px;top:' + (r.top + r.height / 2 - 22) + 'px' });
      $('#stage').appendChild(s);
      var dx = target.left + target.width / 2 - (r.left + r.width / 2), dy = target.top + target.height / 2 - (r.top + r.height / 2);
      var a = s.animate([{ transform: 'scale(.4)', opacity: 0 }, { transform: 'scale(1.5) translateY(-30px)', opacity: 1, offset: .25 }, { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(.5)', opacity: 1 }], { duration: 950, easing: 'ease-in-out' });
      a.onfinish = function () { Audio.sfx('star'); s.remove(); counter.classList.remove('bump'); void counter.offsetWidth; counter.classList.add('bump'); UI.updateStars(); };
    } else { UI.updateStars(); Audio.sfx('star'); }
    UI.announceBadges(badges);
  };
  UI.toast = function (msg) { var t = $('#toast'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(UI._tt); UI._tt = setTimeout(function () { t.classList.add('hidden'); }, 3200); };
  UI.announceBadges = function (list) {
    if (!list || !list.length) return;
    list.forEach(function (b, i) { setTimeout(function () { UI.toast('🏅 وسام جديد: ' + b.title); }, i * 1500); });
    setTimeout(function () { Audio.sfx('unlock'); FX.confetti(); }, 1900);
  };
  function starsRating(mistakes) { return mistakes === 0 ? 3 : mistakes <= 2 ? 2 : 1; }
  function ratingStars(n, total) {
    var row = h('div', { class: 'stars-row' }); total = total || 3;
    for (var i = 0; i < total; i++) { var im = h('img', { src: 'assets/images/star.svg', alt: '' }); im.style.animationDelay = (i * .2) + 's'; if (i >= n) im.className = 'empty'; row.appendChild(im); }
    return row;
  }

  /* ---------- common bits ---------- */
  function title(text, sub) { var f = document.createDocumentFragment(); f.appendChild(h('h2', { class: 'title' }, text)); if (sub) f.appendChild(h('p', { class: 'sub' }, sub)); return f; }
  function wordSpans(l) {
    var shaped = LOLO.shapeChunks(l);
    return shaped.map(function (t, i) { return h('span', { class: i === 0 ? 'first' : '' }, t); });
  }
  function picEl(l) {
    var em = function () { return h('span', { class: 'pic', role: 'img', 'aria-label': l.plain }, l.emoji || '🖼️'); };
    if (!l.img) return em();
    var im = h('img', { class: 'pic', src: l.img, alt: l.plain }); im.addEventListener('error', function () { if (im.parentNode) im.parentNode.replaceChild(em(), im); }); return im;
  }

  /* ==========================================================
     LESSON: ONE LETTER
     ========================================================== */
  function letterLesson(box, o) {
    var ids = o.ids, idx = o.start || 0, seq = 0, alive = Nav.alive();
    function say(obj, state) { return Audio.say(obj.key, obj.text).then(function (ok) { return ok; }); }

    function render() {
      var l = LOLO.byId(ids[idx]), f = LOLO.forms(l), my = ++seq;
      box.innerHTML = '';
      var badges = Progress.learnLetter(l.id); UI.announceBadges(badges);
      var g = glyph(l.ch);
      g.addEventListener('click', function () { g.classList.remove('boing'); void g.offsetWidth; g.classList.add('boing'); Audio.sfx('pop'); say(V.name(l)); });
      var chips = [['مُنْفَصِلَة', f.isolated], ['أَوَّلَ الكَلِمَة', f.initial], ['وَسَطَ الكَلِمَة', f.medial], ['آخِرَ الكَلِمَة', f.final]].map(function (c) {
        return h('div', { class: 'form-chip' }, glyph(c[1]), h('small', null, c[0]));
      });
      var wordEl = h('div', { class: 'glyph word', onclick: function () { Audio.sfx('pop'); say(V.word(l)); } }, wordSpans(l));
      var picture = h('div', { class: 'card picture-card' }, h('div', { onclick: function () { Audio.sfx('pop'); say(V.word(l)); } }, picEl(l)), wordEl);
      var nameRow = h('div', { class: 'say-row' },
        h('button', { class: 'btn purple small', onclick: click(function () { say(V.name(l)); }, 'pop') }, '🔊 اسْمُ الحَرْف'),
        h('button', { class: 'btn mint small', onclick: click(function () { say(V.syl(l, 'fatha')); }, 'pop') }, '🔊 صَوْتُهُ: ' + LOLO.syllable(l, 'fatha')),
        h('button', { class: 'btn gold small', onclick: click(function () { playIntro(l, my); }, 'pop') }, '🗣️ هَيَّا نَنْطِقُهُ مَعاً'));
      var dots = h('div', { class: 'dots' }, ids.map(function (_, i) { return h('i', { class: i < idx ? 'done' : (i === idx ? 'now' : '') }); }));
      var last = idx === ids.length - 1;
      var nav = h('div', { class: 'nav-row' },
        h('button', { class: 'btn', disabled: idx === 0 ? 'disabled' : false, onclick: click(function () { idx--; render(); }) }, '▶ السَّابِق'),
        h('button', { class: 'btn primary', onclick: click(function () { if (last) o.onFinish && o.onFinish(); else { idx++; render(); } }, 'whoosh') }, last ? (o.finishLabel || 'أَحْسَنْتُم ✅') : 'التَّالِي ◀'));
      box.append(
        h('div', { class: 'lesson-top' }, h('div', { class: 'card big-letter' }, g, h('div', { class: 'letter-name' }, 'حَرْفُ ' + V.the(l)), nameRow), picture),
        h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, 'أَشْكَالُ الحَرْف'), h('div', { class: 'forms' }, chips)),
        dots, nav);
      box.parentNode.scrollTop = 0;
      playIntro(l, my);
    }
    function playIntro(l, my) {
      var i = V.intro(l);
      Guide.say(i.text, { key: i.key, state: 'greet' }).then(function (ok) {
        if (!ok || !alive() || my !== seq) return; return say(V.name(l));
      }).then(function (ok) {
        if (!ok || !alive() || my !== seq) return; return say(V.syl(l, 'fatha'));
      }).then(function (ok) {
        if (!ok || !alive() || my !== seq) return; return say(V.word(l));
      });
    }
    render();
  }

  /* ==========================================================
     LESSON: SHORT VOWEL (3 steps: see it → hear it → practise)
     ========================================================== */
  function vowelLesson(box, o) {
    var vd = LOLO.VOWELS.filter(function (v) { return v.id === o.vowel; })[0], alive = Nav.alive();
    function step1() {
      box.innerHTML = '';
      var demoL = LOLO.byId(8);   // د — a dot-free letter makes the mark easy to see
      var syl = glyph(LOLO.syllable(demoL, vd.id), 'demo-letter');
      syl.style.color = vd.color; syl.style.opacity = 0;
      var bare = glyph(demoL.ch, 'demo-letter');
      var markBig = h('span', { class: 'glyph demo-mark', style: 'position:static;color:' + vd.color + ';transform:none;opacity:0' }, '\u25CC' + vd.mark);
      var plus = h('span', { class: 'glyph', style: 'font-size:clamp(40px,12vw,70px);color:var(--ink-soft)' }, '+');
      var eq = h('span', { class: 'glyph', style: 'font-size:clamp(40px,12vw,70px);color:var(--ink-soft)' }, '=');
      var eqRow = h('div', { style: 'display:flex;align-items:center;justify-content:center;gap:clamp(6px,3vw,20px);direction:rtl' }, bare, plus, markBig, eq, syl);
      var up = vd.place === 'above';
      var label = h('div', { class: 'demo-label', style: 'color:' + vd.color + ';position:static;transform:none;margin:6px auto;width:max-content' }, (up ? '⬇ ' : '⬆ ') + vd.name + ' ' + vd.where);
      var card = h('div', { class: 'card', style: 'text-align:center' }, h('h2', { class: 'title', style: 'color:' + vd.color }, vd.name), eqRow, label,
        h('div', { class: 'sub' }, 'الصَّوْتُ: ' + vd.sound));
      var play = h('button', { class: 'btn purple', onclick: click(function () { Audio.say(V.syl(demoL, vd.id).key, V.syl(demoL, vd.id).text); }, 'pop') }, '🔊 اسْتَمِعْ: ' + LOLO.syllable(demoL, vd.id));
      var go = h('button', { class: 'btn primary', onclick: click(step2, 'whoosh') }, 'هَيَّا نُجَرِّب ◀');
      box.append(card, h('div', { class: 'row-btns' }, play, go));
      markBig.animate([{ opacity: 0, transform: 'translateY(' + (up ? '-60px' : '60px') + ') scale(2)' }, { opacity: 1, transform: 'translateY(0) scale(1)' }], { duration: 900, delay: 400, fill: 'forwards', easing: 'cubic-bezier(.3,1.5,.5,1)' });
      syl.animate([{ opacity: 0, transform: 'scale(.4)' }, { opacity: 1, transform: 'scale(1.15)' }, { opacity: 1, transform: 'scale(1)' }], { duration: 800, delay: 1400, fill: 'forwards' });
      Guide.say(vd.intro, { key: V.vowel(vd).key, state: 'greet' }).then(function (ok) { if (ok && alive()) return Audio.say(V.syl(demoL, vd.id).key, V.syl(demoL, vd.id).text); });
    }
    function step2() {
      box.innerHTML = '';
      var grid = h('div', { class: 'syl-grid' });
      LOLO.LETTERS.forEach(function (l) {
        var b = h('button', { class: 'syl', onclick: function () { Audio.sfx('pop'); b.classList.add('on'); setTimeout(function () { b.classList.remove('on'); }, 350); var s = V.syl(l, vd.id); Audio.say(s.key, s.text); } }, glyph(LOLO.syllable(l, vd.id)));
        b.firstChild.style.color = vd.color; grid.appendChild(b);
      });
      box.append(h('h2', { class: 'title', style: 'color:' + vd.color }, 'اسْمَعُوا مَعَ ' + vd.name), h('p', { class: 'sub' }, vd.tip), grid,
        h('div', { class: 'row-btns' }, h('button', { class: 'btn primary', onclick: click(step3, 'whoosh') }, 'هَيَّا نَتَدَرَّب ◀')));
      var t = V.fixed.tapToHear; Guide.say(t.text, { key: t.key, state: 'smile' });
    }
    function step3() {
      box.innerHTML = '';
      var q = h('div'); box.appendChild(q);
      var ex = V.fixed.exercise; Guide.say(ex.text, { key: ex.key, state: 'clap' });
      LOLO.Games.quiz(q, { kinds: ['harakat'], vowel: vd.id, rounds: LOLO.ROUNDS.levelQuiz, onDone: function (res) {
        var badges = Progress.doneVowel(vd.id); UI.announceBadges(badges);
        o.onFinish && o.onFinish(res);
      } });
    }
    step1();
  }

  /* ==========================================================
     LESSON: LONG VOWEL (3 steps)
     ========================================================== */
  function longLesson(box, o) {
    var lt = LOLO.LONGS.filter(function (v) { return v.id === o.long; })[0], alive = Nav.alive();
    var demo = LOLO.byId(2);   // ب
    function step1() {
      box.innerHTML = '';
      var sh = LOLO.syllable(demo, lt.short), lg = LOLO.syllable(demo, lt.id);
      function side(txt, kind, label, obj) {
        var g = glyph(txt); g.style.color = lt.color;
        var c = h('div', { class: 'card lc', onclick: function () { Audio.sfx('pop'); Audio.say(obj.key, obj.text); } }, g, h('div', { class: 'bar ' + kind }), h('small', null, label));
        return c;
      }
      box.append(h('h2', { class: 'title', style: 'color:' + lt.color }, lt.name),
        h('div', { class: 'long-compare' }, side(sh, 'short', 'صَوْتٌ قَصِير', V.syl(demo, lt.short)), side(lg, 'long', 'صَوْتٌ طَوِيل', V.syl(demo, lt.id))),
        h('div', { class: 'card', style: 'text-align:center;font-weight:800' }, lt.rule),
        h('div', { class: 'row-btns' },
          h('button', { class: 'btn purple', onclick: click(function () { var s = V.fixed.shortLong; Guide.say(s.text, { key: s.key, state: 'think' }).then(function (ok) { if (!ok) return; return Audio.say(V.syl(demo, lt.short).key, V.syl(demo, lt.short).text); }).then(function (ok) { if (ok === false) return; return delay(300); }).then(function () { if (alive()) return Audio.say(V.syl(demo, lt.id).key, V.syl(demo, lt.id).text); }); }, 'pop') }, '🔊 قَصِير ثُمَّ طَوِيل'),
          h('button', { class: 'btn primary', onclick: click(step2, 'whoosh') }, 'هَيَّا نُجَرِّب ◀')));
      Guide.say(lt.intro, { key: V.long(lt).key, state: 'greet' });
    }
    function step2() {
      box.innerHTML = '';
      var grid = h('div', { class: 'syl-grid' });
      LOLO.LETTERS.forEach(function (l) {
        var b = h('button', { class: 'syl', onclick: function () { Audio.sfx('pop'); b.classList.add('on'); setTimeout(function () { b.classList.remove('on'); }, 350); var s = V.syl(l, lt.id); Audio.say(s.key, s.text); } }, glyph(LOLO.syllable(l, lt.id)));
        b.firstChild.style.color = lt.color; grid.appendChild(b);
      });
      box.append(h('h2', { class: 'title', style: 'color:' + lt.color }, 'اسْمَعُوا ' + lt.name), h('p', { class: 'sub' }, lt.rule), grid,
        h('div', { class: 'row-btns' }, h('button', { class: 'btn primary', onclick: click(step3, 'whoosh') }, 'هَيَّا نَتَدَرَّب ◀')));
      var t = V.fixed.tapToHear; Guide.say(t.text, { key: t.key, state: 'smile' });
    }
    function step3() {
      box.innerHTML = ''; var q = h('div'); box.appendChild(q);
      var ex = V.fixed.exercise; Guide.say(ex.text, { key: ex.key, state: 'clap' });
      LOLO.Games.quiz(q, { kinds: ['long'], long: lt.id, rounds: LOLO.ROUNDS.levelQuiz, onDone: function (res) {
        var badges = Progress.doneLong(lt.id); UI.announceBadges(badges);
        o.onFinish && o.onFinish(res);
      } });
    }
    step1();
  }

  /* ==========================================================
     LEVEL COMPLETE
     ========================================================== */
  function levelComplete(box, idx, res) {
    var lv = LOLO.LEVELS[idx], rating = starsRating(res ? res.mistakes || 0 : 0);
    var wasLocked = LOLO.LEVELS[idx + 1] ? !Progress.isLevelUnlocked(idx + 1) : false;
    var badges = Progress.completeLevel(lv.id, rating);
    var next = LOLO.LEVELS[idx + 1];
    box.innerHTML = '';
    box.append(h('div', { class: 'card result' },
      h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }),
      h('h2', { class: 'title' }, 'أَتْمَمْتُمُ المَرْحَلَة!'), h('p', { class: 'sub' }, lv.title + ' ' + lv.emoji),
      ratingStars(rating),
      h('div', { class: 'row-btns' },
        next ? h('button', { class: 'btn primary', onclick: click(function () { Nav.go('level', { idx: idx + 1 }, { replace: true }); }, 'whoosh') }, 'المَرْحَلَةُ التَّالِيَة ◀') : null,
        h('button', { class: 'btn purple', onclick: click(function () { Nav.go('map', {}, { replace: true }); }) }, '🗺️ الخَرِيطَة'))));
    Audio.sfx('levelup'); FX.confetti(); Guide.phrase('levelDone', { state: 'celebrate' });
    if (wasLocked && Progress.isLevelUnlocked(idx + 1)) setTimeout(function () { Audio.sfx('unlock'); }, 250);   // special unlock sound (badge sound is dropped if it would overlap)
    UI.announceBadges(badges);
    if (!next) UI.toast('👑 أَتْمَمْتُمُ المَمْلَكَةَ كُلَّهَا!');
  }

  /* ==========================================================
     SCREENS
     ========================================================== */
  function registerScreens() {
    /* ----- splash: tap to enter (browsers need a tap before sound) ----- */
    Nav.register('splash', function (box) {
      Guide.show('اضْغَطُوا عَلَى البَوَّابَةِ السِّحْرِيَّةِ لِنَدْخُلَ المَمْلَكَة! ✨');
      var gate = h('button', { class: 'gate-btn', onclick: function () { Audio.unlock(); Audio.sfx('magic'); FX.burstAt(gate, ['✨', '⭐', '🦋', '💖']); setTimeout(function () { Nav.go('home', { welcome: true }, { replace: true }); }, 450); } },
        h('img', { src: 'assets/images/gate.svg', alt: '' }), h('span', null, 'ادْخُلُوا المَمْلَكَة'));
      box.append(h('div', { class: 'logo' }, h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }),
        h('h1', { class: 'title' }, LOLO.CONFIG.title), h('span', { class: 'l1' }, LOLO.CONFIG.subtitle)), gate);
      box.classList.add('splash');
    }, { theme: 'home' });

    /* ----- home ----- */
    Nav.register('home', function (box, p) {
      var next = Progress.nextLevelIndex();
      var btn = function (cls, ico, txt, fn) { return h('button', { class: 'menu-btn ' + cls, onclick: click(fn, 'whoosh') }, h('span', { class: 'ico' }, ico), h('span', null, txt)); };
      box.append(
        h('div', { class: 'logo' }, h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }), h('h1', { class: 'title' }, LOLO.CONFIG.title), h('span', { class: 'l1' }, LOLO.CONFIG.subtitle)),
        h('div', { class: 'menu-grid' },
          btn('m1 big', '🏰', Progress.levelsDone() > 0 ? 'تَابِعِ المُغَامَرَة' : 'ابْدَأِ المُغَامَرَة', function () { Nav.go('map'); }),
          btn('m2', '🌷', 'مَمْلَكَةُ الحُرُوف', function () { Nav.go('letters'); }),
          btn('m3', '✨', 'مَمْلَكَةُ الحَرَكَات', function () { Nav.go('vowels'); }),
          btn('m5', '🌈', 'مَمْلَكَةُ المُدُود', function () { Nav.go('longs'); }),
          btn('m4', '🎮', 'الأَلْعَابُ وَالتَّحَدِّيَات', function () { Nav.go('games'); }),
          h('button', { class: 'menu-btn ach', onclick: click(function () { Nav.go('achievements'); }, 'whoosh') }, h('span', { class: 'ico' }, '🏆'), h('span', null, 'إِنْجَازَاتِي'))));
      if (p && p.welcome) { var w = V.say('welcome', 0); Guide.say(w.text, { key: w.key, state: 'greet' }); } else Guide.phrase('home', { state: 'greet' });
    }, { theme: 'home' });

    /* ----- adventure map ----- */
    Nav.register('map', function (box) {
      var cur = Progress.nextLevelIndex();
      var map = h('div', { class: 'map' });
      LOLO.LEVELS.forEach(function (lv, i) {
        var done = Progress.isLevelDone(lv.id), unlocked = Progress.isLevelUnlocked(i), st = (Progress.get().levels[lv.id] || {}).stars || 0;
        var bubble = h('div', { class: 'm-bubble' }, lv.emoji, i === cur && !done ? h('div', { class: 'm-face' }) : null, !unlocked ? h('span', { class: 'lock' }, '🔒') : null);
        var node = h('button', { class: 'm-node' + (done ? ' done' : '') + (!unlocked ? ' locked' : '') + (i === cur ? ' current' : ''), onclick: click(function () { Nav.go('level', { idx: i }); }, 'whoosh') },
          bubble, h('div', { class: 'm-info' }, (i + 1) + '. ' + lv.title, h('small', null, done ? '⭐'.repeat(st) + '☆'.repeat(3 - st) : (unlocked ? 'جَاهِزَة!' : 'مُقْفَلَة'))));
        map.appendChild(node);
      });
      box.append(title('خَرِيطَةُ المُغَامَرَة', 'اتَّبِعُوا الطَّرِيقَ السِّحْرِيَّ خُطْوَةً خُطْوَة'), map);
      Guide.phrase('mapK', { state: 'greet' });
      setTimeout(function () { var c = box.querySelector('.current'); if (c) c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 400);
    }, { theme: 'map' });

    /* ----- level runner ----- */
    Nav.register('level', function (box, p) {
      var idx = p.idx, lv = LOLO.LEVELS[idx], body = h('div'); box.append(body);
      $('#tbTitle').textContent = lv.title;
      var res;
      function finish(r) { res = r; levelComplete(body, idx, r); }
      if (lv.kind === 'letters') {
        var st = V.say('start'); Guide.say(st.text, { key: st.key, state: 'jump' });
        letterLesson(body, { ids: lv.letters, finishLabel: 'هَيَّا إِلَى الاخْتِبَار ✅', onFinish: function () {
          body.innerHTML = ''; var q = h('div'); body.appendChild(q);
          var ex = V.fixed.exercise; Guide.say(ex.text, { key: ex.key, state: 'clap' });
          LOLO.Games.quiz(q, { pool: lv.letters, kinds: ['find', 'listen', 'word', 'harakat', 'find'], rounds: LOLO.ROUNDS.levelQuiz, onDone: finish });
        } });
      } else if (lv.kind === 'vowel') vowelLesson(body, { vowel: lv.vowel, onFinish: finish });
      else if (lv.kind === 'long') longLesson(body, { long: lv.long, onFinish: finish });
      else {
        var g = LOLO.GAMES.filter(function (x) { return x.id === 'challenge'; })[0];
        Guide.say(g.intro, { key: V.game(g).key, state: 'celebrate' });
        body.append(h('div', { class: 'card result' }, h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }), h('h2', { class: 'title' }, 'تَحَدِّي الأَمِيرَة'), h('p', { class: 'sub' }, 'أَسْئِلَةٌ مِنْ كُلِّ الدُّرُوس'),
          h('button', { class: 'btn primary', onclick: click(function () { body.innerHTML = ''; var q = h('div'); body.appendChild(q); LOLO.Games.run('challenge', q, { embedded: true, onDone: finish }); }, 'whoosh') }, 'ابْدَأِ التَّحَدِّي ◀')));
      }
    }, { theme: 'map' });

    /* ----- letters kingdom ----- */
    Nav.register('letters', function (box) {
      var P = Progress.get(), grid = h('div', { class: 'letter-grid' });
      LOLO.LETTERS.forEach(function (l, i) {
        grid.appendChild(h('button', { class: 'letter-tile' + (P.lettersLearned.indexOf(l.id) >= 0 ? ' learned' : ''), onclick: click(function () { Nav.go('letter', { ids: LOLO.LETTERS.map(function (x) { return x.id; }), start: i }); }, 'pop') },
          h('span', { class: 'num' }, i + 1), glyph(l.ch), h('span', { class: 'em' }, l.img ? '' : l.emoji)));
      });
      box.append(title('مَمْلَكَةُ الحُرُوف', 'تَعَلَّمْتُمْ ' + P.lettersLearned.length + ' مِنْ ٢٨ حَرْفاً'), grid,
        h('div', { class: 'row-btns' }, h('button', { class: 'btn primary', onclick: click(function () { Nav.go('letter', { ids: LOLO.LETTERS.map(function (x) { return x.id; }), start: 0 }); }, 'whoosh') }, '▶ ابْدَأْ مِنَ الأَلِف')));
      Guide.phrase('lettersK', { state: 'greet' });
    }, { theme: 'letters' });
    Nav.register('letter', function (box, p) {
      letterLesson(box, { ids: p.ids, start: p.start, onFinish: function () { Audio.sfx('levelup'); FX.confetti(); Nav.go('letters', {}, { replace: true }); } });
    }, { theme: 'letters' });

    /* ----- vowels kingdom ----- */
    Nav.register('vowels', function (box) {
      var P = Progress.get(), cards = h('div', { class: 'k-cards' });
      var demo = LOLO.byId(2);
      LOLO.VOWELS.forEach(function (v) {
        cards.appendChild(h('button', { class: 'k-card' + (P.vowelsDone.indexOf(v.id) >= 0 ? ' done' : ''), style: 'background:linear-gradient(160deg,' + v.color + 'cc,' + v.color + ');box-shadow:0 7px 0 rgba(0,0,0,.2)', onclick: click(function () { Nav.go('vowel', { id: v.id }); }, 'whoosh') },
          glyph(LOLO.syllable(demo, v.id)), h('div', null, h('b', null, v.name), h('small', null, v.where))));
      });
      cards.appendChild(h('button', { class: 'k-card', style: 'background:linear-gradient(160deg,#ffd36a,#ff9f2e);box-shadow:0 7px 0 rgba(0,0,0,.2)', onclick: click(function () { Nav.go('vowel', { id: 'compare' }); }, 'whoosh') },
        glyph('بَ بُ بِ'), h('div', null, h('b', null, 'نُقَارِن'), h('small', null, 'الثَّلَاثُ مَعاً'))));
      box.append(title('مَمْلَكَةُ الحَرَكَات', 'الفَتْحَةُ وَالضَّمَّةُ وَالكَسْرَة'), cards);
      Guide.phrase('vowelsK', { state: 'greet' });
    }, { theme: 'vowels' });
    Nav.register('vowel', function (box, p) {
      if (p.id === 'compare') {
        var demo = LOLO.byId(2), row = h('div', { class: 'syl-grid', style: 'grid-template-columns:repeat(3,1fr)' });
        LOLO.VOWELS.forEach(function (v) { var b = h('button', { class: 'syl', onclick: function () { Audio.sfx('pop'); var s = V.syl(demo, v.id); Audio.say(s.key, s.text); } }, glyph(LOLO.syllable(demo, v.id)), h('small', { style: 'font-weight:900;color:' + v.color }, v.name)); b.firstChild.style.color = v.color; row.appendChild(b); });
        var q = h('div');
        box.append(title('نُقَارِنُ بَيْنَ الحَرَكَات', 'اضْغَطُوا وَاسْتَمِعُوا إِلَى الفَرْق'), row, h('div', { class: 'sub' }, 'ثُمَّ تَدَرَّبُوا:'), q);
        Guide.say('اسْتَمِعُوا إِلَى الفَرْقِ بَيْنَ الفَتْحَةِ وَالضَّمَّةِ وَالكَسْرَة.', { key: 'compare_intro', state: 'think' });
        LOLO.Games.run('harakat', q, { embedded: false, rounds: 6 });
      } else vowelLesson(box, { vowel: p.id, onFinish: function () { Audio.sfx('levelup'); FX.confetti(); Guide.phrase('levelDone', { state: 'celebrate' }); box.innerHTML = ''; box.append(h('div', { class: 'card result' }, h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }), h('h2', { class: 'title' }, 'أَحْسَنْتُم!'), h('div', { class: 'row-btns' }, h('button', { class: 'btn primary', onclick: click(function () { Nav.go('vowels', {}, { replace: true }); }) }, 'مَمْلَكَةُ الحَرَكَات')))); } });
    }, { theme: 'vowels' });

    /* ----- long vowels kingdom ----- */
    Nav.register('longs', function (box) {
      var P = Progress.get(), cards = h('div', { class: 'k-cards' }), demo = LOLO.byId(2);
      LOLO.LONGS.forEach(function (v) {
        cards.appendChild(h('button', { class: 'k-card' + (P.longsDone.indexOf(v.id) >= 0 ? ' done' : ''), style: 'background:linear-gradient(160deg,' + v.color + 'cc,' + v.color + ');box-shadow:0 7px 0 rgba(0,0,0,.2)', onclick: click(function () { Nav.go('long', { id: v.id }); }, 'whoosh') },
          glyph(LOLO.syllable(demo, v.id)), h('div', null, h('b', null, v.name), h('small', null, 'بَعْدَ ' + (v.short === 'fatha' ? 'الفَتْحَة' : v.short === 'damma' ? 'الضَّمَّة' : 'الكَسْرَة')))));
      });
      box.append(title('مَمْلَكَةُ المُدُود', 'نُطِيلُ الصَّوْتَ مَعَ الأَلِفِ وَالوَاوِ وَاليَاء'), cards);
      Guide.phrase('longK', { state: 'greet' });
    }, { theme: 'long' });
    Nav.register('long', function (box, p) {
      longLesson(box, { long: p.id, onFinish: function () { Audio.sfx('levelup'); FX.confetti(); Guide.phrase('levelDone', { state: 'celebrate' }); box.innerHTML = ''; box.append(h('div', { class: 'card result' }, h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }), h('h2', { class: 'title' }, 'أَحْسَنْتُم!'), h('div', { class: 'row-btns' }, h('button', { class: 'btn primary', onclick: click(function () { Nav.go('longs', {}, { replace: true }); }) }, 'مَمْلَكَةُ المُدُود')))); } });
    }, { theme: 'long' });

    /* ----- games hub + game ----- */
    Nav.register('games', function (box) {
      var grid = h('div', { class: 'games-grid' });
      LOLO.GAMES.forEach(function (g) {
        var n = Progress.get().gamesPlayed[g.id] || 0;
        grid.appendChild(h('button', { class: 'game-card', style: 'background:linear-gradient(160deg,' + g.color + 'dd,' + g.color + ')', onclick: click(function () { Nav.go('game', { id: g.id }); }, 'whoosh') },
          h('span', { class: 'ico' }, g.icon), h('span', null, g.title), h('small', null, n ? 'لَعِبْتُمْ ' + n + ' مَرَّة' : 'جَدِيدَة!')));
      });
      box.append(title('الأَلْعَابُ وَالتَّحَدِّيَات', 'اخْتَارُوا لُعْبَةً مُمْتِعَة'), grid);
      Guide.phrase('gamesK', { state: 'jump' });
    }, { theme: 'games' });
    Nav.register('game', function (box, p) {
      var g = LOLO.GAMES.filter(function (x) { return x.id === p.id; })[0];
      $('#tbTitle').textContent = g.title;
      var area = h('div');
      var start = h('button', { class: 'btn primary', onclick: click(function () { var st = V.say('start'); area.innerHTML = ''; Guide.say(st.text, { key: st.key, state: 'jump' }); setTimeout(function () { if (Nav.screens && Nav.current && Nav.current.name === 'game') LOLO.Games.run(g.id, area, {}); }, 500); }, 'whoosh') }, 'ابْدَأِ اللَّعِب ◀');
      area.append(h('div', { class: 'card result' }, h('div', { style: 'font-size:84px', class: 'q-media' }, g.icon), h('h2', { class: 'title' }, g.title), h('p', { class: 'sub' }, g.intro), start));
      box.append(area);
      Guide.say(g.intro, { key: V.game(g).key, state: 'greet' });
    }, { theme: 'games' });

    /* ----- achievements ----- */
    Nav.register('achievements', function (box) {
      var P = Progress.get(), grid = h('div', { class: 'badges' });
      LOLO.BADGES.forEach(function (b) {
        var got = P.badges.indexOf(b.id) >= 0;
        grid.appendChild(h('div', { class: 'badge' + (got ? '' : ' locked') }, h('span', { class: 'ico' }, got ? b.icon : '🔒'), h('b', null, b.title), h('small', null, b.desc)));
      });
      var hold = h('button', { class: 'btn small hold-btn' }, h('i'), '👨‍👩‍👧 مِنْطَقَةُ الأَهْلِ وَالمُعَلِّمِين (اضْغَطْ مُطَوَّلاً)');
      var timer = null, bar = hold.firstChild;
      function startHold() { bar.style.transition = 'transform 1.4s linear'; bar.style.transform = 'scaleX(1)'; timer = setTimeout(function () { Nav.go('parent'); }, LOLO.CONFIG.parentHoldMs || 1400); }
      function stopHold() { clearTimeout(timer); bar.style.transition = 'none'; bar.style.transform = 'scaleX(0)'; }
      ['pointerdown'].forEach(function (e) { hold.addEventListener(e, startHold); });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (e) { hold.addEventListener(e, stopHold); });
      box.append(title('إِنْجَازَاتِي'),
        h('div', { class: 'stat-strip' },
          h('div', { class: 'stat' }, h('b', null, P.stars), h('small', null, '⭐ نُجُوم')),
          h('div', { class: 'stat' }, h('b', null, P.lettersLearned.length + '/٢٨'), h('small', null, '🌷 حُرُوف')),
          h('div', { class: 'stat' }, h('b', null, Progress.levelsDone() + '/' + LOLO.LEVELS.length), h('small', null, '🏰 مَرَاحِل'))),
        h('div', { class: 'sub' }, 'الأَوْسِمَة: ' + P.badges.length + ' / ' + LOLO.BADGES.length), grid,
        h('div', { class: 'row-btns' }, hold));
      Guide.phrase('achieveK', { state: 'clap' });
    }, { theme: 'map' });

    /* ----- parent / teacher area ----- */
    Nav.register('parent', function (box) {
      var P = Progress.get();
      var overall = Math.round((P.lettersLearned.length / 28 * 40) + (P.vowelsDone.length / 3 * 20) + (P.longsDone.length / 3 * 20) + (Progress.levelsDone() / LOLO.LEVELS.length * 20));
      function bar(pct) { var i = h('i'); i.style.width = pct + '%'; return h('div', { class: 'progress-bar pbar' }, i); }
      function row(label, val, pct) { return h('div', { class: 'p-row' }, h('span', null, label), h('span', null, val), pct !== undefined ? bar(pct) : null); }
      var chips = h('div', { class: 'chips' }, LOLO.LETTERS.map(function (l) { return h('span', { class: 'chip' + (P.lettersLearned.indexOf(l.id) >= 0 ? ' on' : '') }, l.ch); }));
      var gameRows = LOLO.GAMES.map(function (g) { return row(g.icon + ' ' + g.title, (P.gamesPlayed[g.id] || 0) + ' مرة'); });
      var levelRows = LOLO.LEVELS.map(function (lv) { var d = P.levels[lv.id]; return row(lv.emoji + ' ' + lv.title, d && d.done ? '✅ ' + '⭐'.repeat(d.stars) : '—'); });
      var vs = Audio.voiceStatus();
      var voiceCard = h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, '🎙️ مَصْدَرُ صَوْتِ الأَمِيرَة'),
        h('div', { class: 'p-table' },
          row('تَسْجِيلَاتٌ حَقِيقِيَّة', vs.recorded + ' / ' + vs.total + ' جُمْلَة'),
          row('صَوْتُ الجِهَازِ العَرَبِيّ (قِرَاءَةٌ آلِيَّة)', vs.tts === true ? 'مُتَوَفِّر' : (vs.deviceWorked ? 'يَعْمَل' : 'لَمْ يُكْتَشَفْ فِي القَائِمَة (انْظُرُوا التَّشْخِيصَ أَدْنَاه)')),
          row('نَوْعُ صَوْتِ الجِهَازِ', vs.voiceName ? (vs.voiceName + (vs.female ? ' (أُنْثَوِيّ)' : ' (قَدْ لَا يَكُونَ أُنْثَوِيّاً)')) : '—'),
          row('صَوْتٌ عَرَبِيٌّ عَبْرَ الإِنْتَرْنِت (احْتِيَاطِيّ)', (vs.online ? 'مُفَعَّل' : 'مُعَطَّل') + (vs.onlineWorked ? ' — عَمِلَ ✅' : '')),
          h('div', { class: 'sub', style: 'text-align:right' }, vs.recorded < vs.total ? 'الجُمَلُ غَيْرُ المُسَجَّلَةِ تُقْرَأُ بِصَوْتِ الجِهَازِ وَقَدْ لَا يَكُونُ نُطْقُهَا دَقِيقاً. اسْتَخْدِمُوا recorder.html لِتَسْجِيلِ صَوْتٍ حَقِيقِيّ.' : 'كُلُّ الجُمَلِ مُسَجَّلَة ✅')));
      var diagBox = h('div', { class: 'card', style: 'direction:ltr;text-align:left;font:13px/1.5 monospace' });
      function renderDiag() {
        var d = Audio.diagnose(); diagBox.innerHTML = '';
        function ln(txt, cls) { diagBox.appendChild(h('div', cls ? { style: 'color:' + cls } : null, txt)); }
        ln('speechSynthesis in browser: ' + d.hasSS, d.hasSS ? '#2a7' : '#c33');
        ln('secure context (https/localhost): ' + d.secure);
        ln('running inside a frame (e.g. Claude preview): ' + d.inFrame, d.inFrame ? '#c80' : null);
        ln('user activation: ' + (d.activation ? 'active=' + d.activation.active + ' hasBeenActive=' + d.activation.hasBeenActive : 'n/a'));
        ln('voiceschanged events seen: ' + d.voicesChangedEvents + ' | online: ' + d.online);
        ln('voices returned by getVoices(): ' + d.voices.length, d.voices.length ? '#2a7' : '#c33');
        d.voices.forEach(function (v) { ln((v.chosen ? '★ ' : '• ') + v.name + '  [' + v.lang + ']  ' + (v.local ? 'local' : 'network') + (v.arabic ? '  ARABIC' : ''), v.arabic ? '#2a7' : null); });
        if (d.voices.length && !d.voices.some(function (v) { return v.arabic; })) ln('→ voices exist but none has an Arabic language code', '#c33');
        if (!d.voices.length) ln('→ the list is empty: the browser/frame hides its voices. Use the tests below - speech can still work.', '#c80');
        ln('UA: ' + d.ua.slice(0, 120));
      }
      var testOut = h('div', { style: 'direction:ltr;text-align:left;font:13px/1.5 monospace;margin-top:6px' });
      function logT(txt) { testOut.appendChild(h('div', null, txt)); }
      function runTest(lang) { logT('… testing ' + lang); Audio.testSpeak(lang, function (r) { logT((r.started ? '✅ ' : '❌ ') + 'speak lang=' + r.lang + ' started=' + r.started + ' ended=' + r.ended + ' error=' + (r.error || 'none') + ' (' + r.ms + ' ms)'); renderDiag(); }); }
      renderDiag(); setTimeout(renderDiag, 1500); setTimeout(renderDiag, 5000);
      var diagCard = h('div', null,
        h('div', { class: 'sub', style: 'margin:10px 0 6px' }, '🔧 تَشْخِيصُ الصَّوْت (للمُطَوِّر)'),
        diagBox,
        h('div', { class: 'row-btns' },
          h('button', { class: 'btn small no-print', onclick: function () { runTest('ar-SA'); } }, '🔊 test ar-SA'),
          h('button', { class: 'btn small no-print', onclick: function () { runTest('ar'); } }, '🔊 test ar'),
          h('button', { class: 'btn small no-print', onclick: function () { runTest('voice'); } }, '🔊 test chosen voice'),
          h('button', { class: 'btn small no-print', onclick: function () { logT('… testing online voice'); Audio.testOnline(function (r) { logT((r.started ? '✅ ' : '❌ ') + 'online voice started=' + r.started + ' error=' + (r.error || 'none')); }); } }, '🌐 test online'),
          h('button', { class: 'btn small no-print', onclick: function () { renderDiag(); } }, '🔄 refresh')),
        testOut);
      var labLetter = LOLO.LETTERS[1], labBtns = [], labOut = h('div', { style: 'direction:ltr;text-align:left;font:12px/1.5 monospace;margin-top:6px' });
      var styleNames = { plain: 'plain (no change)', rate: 'rate (short fast / long slow)', stretch: 'stretch (recommended)', extra: 'extra (long = 3 madd letters)' };
      var labSel = h('select', { style: 'font:16px sans-serif;padding:6px;margin:4px', onchange: function () { labLetter = LOLO.LETTERS[+labSel.value]; labBtns.forEach(function (b) { b.el.textContent = LOLO.syllable(labLetter, b.vid); }); } },
        LOLO.LETTERS.map(function (l, i) { var o = h('option', { value: i }, l.ch + '  ' + l.plain); if (i === 1) o.selected = true; return o; }));
      var styleRow = h('div', { style: 'direction:ltr;text-align:left;font:14px sans-serif' }, Object.keys(styleNames).map(function (k) {
        var r = h('input', { type: 'radio', name: 'vstyle', id: 'vs_' + k, style: 'margin:6px' }); if (Audio.vowelStyle === k) r.checked = true;
        r.addEventListener('change', function () { Audio.setVowelStyle(k); labOut.textContent = 'saved style: ' + k; });
        return h('label', { style: 'display:block;padding:3px 0' }, r, styleNames[k]);
      }));
      function labBtn(vid, label) {
        var el = h('button', { class: 'btn small no-print', style: 'font-size:22px', onclick: function () {
          var st = (document.querySelector('input[name=vstyle]:checked') || {}).value || Audio.vowelStyle, sy = V.syl(labLetter, vid);
          var pr = Audio.labSpeak(sy.key, sy.text, st); labOut.textContent = vid + ' | style=' + st + ' | spoken text=' + pr.text + ' | speed x' + pr.mul + ' | ' + pr.kind;
        } }, label);
        labBtns.push({ el: el, vid: vid }); return el;
      }
      var labCard = h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, '🎧 مُخْتَبَرُ النُّطْق: القَصِيرُ وَالطَّوِيل'),
        h('div', { class: 'sub' }, 'اخْتَارُوا الحَرْفَ ثُمَّ قَارِنُوا بَيْنَ الأَزْوَاج، وَاخْتَارُوا الأُسْلُوبَ الأَوْضَحَ لِهَاتِفِكُم.'),
        labSel, styleRow,
        h('div', { class: 'row-btns', style: 'margin-top:8px' },
          labBtn('fatha', 'بَ'), labBtn('longa', 'بَا'), labBtn('damma', 'بُ'), labBtn('longu', 'بُو'), labBtn('kasra', 'بِ'), labBtn('longi', 'بِي')), labOut);
      var last = new Date(P.lastPlayed); var ds = last.toLocaleDateString('ar') + ' ' + last.toLocaleTimeString('ar', { hour: '2-digit', minute: '2-digit' });
      var reset = h('button', { class: 'btn small no-print', onclick: function () { if (confirm('هل تريد حذف كل تقدّم الطفل؟ لا يمكن التراجع.')) { Progress.reset(); UI.updateStars(); Nav.go('parent', {}, { replace: true }); } } }, '🗑️ مَسْحُ التَّقَدُّم');
      box.append(title('مِنْطَقَةُ الأَهْلِ وَالمُعَلِّمِين', 'ملخّص تقدّم الطفل — آخر لعب: ' + ds),
        h('div', { class: 'card' }, h('div', { class: 'sub' }, 'التَّقَدُّمُ العَامّ'), h('div', { class: 'stat' }, h('b', null, overall + '%')), bar(overall)),
        h('div', { class: 'stat-strip' },
          h('div', { class: 'stat' }, h('b', null, P.lettersLearned.length + '/٢٨'), h('small', null, 'حُرُوفٌ تَعَلَّمَهَا')),
          h('div', { class: 'stat' }, h('b', null, P.vowelsDone.length + '/٣'), h('small', null, 'حَرَكَاتٌ مُكْتَمِلَة')),
          h('div', { class: 'stat' }, h('b', null, P.longsDone.length + '/٣'), h('small', null, 'مُدُودٌ مُكْتَمِلَة')),
          h('div', { class: 'stat' }, h('b', null, P.gamesTotal), h('small', null, 'أَلْعَابٌ لُعِبَت')),
          h('div', { class: 'stat' }, h('b', null, P.stars), h('small', null, 'مَجْمُوعُ النُّجُوم')),
          h('div', { class: 'stat' }, h('b', null, Progress.levelsDone() + '/' + LOLO.LEVELS.length), h('small', null, 'مَرَاحِلُ مُكْتَمِلَة'))),
        h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, 'الحُرُوفُ (الأَخْضَرُ = تَعَلَّمَهُ الطِّفْل)'), chips),
        h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, 'المَرَاحِل'), h('div', { class: 'p-table' }, levelRows)),
        voiceCard, labCard, diagCard,
        h('div', { class: 'card' }, h('div', { class: 'sub', style: 'margin-bottom:6px' }, 'الأَلْعَاب'), h('div', { class: 'p-table' }, gameRows)),
        h('div', { class: 'row-btns' }, h('button', { class: 'btn small no-print', onclick: function () { window.print(); } }, '🖨️ طِبَاعَة'), reset));
      Guide.say('هَذِهِ صَفْحَةٌ لِلأَهْلِ وَالمُعَلِّمِينَ لِمُتَابَعَةِ تَقَدُّمِ الطِّفْل.', { key: 'parent_intro', state: 'smile' });
    }, { theme: 'parent' });
  }

  /* ==========================================================
     BOOT
     ========================================================== */
  var TITLES = { splash: '', home: '', map: 'الخَرِيطَة', letters: 'مَمْلَكَةُ الحُرُوف', letter: 'دَرْسُ الحَرْف', vowels: 'مَمْلَكَةُ الحَرَكَات', vowel: 'دَرْسُ الحَرَكَات', longs: 'مَمْلَكَةُ المُدُود', long: 'دَرْسُ المَدّ', games: 'الأَلْعَاب', achievements: 'إِنْجَازَاتِي', parent: 'الأَهْلُ وَالمُعَلِّمُون' };

  function init() {
    Progress = LOLO.Progress; Audio = LOLO.Audio; Nav = LOLO.Nav; V = LOLO.V;
    LOLO.UI = UI; document.title = LOLO.CONFIG.pageTitle || document.title;
    Audio.init(Progress.get().settings);
    Nav.init($('#view'), $('#stage'));
    Guide.init(); registerScreens(); UI.updateStars();
    var tw = $('#twinkles'); for (var i = 0; i < 14; i++) { var s = h('i', { class: 'tw', style: 'left:' + Math.random() * 100 + '%;top:' + Math.random() * 55 + '%;animation-delay:' + Math.random() * 3 + 's' }); tw.appendChild(s); }

    Nav.on(function (name) {
      var t = TITLES[name]; $('#tbTitle').textContent = t || '';
      $('#btnBack').style.visibility = (name === 'home' || name === 'splash') ? 'hidden' : 'visible';
      $('#btnHome').style.visibility = name === 'splash' ? 'hidden' : 'visible';
      $('#soundPanel').classList.add('hidden');
      if (Audio.started) setTimeout(function () { Audio.sfx('whoosh'); }, 170);   // soft screen-transition sound
    });
    $('#btnBack').addEventListener('click', function () { Audio.sfx('click'); Nav.back(); });
    $('#btnHome').addEventListener('click', function () { Audio.sfx('click'); Nav.home(); });

    var S = Progress.get().settings, panel = $('#soundPanel'), vol = $('#volRange');
    vol.value = Math.round(S.volume * 100);
    function syncSound() { $('#btnSound').textContent = Audio.muted ? '🔇' : '🔊'; $('#btnMute').textContent = Audio.muted ? '🔈 تَشْغِيلُ الصَّوْت' : '🔇 كَتْمُ الصَّوْت'; $('#btnMusic').textContent = Audio.musicOn ? '🎵 المُوسِيقَى: تَعْمَل' : '🎵 المُوسِيقَى: مُتَوَقِّفَة'; }
    $('#btnSound').addEventListener('click', function () { Audio.sfx('click'); panel.classList.toggle('hidden'); syncSound(); });
    vol.addEventListener('input', function () { Audio.setVolume(vol.value / 100); });
    $('#btnMute').addEventListener('click', function () { Audio.setMuted(!Audio.muted); syncSound(); });
    $('#btnMusic').addEventListener('click', function () { Audio.setMusic(!Audio.musicOn); syncSound(); });
    $('#btnReplay').addEventListener('click', function () { Audio.replay(); });
    syncSound();
    Progress.on(function (t) { if (t === 'stars' || t === 'reset') UI.updateStars(); });
    Progress.checkBadges();
    Nav.go('splash');
  }
  document.addEventListener('DOMContentLoaded', init);
  window.LOLO = window.LOLO || {}; LOLO.UI = UI;
})();
