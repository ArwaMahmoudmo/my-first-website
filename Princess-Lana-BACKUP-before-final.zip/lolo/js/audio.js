/* ==========================================================
   js/audio.js — sound effects, music and Princess Lana's voice

   VOICE PRIORITY for every spoken line (key = e.g. letter_2, fatha_2):
     1) a real recording   assets/audio/voice/<key>.mp3   (if you add it)
     2) the device's Arabic text-to-speech (Web Speech API)
     3) silent — the text is always shown in the speech bubble

   Sound effects + music are real MP3 files (assets/audio/sfx, assets/music).
   If a file cannot load, a tiny Web-Audio synth plays instead.
   ========================================================== */
(function () {
  var SFX = ['click', 'pop', 'whoosh', 'step', 'correct', 'wrong', 'star', 'magic', 'unlock', 'flip', 'celebrate', 'levelup'];
  var A = {
    muted: false, volume: 0.85, musicOn: true,
    voiceFiles: {},        // key -> true/false (does a recording exist?)
    lastVoice: null, hasArabicVoice: null, started: false
  };
  var sfxAudio = {}, music = null, ctx = null, curFile = null, curToken = 0, ttsVoice = null, listeners = [];

  function emit(t, d) { listeners.forEach(function (f) { try { f(t, d); } catch (e) {} }); }
  A.on = function (f) { listeners.push(f); };

  /* ---------- init / unlock (must run from a user tap) ---------- */
  A.init = function (s) {
    if (s) { A.muted = !!s.muted; A.volume = s.volume; A.musicOn = s.music !== false; }
    SFX.forEach(function (n) {
      var a = new Audio('assets/audio/sfx/' + n + '.mp3'); a.preload = 'auto'; sfxAudio[n] = a;
    });
    music = new Audio('assets/music/lolo_theme.mp3'); music.loop = true; music.preload = 'auto';
    applyVolumes();
    if ('speechSynthesis' in window) {
      loadVoices();
      try { speechSynthesis.addEventListener('voiceschanged', loadVoices); } catch (e) { try { speechSynthesis.onvoiceschanged = loadVoices; } catch (e2) {} }
      pollVoices();
    } else { A.hasArabicVoice = false; emit('voices', false); }
  };
  A.unlock = function () {            // call on the first tap
    if (A.started) return; A.started = true;
    try { var AC = window.AudioContext || window.webkitAudioContext; if (AC) { ctx = new AC(); ctx.resume && ctx.resume(); } } catch (e) {}
    try {                                   // silent warm-up: gives Android Chrome the user-gesture it needs and makes it load its voice list
      speechSynthesis.cancel(); loadVoices();
      var w = new SpeechSynthesisUtterance(' '); w.volume = 0; w.lang = ttsVoice ? ttsVoice.lang : 'ar-SA'; if (ttsVoice) w.voice = ttsVoice;
      speechSynthesis.speak(w); pollVoices();
    } catch (e) {}
    A.startMusic();
    loadBuffers();
  };

  /* automatic choice of the most suitable (female, Arabic) device voice */
  var FEM = /zariyah|zariah|hoda|huda|salma|laila|leila|layla|amira|fatima|fatma|sara|sarah|nora|noura|maryam|mariam|zeina|zeinab|female|woman|أنثى|امرأة/i;
  var MALE = /naayf|nayef|hamed|hamid|maged|majed|tarik|tareq|shakir|shaker|zied|ziad|male\b|man\b|ذكر/i;
  function normLang(l) { return String(l || '').toLowerCase().replace(/_/g, '-'); }
  /* a voice is Arabic if its language code is ar / ar-SA / ar-EG / ar_XA / ara-..., OR its name/URI says Arabic.
     (The voice NAME is never needed - female names are only used afterwards to rank the Arabic voices.) */
  function isArabic(v) {
    return /^(ar|ara)($|-)/.test(normLang(v.lang)) || /arab|عرب/i.test(v.name || '') || /(^|[^a-z])ar[-_]/i.test(v.voiceURI || '');
  }
  A.isArabicVoice = isArabic;
  function pickVoice(ar) {
    var best = null, bs = -1e9;
    ar.forEach(function (v) {
      var sc = 0, l = normLang(v.lang);
      if (FEM.test(v.name) && !MALE.test(v.name)) sc += 10;
      if (MALE.test(v.name)) sc -= 10;
      if (/^ar-sa/.test(l)) sc += 3; else if (/^ar-eg/.test(l)) sc += 2; else if (/^ar($|-)/.test(l)) sc += 1;
      if (/google|natural|neural|enhanced|premium/i.test(v.name)) sc += 2;
      if (sc > bs) { bs = sc; best = v; }
    });
    return best;
  }
  /* Android Chrome often returns an empty list, or an incomplete one, at start-up and fills it later
     (voiceschanged fires late or not at all until the first speak). So: never conclude "no Arabic voice" from
     one early look - keep re-checking for ~12 s and after the first tap. */
  function loadVoices() {
    try {
      var vs = speechSynthesis.getVoices(); if (!vs || !vs.length) return;
      A.voiceCount = vs.length;
      var ar = vs.filter(isArabic);
      if (ar.length) {
        A.hasArabicVoice = true; ttsVoice = pickVoice(ar);
        A.voiceIsFemale = !!(ttsVoice && FEM.test(ttsVoice.name) && !MALE.test(ttsVoice.name));
        emit('voices', true);
      }
    } catch (e) {}
  }
  var vcEvents = 0;
  try { speechSynthesis.addEventListener('voiceschanged', function () { vcEvents++; }); } catch (e) {}
  /* everything the parent page needs to see why speech does or does not work */
  A.diagnose = function () {
    var d = { hasSS: 'speechSynthesis' in window, secure: !!window.isSecureContext, inFrame: false, activation: null, voices: [], voicesChangedEvents: vcEvents, ua: navigator.userAgent, online: navigator.onLine };
    try { d.inFrame = window.top !== window.self; } catch (e) { d.inFrame = true; }
    try { d.activation = navigator.userActivation ? { active: navigator.userActivation.isActive, hasBeenActive: navigator.userActivation.hasBeenActive } : null; } catch (e) {}
    try {
      if (d.hasSS) {
        d.speaking = speechSynthesis.speaking; d.pending = speechSynthesis.pending;
        d.voices = (speechSynthesis.getVoices() || []).map(function (v) { return { name: v.name, lang: v.lang, local: v.localService, def: v.default, arabic: isArabic(v), chosen: v === ttsVoice }; });
      }
    } catch (e) { d.error = String(e); }
    return d;
  };
  /* live test: speaks a short Arabic word and reports what the browser really did */
  A.testSpeak = function (lang, cb) {
    var r = { lang: lang, started: false, ended: false, error: null, ms: 0 };
    try {
      if (!('speechSynthesis' in window)) { r.error = 'no speechSynthesis'; return cb(r); }
      speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance('مَرْحَباً، أَنَا الأَمِيرَةُ لَانَا'); u.lang = lang; u.rate = 0.8; u.volume = Math.max(0.5, A.volume);
      if (lang === 'voice' && ttsVoice) { u.voice = ttsVoice; u.lang = ttsVoice.lang; r.lang = ttsVoice.name + ' / ' + ttsVoice.lang; }
      var t0 = Date.now(), fin = false;
      function end() { if (fin) return; fin = true; r.ms = Date.now() - t0; cb(r); }
      u.onstart = function () { r.started = true; };
      u.onend = function () { r.ended = true; end(); };
      u.onerror = function (e) { r.error = (e && e.error) || 'error'; end(); };
      setTimeout(function () { if (!fin) { if (!r.started) r.error = r.error || 'no start event after 4 s'; end(); } }, 4000);
      speechSynthesis.speak(u);
    } catch (e) { r.error = String(e); cb(r); }
  };
  A.testOnline = function (cb) {
    var r = { started: false, error: null };
    try {
      var a = new Audio(); var fin = false; function end() { if (fin) return; fin = true; try { a.pause(); } catch (e) {} cb(r); }
      a.onerror = function () { r.error = 'load/blocked'; end(); };
      a.src = ((LOLO.CONFIG && LOLO.CONFIG.onlineVoiceUrls) || ONLINE)[0] + encodeURIComponent('مرحبا');
      var p = a.play(); if (p && p.then) p.then(function () { r.started = true; setTimeout(end, 800); }).catch(function (e) { r.error = (e && e.name) || 'blocked'; end(); });
      setTimeout(end, 5000);
    } catch (e) { r.error = String(e); cb(r); }
  };
  var pollTimer = null;
  function pollVoices() {
    if (pollTimer || A.hasArabicVoice === true) return;
    var n = 0;
    pollTimer = setInterval(function () {
      loadVoices(); n++;
      if (A.hasArabicVoice === true) { clearInterval(pollTimer); pollTimer = null; }
      else if (n >= 24) { clearInterval(pollTimer); pollTimer = null; if (A.hasArabicVoice !== true) { A.hasArabicVoice = false; emit('voices', false); } }
    }, 500);
  }

  function applyVolumes() {
    var v = A.muted ? 0 : A.volume;
    if (music) music.volume = A.musicOn ? Math.min(1, v * (A._ducked ? 0.1 : 0.3)) : 0;
    if (curFile) curFile.volume = v;
  }
  A.setVolume = function (v) { A.volume = Math.max(0, Math.min(1, v)); applyVolumes(); LOLO.Progress.setSetting('volume', A.volume); };
  A.setMuted = function (m) { A.muted = !!m; applyVolumes(); if (m) A.stopVoice(); LOLO.Progress.setSetting('muted', A.muted); if (!m) A.startMusic(); };
  A.setMusic = function (on) { A.musicOn = !!on; applyVolumes(); LOLO.Progress.setSetting('music', A.musicOn); if (on) A.startMusic(); else if (music) music.pause(); };
  A.startMusic = function () {
    if (!music || !A.musicOn || A.muted || !A.started) return;
    applyVolumes(); var p = music.play(); if (p && p.catch) p.catch(function () {});
  };
  function duck(on) { A._ducked = on; applyVolumes(); }

  /* ---------- sound effects ----------
     Played through the Web Audio API (decoded once, instant, reliable on Android Chrome); falls back to
     <audio> elements and then to a tiny synth. Rules that stop sounds piling up:
       - the same sound never repeats within a short gap
       - "big" sounds (celebrate, levelup, unlock, magic) are queued one after the other (never layered),
         an identical big sound that is already queued/just played is dropped
       - small sounds (click, pop, star, correct...) are skipped while a big sound is playing */
  var GAIN = { click: .7, pop: .8, whoosh: .45, step: .6, correct: 1, wrong: .65, star: .9, magic: .9, unlock: 1, flip: .7, celebrate: 1, levelup: 1 };
  var GAP = { click: 70, pop: 70, whoosh: 250, step: 120, correct: 250, wrong: 250, star: 120, flip: 120 };
  var BIG = { celebrate: 1, levelup: 1, unlock: 1, magic: 1 };
  var buffers = {}, lastAt = {}, bigUntil = 0, decoding = false;
  function dataToBuf(u) {
    var i = u.indexOf(','), bin = atob(u.slice(i + 1)), ab = new ArrayBuffer(bin.length), v = new Uint8Array(ab);
    for (var k = 0; k < bin.length; k++) v[k] = bin.charCodeAt(k); return ab;
  }
  function loadBuffers() {
    if (decoding || !ctx) return; decoding = true;
    SFX.forEach(function (n) {
      var src = sfxAudio[n] && (sfxAudio[n].src || sfxAudio[n].currentSrc); if (!src) return;
      function dec(ab) { try { var pr = ctx.decodeAudioData(ab, function (b) { buffers[n] = b; }, function () {}); if (pr && pr.catch) pr.catch(function () {}); } catch (e) {} }
      try {
        if (src.indexOf('data:') === 0) dec(dataToBuf(src));
        else { var x = new XMLHttpRequest(); x.open('GET', src); x.responseType = 'arraybuffer'; x.onload = function () { if (x.status === 0 || x.status === 200) dec(x.response); }; x.send(); }
      } catch (e) {}
    });
  }
  A.sfxState = function () { return { ctx: ctx ? ctx.state : null, decoded: Object.keys(buffers).length, played: A._played || [] }; };
  function reallyPlay(name) {
    A._played = (A._played || []).concat(name).slice(-60);
    var g = (GAIN[name] || 1) * Math.min(1, A.volume);
    if (ctx && buffers[name]) {
      try {
        if (ctx.state === 'suspended' && ctx.resume) ctx.resume();
        var src = ctx.createBufferSource(), gn = ctx.createGain(); src.buffer = buffers[name]; gn.gain.value = g;
        src.connect(gn); gn.connect(ctx.destination); src.start(0);
        return;
      } catch (e) {}
    }
    var a = sfxAudio[name];
    if (!a) return synth(name);
    try {
      var c = a.cloneNode(); c.volume = Math.min(1, g);
      c.onerror = function () { synth(name); };
      var p = c.play(); if (p && p.catch) p.catch(function (e) { if (e && e.name !== 'NotAllowedError') synth(name); });
    } catch (e) { synth(name); }
  }
  A.sfx = function (name) {
    if (A.muted || !SFX.some(function (n) { return n === name; })) return;
    var now = Date.now(), dur = (buffers[name] ? buffers[name].duration * 1000 : 1500);
    if (BIG[name]) {
      if (lastAt[name] && now - lastAt[name] < 2500) return;          // identical big sound just played / queued -> drop
      var startAt = Math.max(now, bigUntil);
      if (startAt - now > 4500) return;                                // too far behind, drop
      lastAt[name] = now; bigUntil = startAt + dur + 120;
      if (startAt - now < 30) reallyPlay(name); else setTimeout(function () { if (!A.muted) reallyPlay(name); }, startAt - now);
      return;
    }
    if (now < bigUntil) return;                                        // a big sound is playing: skip small ones
    if (lastAt[name] && now - lastAt[name] < (GAP[name] || 100)) return;
    var PRIO = { correct: 1, wrong: 1, star: 1 };                      // reward/feedback sounds always win over UI sounds
    if (!PRIO[name] && now - (lastAt._small || 0) < 150) return;       // UI sounds never stack on top of each other
    lastAt._small = now; lastAt[name] = now; reallyPlay(name);
  };
  var SYN = { click: [900], pop: [700, 1000], correct: [523, 659, 784, 1047], wrong: [392, 330], star: [784, 1047, 1319], celebrate: [523, 659, 784, 1047, 1319], levelup: [523, 659, 784, 1047, 1319], magic: [660, 880, 1100], unlock: [659, 880, 1175], whoosh: [300], step: [220], flip: [900, 1300] };
  function synth(name) {
    if (!ctx || A.muted) return;
    var fs = SYN[name] || [700]; var t = ctx.currentTime;
    fs.forEach(function (f, i) {
      var o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + i * 0.1); g.gain.exponentialRampToValueAtTime(0.25 * A.volume, t + i * 0.1 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.1 + 0.4);
      o.connect(g); g.connect(ctx.destination); o.start(t + i * 0.1); o.stop(t + i * 0.1 + 0.45);
    });
  }

  /* ---------- short vs long vowel speech ----------
     Phone voices often read  بَ  and  بَا  with the same length. For the six syllable keys only
     (fatha_/damma_/kasra_ = SHORT, longa_/longu_/longi_ = LONG) the text and speaking speed are changed:
       plain   - nothing changed (old behaviour)
       rate    - short is spoken quickly, long slowly
       stretch - (default) short quickly; long slowly AND the madd letter is written twice (بَاا) so the voice holds the vowel
       extra   - long written with three madd letters, normal speed
     The best style depends on the phone's voice, so the parent area has a "pronunciation lab" to listen and choose. */
  var VSTYLES = { plain: 1, rate: 1, stretch: 1, extra: 1 };
  A.vowelStyle = 'stretch';
  try { var vs0 = localStorage.getItem('lolo.vowelStyle'); if (vs0 && VSTYLES[vs0]) A.vowelStyle = vs0; } catch (e) {}
  A.setVowelStyle = function (st) { if (!VSTYLES[st]) return; A.vowelStyle = st; try { localStorage.setItem('lolo.vowelStyle', st); } catch (e) {} };
  var curRate = 0.8;
  function vowelProfile(key, text, style) {
    var r = { text: text, mul: 1, kind: null }; style = style || A.vowelStyle;
    var m = /^(fatha|damma|kasra|longa|longu|longi)_/.exec(String(key || ''));
    if (!m || !text) return r;
    var isLong = m[1].indexOf('long') === 0; r.kind = isLong ? 'long' : 'short';
    if (style === 'plain') return r;
    var tail = String(text).slice(-1);
    if (style === 'rate') { r.mul = isLong ? 0.6 : 1.25; return r; }
    if (style === 'stretch') { r.mul = isLong ? 0.65 : 1.2; if (isLong) r.text = text + tail; return r; }
    if (style === 'extra') { if (isLong) r.text = text + tail + tail; return r; }
    return r;
  }
  A.vowelProfile = vowelProfile;
  /* pronunciation lab: speak one syllable with a chosen style (no game state involved) */
  A.labSpeak = function (key, text, style, cb) {
    var pr = vowelProfile(key, text, style);
    try {
      speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(pr.text); u.lang = ttsVoice ? ttsVoice.lang : 'ar-SA'; if (ttsVoice) u.voice = ttsVoice;
      u.rate = 0.8 * pr.mul; u.pitch = A.voiceIsFemale ? 1.05 : 1.25; u.volume = A.volume;
      u.onend = u.onerror = function () { cb && cb(pr); }; speechSynthesis.speak(u);
    } catch (e) { cb && cb(pr); }
    return pr;
  };

  /* ---------- voice ---------- */
  var pendingDone = null;
  A.stopVoice = function () {
    curToken++;
    var d = pendingDone; pendingDone = null;
    if (curFile) { try { curFile.pause(); } catch (e) {} curFile = null; }
    try { speechSynthesis.cancel(); } catch (e) {}
    duck(false);
    if (d) d();                      // resolves the interrupted line with false
  };

  /* say(key, text) -> Promise<boolean>: true = finished naturally, false = interrupted */
  A.say = function (key, text) {
    A.stopVoice();
    A.lastVoice = { key: key, text: text };
    var token = ++curToken;
    var vp = vowelProfile(key, text); text = vp.text; curRate = 0.8 * vp.mul;
    if (A.muted) return new Promise(function (r) { setTimeout(function () { r(token === curToken); }, Math.min(Math.max(900, String(text || '').length * 60), 2200)); });
    return new Promise(function (resolve) {
      var finished = false;
      function done() { if (finished) return; finished = true; var ok = token === curToken; if (ok) { duck(false); pendingDone = null; } resolve(ok); }
      pendingDone = done; duck(true);
      playFile(key, token, done).then(function (ok) {
        if (token !== curToken) { done(); return; }
        if (ok) return;
        runChain(text, token, done);
      });
    });
  };
  A.replay = function () { if (A.lastVoice) return A.say(A.lastVoice.key, A.lastVoice.text); return Promise.resolve(); };

  /* recorded files are listed in data/voice-manifest.js (made by recorder.html).
     Optionally the game can also probe  assets/audio/voice/<key>.mp3  (LOLO.VOICE_PROBE = true). */
  function voiceUrl(key) {
    var m = LOLO.VOICE_FILES || {};
    if (key && m[key]) return 'assets/audio/voice/' + m[key];
    if (key && LOLO.VOICE_PROBE === true) return 'assets/audio/voice/' + key + '.mp3';
    return null;
  }
  A.voiceStatus = function () {
    var total = LOLO.V ? LOLO.V.all().length : 0, rec = Object.keys(LOLO.VOICE_FILES || {}).length;
    return { recorded: rec, total: total, tts: A.hasArabicVoice, voiceName: ttsVoice ? ttsVoice.name : null, female: !!A.voiceIsFemale, online: (LOLO.CONFIG || {}).onlineVoice !== false, onlineWorked: !!A.onlineUsed, deviceWorked: !!A.deviceUsed, voiceCount: A.voiceCount || 0 };
  };
  function playFile(key, token, done) {
    var url = voiceUrl(key);
    if (!url || A.voiceFiles[key] === false) return Promise.resolve(false);
    return new Promise(function (res) {
      var a = new Audio(url); a.volume = A.volume;
      var settled = false;
      a.onerror = function () { A.voiceFiles[key] = false; if (!settled) { settled = true; res(false); } };
      a.onended = function () { done(); };
      var p = a.play();
      if (p && p.then) p.then(function () {
        if (token !== curToken) { a.pause(); settled = true; res(true); return; }
        A.voiceFiles[key] = true; curFile = a; settled = true; res(true);
      }).catch(function (e) {
        if (e && e.name === 'NotAllowedError') { settled = true; res(true); done(); return; }
        A.voiceFiles[key] = false; if (!settled) { settled = true; res(false); }
      });
      else { settled = true; res(false); }
    });
  }

  /* ---------- automatic voice chain ----------
     recorded file -> device Arabic voice -> online Arabic voice (2 addresses) -> device with language code only -> text bubble.
     A provider that fails is skipped silently; the next one is tried. Nothing is ever shown as an error. */
  function runChain(text, token, done) {
    var cfg = LOLO.CONFIG || {}, online = cfg.onlineVoice !== false;
    var est = Math.max(900, String(text || '').length * 85 + 500);
    var dev = function () { return speakDevice(text, token, done, true); };
    var devLoose = function () { return speakDevice(text, token, done, false); };
    var on0 = function () { return playOnline(text, token, done, 0); };
    var on1 = function () { return playOnline(text, token, done, 1); };
    var hasDev = 'speechSynthesis' in window && A.deviceOK !== false;
    var list;
    if (A.hasArabicVoice === true) list = [dev].concat(online ? [on0, on1] : []);
    else list = (online ? [on0, on1] : []).concat(hasDev ? [devLoose] : []);
    if (A.hasArabicVoice === true && cfg.onlineVoice === 'always' && !A.voiceIsFemale && online) list = [on0, on1, dev];
    if (A.hasArabicVoice === true && hasDev) list.push(devLoose);
    (function next(i) {
      if (token !== curToken) { done(); return; }
      if (i >= list.length) { setTimeout(done, Math.min(est, 2500)); return; }
      list[i]().then(function (ok) { if (!ok) next(i + 1); });
    })(0);
  }

  /* device voice. strict=true uses the detected Arabic voice; strict=false only sets lang ar-SA and lets the
     phone choose (works even when Chrome does not list its voices). Resolves true once speech has really started. */
  function speakDevice(text, token, done, strict) {
    return new Promise(function (res) {
      if (!text || !('speechSynthesis' in window)) return res(false);
      var u; try { u = new SpeechSynthesisUtterance(text); } catch (e) { return res(false); }
      u.lang = (strict && ttsVoice) ? ttsVoice.lang : (['ar-SA', 'ar', 'ar-EG', 'ar-XA'][(A.deviceFails || 0) % 4]); if (strict && ttsVoice) u.voice = ttsVoice;
      u.rate = curRate; u.pitch = A.voiceIsFemale ? 1.05 : 1.25; u.volume = A.volume;
      var est = Math.max(900, String(text).length * 85 + 500), t0 = Date.now(), started = false, settled = false, endT = null;
      function fin(ok) { if (settled) return; settled = true; clearTimeout(guard); res(ok); }
      function fail() { A.deviceFails = (A.deviceFails || 0) + 1; if (A.deviceFails >= 3) A.deviceOK = false; try { speechSynthesis.cancel(); } catch (e) {} fin(false); }
      var guard = setTimeout(fail, 3500);                       // speech never started -> try the next provider
      u.onstart = function () { started = true; if (A.hasArabicVoice !== true) { A.hasArabicVoice = true; emit('voices', true); } A.deviceFails = 0; A.deviceUsed = true; endT = setTimeout(done, est + 6000); fin(true); };
      u.onend = function () { clearTimeout(endT); if (started) done(); else if (Date.now() - t0 > 250) { fin(true); done(); } else fail(); };
      u.onerror = function () { clearTimeout(endT); if (started) done(); else fail(); };
      setTimeout(function () { if (token === curToken) { try { speechSynthesis.speak(u); } catch (e) { fail(); } } else fin(false); }, 40);
    });
  }

  /* online Arabic voice: plain <audio> element, so it works on any normal website (Netlify, GitHub Pages...).
     NOT inside Claude's preview frame, which blocks every outside address. Needs internet.
     Addresses can be changed in data/config.js (onlineVoiceUrls). Long lines are split into <=180-character pieces. */
  var ONLINE = ['https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ar&q=',
                'https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=ar&q='];
  function chunkText(t) {
    var out = [], parts = String(t).replace(/\u200d|\u200c/g, '').split(/[.!؟?،,]\s+/);
    var cur = '';
    parts.forEach(function (p) { if ((cur + ' ' + p).trim().length > 180) { if (cur) out.push(cur); cur = p; } else cur = (cur + ' ' + p).trim(); });
    if (cur) out.push(cur);
    return out.length ? out : [String(t)];
  }
  function playOnline(text, token, done, idx) {
    var bases = (LOLO.CONFIG && LOLO.CONFIG.onlineVoiceUrls) || ONLINE;
    if (!text || !bases[idx] || A['onlineBad' + idx] >= 3 || navigator.onLine === false) return Promise.resolve(false);
    var chunks = chunkText(text);
    return new Promise(function (res) {
      var settled = false, k = 0, a = null;
      function fin(ok) { if (!settled) { settled = true; res(ok); } }
      function bad() { A['onlineBad' + idx] = (A['onlineBad' + idx] || 0) + 1; if (!settled) fin(false); else done(); }
      function playChunk() {
        if (token !== curToken) { fin(true); done(); return; }
        a = new Audio(); a.volume = A.volume; a.preload = 'auto';
        var started = false, guard = setTimeout(function () { if (!started) { try { a.pause(); } catch (e) {} bad(); } }, 7000);
        a.onerror = function () { clearTimeout(guard); bad(); };
        a.onended = function () { k++; if (k < chunks.length) playChunk(); else done(); };
        a.src = bases[idx] + encodeURIComponent(chunks[k]);
        var p = a.play();
        if (p && p.then) p.then(function () {
          started = true; clearTimeout(guard); A['onlineBad' + idx] = 0; A.onlineUsed = true; curFile = a; fin(true);
          if (token !== curToken) { try { a.pause(); } catch (e) {} }
        }).catch(function (e) { clearTimeout(guard); if (e && e.name === 'NotAllowedError') { fin(true); done(); } else bad(); });
      }
      playChunk();
    });
  }

  window.LOLO = window.LOLO || {};
  LOLO.Audio = A;
})();
