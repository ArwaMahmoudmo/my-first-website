/* ==========================================================
   js/navigation.js — tiny screen router (works from file:// too)
   Nav.register('name', function(container, params){ ... return cleanupFn })
   Nav.go('name', params)   Nav.back()   Nav.home()
   Nav.token changes on every navigation: async flows compare it to
   know the screen they belong to has gone.
   ========================================================== */
(function () {
  var Nav = { screens: {}, stack: [], current: null, token: 0, viewEl: null, stageEl: null, listeners: [] };
  var cleanup = null;

  Nav.init = function (viewEl, stageEl) { Nav.viewEl = viewEl; Nav.stageEl = stageEl; };
  Nav.register = function (name, fn, opts) { Nav.screens[name] = { fn: fn, theme: (opts && opts.theme) || 'home' }; };
  Nav.on = function (fn) { Nav.listeners.push(fn); };
  Nav.alive = function () { var t = Nav.token; return function () { return Nav.token === t; }; };

  Nav.go = function (name, params, opts) {
    opts = opts || {};
    var s = Nav.screens[name]; if (!s) { console.warn('unknown screen', name); return; }
    if (cleanup) { try { cleanup(); } catch (e) {} cleanup = null; }
    LOLO.Audio.stopVoice();
    Nav.token++;
    if (!opts.replace && Nav.current) Nav.stack.push(Nav.current);
    Nav.current = { name: name, params: params || {} };
    Nav.stageEl.setAttribute('data-theme', opts.theme || s.theme);

    var old = Nav.viewEl.querySelector('.screen');
    var el = document.createElement('div'); el.className = 'screen enter'; el.setAttribute('data-screen', name);
    if (old) { old.classList.add('leave'); setTimeout(function () { if (old.parentNode) old.parentNode.removeChild(old); }, 260); }
    Nav.viewEl.appendChild(el);
    Nav.viewEl.scrollTop = 0;
    Nav.listeners.forEach(function (f) { f(name, Nav.current.params); });   // (screens may then override the title)
    try { cleanup = s.fn(el, Nav.current.params) || null; } catch (e) { console.error('screen error', name, e); }
    requestAnimationFrame(function () { el.classList.remove('enter'); });
  };
  Nav.back = function () {
    var prev = Nav.stack.pop();
    if (!prev) return Nav.go('home', {}, { replace: true });
    Nav.go(prev.name, prev.params, { replace: true });
  };
  Nav.home = function () { Nav.stack = []; Nav.go('home', {}, { replace: true }); };

  window.LOLO = window.LOLO || {};
  LOLO.Nav = Nav;
})();
