/* ==========================================================
   js/games.js — the 8 educational games + question generators
   Public: LOLO.Games.run(gameId, box, opts)
           LOLO.Games.quiz(box, opts)          (level quizzes)
   Rules for every game: never punish; wrong answer -> kind phrase +
   hint, same question again; stars are only ever added.
   ========================================================== */
(function () {
  var G = {};
  function U() { return LOLO.UI; }
  function h() { return LOLO.UI.h.apply(null, arguments); }
  var V = function () { return LOLO.V; };

  /* ---------- small helpers ---------- */
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function delay(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function allLetters() { return LOLO.LETTERS; }
  function ids(list) { return list.map(function (l) { return l.id; }); }
  function poolLetters(pool) { return (pool && pool.length ? pool : ids(allLetters())).map(LOLO.byId); }

  /* wrong answers: one look-alike letter (tricky but fair) + random others */
  function distractors(target, pool, n) {
    var out = [], all = allLetters();
    var group = LOLO.SIMILAR.filter(function (g) { return g.indexOf(target.id) >= 0; })[0] || [];
    var sim = shuffle(group.filter(function (i) { return i !== target.id; }).map(LOLO.byId));
    var near = poolLetters(pool).filter(function (l) { return l.id !== target.id; });
    if (sim.length && Math.random() < 0.6) out.push(sim[0]);
    shuffle(near).concat(shuffle(all)).forEach(function (l) {
      if (out.length < n && l.id !== target.id && out.indexOf(l) < 0) out.push(l);
    });
    return out.slice(0, n);
  }
  function glyph(t) { return h('span', { class: 'glyph' }, t); }
  function sayObj(o) { return { text: o.text, key: o.key }; }

  /* ==========================================================
     QUESTION GENERATORS  ->  q = { prompt, say, sound, media, speaker, opts[], hint }
     ========================================================== */
  var Q = {};
  Q.find = function (pool) {
    var l = pick(poolLetters(pool)), v = V();
    var opts = shuffle([l].concat(distractors(l, pool, 2))).map(function (x) { return { node: function () { return glyph(x.ch); }, correct: x === l }; });
    var a = v.askFind(l);
    return { prompt: a.text, say: a, opts: opts, hint: { text: v.hintLetter(l).text, say: v.hintLetter(l), img: l.img, emoji: l.emoji }, letter: l };
  };
  Q.listen = function (pool) {
    var l = pick(poolLetters(pool)), v = V();
    var opts = shuffle([l].concat(distractors(l, pool, 2))).map(function (x) { return { node: function () { return glyph(x.ch); }, correct: x === l }; });
    return { prompt: 'مَاذَا سَمِعْتُم؟', say: v.fixed.listen, sound: v.name(l), speaker: true, opts: opts,
      hint: { text: v.fixed.listenHint.text, say: v.fixed.listenHint, img: l.img, emoji: l.emoji }, letter: l };
  };
  Q.harakat = function (pool, o) {
    var l = pick(poolLetters(pool)), v = V();
    var vow = (o && o.vowel) || pick(['fatha', 'damma', 'kasra']);
    var opts = shuffle(['fatha', 'damma', 'kasra']).map(function (x) { return { node: function () { return glyph(LOLO.syllable(l, x)); }, correct: x === vow }; });
    var vd = LOLO.VOWELS.filter(function (z) { return z.id === vow; })[0];
    return { prompt: 'أَيُّهَا سَمِعْتُم؟', say: v.fixed.harakat, sound: v.syl(l, vow), speaker: true, opts: opts,
      hint: { text: vd.tip, say: v.vowelTip(vd) }, letter: l };
  };
  Q.word = function (pool) {
    var l = pick(poolLetters(pool)), v = V();
    var opts = shuffle([l].concat(distractors(l, pool, 2))).map(function (x) { return { node: function () { return glyph(x.ch); }, correct: x === l }; });
    var shaped = LOLO.shapeChunks(l);
    return { prompt: 'أَكْمِلِ الكَلِمَة', say: v.fixed.word, media: { emoji: l.emoji, img: l.img }, boxes: shaped, opts: opts, letter: l,
      hint: { text: 'الكَلِمَةُ هِيَ: ' + l.word, say: v.word(l) }, after: v.word(l) };
  };
  Q.concept = function () {
    var i = Math.floor(Math.random() * LOLO.CONCEPT_QUESTIONS.length), c = LOLO.CONCEPT_QUESTIONS[i], v = V();
    var opts = shuffle(c.opts.map(function (t, k) { return { text: t, correct: k === c.a }; }));
    return { prompt: c.q, say: v.concept(i), textOpts: true, opts: opts, hint: { text: c.hint, say: v.conceptHint(i) } };
  };
  Q.long = function (pool, o) {
    var l = pick(poolLetters(pool)), v = V();
    var lt = (o && o.long) ? LOLO.LONGS.filter(function (z) { return z.id === o.long; })[0] : pick(LOLO.LONGS);
    var isLong = Math.random() < 0.6;
    var shortId = lt.short, longId = lt.id;
    var other = pick(LOLO.LONGS.filter(function (z) { return z.id !== lt.id; }));
    var heard = isLong ? longId : shortId;
    var kinds = shuffle([shortId, longId, other.id]);
    var opts = kinds.map(function (k) { return { node: function () { return glyph(LOLO.syllable(l, k)); }, correct: k === heard }; });
    return { prompt: 'مَاذَا سَمِعْتُم؟', say: v.fixed.long, sound: v.syl(l, heard), speaker: true, opts: opts,
      hint: { text: v.fixed.longHint.text, say: v.fixed.longHint }, letter: l };
  };
  Q.mixed = function (pool, i) {
    var order = ['find', 'listen', 'harakat', 'word', 'concept', 'long', 'find', 'listen', 'harakat', 'word', 'long', 'concept'];
    return Q[order[i % order.length]](pool);
  };
  G.Q = Q;

  /* ==========================================================
     GENERIC "CHOOSE THE ANSWER" ENGINE
     cfg: { gameId, rounds, gen(i), scene, embedded, onDone(res), pool }
     ========================================================== */
  function runChoice(box, cfg) {
    var u = U(), alive = LOLO.Nav.alive(), A = LOLO.Audio;
    var i = 0, stars = 0, mistakes = 0, attempts = 0, locked = false, q = null;
    box.innerHTML = '';
    var bar = h('i'); var prog = h('div', { class: 'progress-bar' }, bar);
    var path = cfg.scene === 'find' ? makePath(cfg.rounds) : null;
    var card = h('div', { class: 'card q-card' });
    var opts = h('div', { class: 'opts' });
    var hintBox = h('div');
    box.appendChild(prog); if (path) box.appendChild(path.el);
    box.appendChild(card); box.appendChild(opts); box.appendChild(hintBox);

    function setBar() { bar.style.width = Math.round(i / cfg.rounds * 100) + '%'; }
    function playSound() { if (q && q.sound) return A.say(q.sound.key, q.sound.text); return A.replay(); }

    function render() {
      if (!alive()) return;
      q = cfg.gen(i); attempts = 0; locked = false; setBar();
      card.innerHTML = ''; opts.innerHTML = ''; hintBox.innerHTML = '';
      opts.className = 'opts' + (q.textOpts ? ' text-opts' : '');
      card.appendChild(h('p', { class: 'q-prompt' + (q.textOpts ? ' arabic-text' : '') }, q.prompt));
      if (q.media) card.appendChild(q.media.img ? h('div', { class: 'q-media' }, h('img', { src: q.media.img, alt: '' })) : h('div', { class: 'q-media' }, q.media.emoji));
      if (q.boxes) {
        var wb = h('div', { class: 'word-boxes' });
        q.boxes.forEach(function (t, k) { wb.appendChild(h('span', { class: 'wb' + (k === 0 ? ' blank' : ''), 'data-k': k }, t)); });
        card.appendChild(wb); q.wb = wb;
      }
      if (q.speaker) {
        var sp = h('button', { class: 'speaker', 'aria-label': 'استمع', onclick: function () { A.sfx('pop'); playSound(); } }, '🔊');
        card.appendChild(sp);
      }
      q.opts.forEach(function (o) {
        var b = o.textOpts || q.textOpts ? h('button', { class: 'opt text' }, o.text) : h('button', { class: 'opt' }, o.node());
        b.addEventListener('click', function () { choose(o, b); });
        opts.appendChild(b); o.btn = b;
      });
      if (path) path.set(i);
      // speak the question
      var s = q.say;
      u.Guide.say(s.text, { key: s.key, state: q.sound ? 'think' : (cfg.scene === 'find' ? 'walk' : 'smile') }).then(function (ok) {
        if (ok && alive() && q.sound && attempts === 0 && !locked) return A.say(q.sound.key, q.sound.text);
      });
    }

    function choose(o, btn) {
      if (locked) return;
      if (o.correct) {
        locked = true; btn.classList.add('right');
        A.sfx('correct'); u.FX.burstAt(btn, ['⭐', '✨', '🌸', '💖']); u.awardStar(btn); stars++;
        var retry = attempts > 0;
        var finishOne = function () {
          var p = u.Guide.phrase(retry ? 'retryok' : 'correct', { state: retry ? 'smile' : (Math.random() < .5 ? 'clap' : 'jump') });
          if (q.wb) {                              // complete-the-word: fill the blank & say the word
            var b0 = q.wb.querySelector('.blank'); b0.classList.remove('blank'); b0.classList.add('filled'); b0.textContent = q.boxes[0];
            p = p.then(function () { return alive() ? A.say(q.after.key, q.after.text) : null; });
          }
          return p;
        };
        var done = Promise.race([Promise.all([finishOne(), delay(1300)]), delay(5200)]);
        if (path) path.step();
        i++; setBar();
        done.then(function () { if (alive()) { if (i >= cfg.rounds) finish(); else render(); } });
      } else {
        mistakes++; attempts++; btn.classList.add('nope'); A.sfx('wrong');
        u.Guide.phrase('wrong', { state: 'encourage' }).then(function () {
          if (!alive() || locked) return;
          if (q.hint) {
            hintBox.innerHTML = '';
            var hb = h('div', { class: 'hint' }, q.hint.text, q.hint.img ? h('img', { src: q.hint.img, alt: '', style: 'height:52px;vertical-align:middle;margin:0 8px' }) : (q.hint.emoji ? '  ' + q.hint.emoji : ''));
            hintBox.appendChild(hb);
            return u.Guide.say(q.hint.text, { key: q.hint.say && q.hint.say.key, state: 'think' });
          }
        });
        if (attempts >= 2) q.opts.forEach(function (x) { if (x.correct) x.btn.classList.add('glow'); });
      }
    }

    function finish() {
      var res = { stars: stars, perfect: mistakes === 0, mistakes: mistakes, rounds: cfg.rounds };
      if (cfg.embedded) { cfg.onDone && cfg.onDone(res); return; }
      showResult(box, cfg, res);
    }
    render();
  }

  function makePath(n) {
    var el = h('div', { class: 'path' }, h('div', { class: 'road' }));
    var walker = h('div', { class: 'walker' });
    var stones = [];
    for (var k = 0; k <= n; k++) {
      var s = h('div', { class: 'stone' }, k === n ? '🏰' : ''); s.style.right = (4 + k / n * 88) + '%'; el.appendChild(s); stones.push(s);
    }
    el.appendChild(walker);
    var cur = 0;
    function place(k) { walker.style.right = (4 + k / n * 88) + '%'; }
    place(0);
    return {
      el: el,
      set: function (k) { cur = k; place(k); },
      step: function () { stones[cur].classList.add('done'); LOLO.Audio.sfx('whoosh'); place(cur + 1); }
    };
  }

  /* ---------- result screen shared by all games ---------- */
  function showResult(box, cfg, res) {
    var u = U(), badges = LOLO.Progress.gamePlayed(cfg.gameId, res.perfect);
    box.innerHTML = '';
    var total = Math.min(res.rounds, 10), shown = Math.min(res.stars, total);
    var row = h('div', { class: 'stars-row' });
    for (var k = 0; k < total; k++) { var im = h('img', { src: 'assets/images/star.svg', alt: '' }); im.style.animationDelay = (k * 0.12) + 's'; if (k >= shown) im.className = 'empty'; row.appendChild(im); }
    var again = h('button', { class: 'btn primary', onclick: function () { LOLO.Audio.sfx('click'); G.run(cfg.gameId, box, cfg.origOpts || {}); } }, '🔁 العب مرة أخرى');
    var hub = h('button', { class: 'btn purple', onclick: function () { LOLO.Audio.sfx('click'); LOLO.Nav.go('games'); } }, '🎮 الألعاب');
    box.appendChild(h('div', { class: 'card result' },
      h('img', { class: 'crown', src: 'assets/images/crown.svg', alt: '' }),
      h('h2', { class: 'title' }, 'أَحْسَنْتُم يَا أَبْطَال!'),
      row,
      h('p', { class: 'sub' }, 'جَمَعْتُمْ ' + res.stars + ' نَجْمَة' + (res.perfect ? ' — بِلَا أَخْطَاء! 💯' : '')),
      h('div', { class: 'row-btns' }, again, hub)));
    LOLO.Audio.sfx('celebrate'); u.FX.confetti();
    u.Guide.phrase('levelDone', { state: 'celebrate' });
    u.announceBadges(badges);
  }

  /* ==========================================================
     GAME 5 — MATCH LETTERS WITH PICTURES
     ========================================================== */
  function runMatch(box, cfg) {
    var u = U(), alive = LOLO.Nav.alive(), A = LOLO.Audio, round = 0, stars = 0, mistakes = 0;
    function startRound() {
      if (!alive()) return;
      box.innerHTML = '';
      var set = shuffle(poolLetters(cfg.pool)).slice(0, 4), sel = null, matched = 0;
      var prog = h('div', { class: 'progress-bar' }, h('i')); prog.firstChild.style.width = Math.round(round / cfg.rounds * 100) + '%';
      var rowL = h('div', { class: 'match-row' }), rowP = h('div', { class: 'match-row' });
      var cardL = {}, cardP = {};
      shuffle(set).forEach(function (l) { var c = h('button', { class: 'm-card' }, glyph(l.ch)); cardL[l.id] = c; c.addEventListener('click', function () { if (c.classList.contains('locked')) return; A.sfx('pop'); Object.keys(cardL).forEach(function (k) { cardL[k].classList.remove('sel'); }); c.classList.add('sel'); sel = l; A.say(V().name(l).key, V().name(l).text); }); rowL.appendChild(c); });
      shuffle(set).forEach(function (l) {
        var c = h('button', { class: 'm-card' }, l.img ? h('img', { src: l.img, alt: '', style: 'width:78%;height:78%;object-fit:contain' }) : l.emoji); cardP[l.id] = c;
        c.addEventListener('click', function () {
          if (c.classList.contains('locked')) return;
          if (!sel) { u.Guide.say(V().fixed.matchFirst.text, { key: V().fixed.matchFirst.key, state: 'think' }); return; }
          if (sel.id === l.id) {
            cardL[l.id].classList.remove('sel'); cardL[l.id].classList.add('locked'); c.classList.add('locked');
            A.sfx('correct'); u.FX.burstAt(c, ['⭐', '✨', '💖']); u.awardStar(c); stars++; matched++; sel = null;
            u.Guide.say(l.word, { key: V().word(l).key, state: 'clap' }).then(function () {
              if (alive() && matched === set.length) { round++; if (round >= cfg.rounds) finish(); else startRound(); }
            });
          } else {
            mistakes++; c.classList.add('nope'); setTimeout(function () { c.classList.remove('nope'); }, 500); A.sfx('wrong');
            u.Guide.say(V().fixed.matchHint.text, { key: V().fixed.matchHint.key, state: 'encourage' });
          }
        });
        rowP.appendChild(c);
      });
      box.append(prog,
        h('div', { class: 'card q-card' }, h('p', { class: 'q-prompt' }, 'صِلِ الحَرْفَ بِصُورَتِهِ'), h('div', { class: 'match-label' }, 'الحُرُوف'), rowL, h('div', { class: 'match-label', style: 'margin-top:12px' }, 'الصُّوَر'), rowP));
      u.Guide.say(V().fixed.matchFirst.text, { key: V().fixed.matchFirst.key, state: 'smile' });
    }
    function finish() { var res = { stars: stars, perfect: mistakes === 0, mistakes: mistakes, rounds: cfg.rounds * 4 }; if (cfg.embedded) cfg.onDone(res); else showResult(box, cfg, res); }
    startRound();
  }

  /* ==========================================================
     GAME 6 — LETTER HUNT IN THE MAGIC GARDEN
     ========================================================== */
  var PET = [['#ff7eb6', '#ffb3d6'], ['#8f7bff', '#c1b6ff'], ['#ffb23e', '#ffd88a'], ['#4ac7b8', '#9ae8dd'], ['#ff6d6d', '#ffa5a5']];
  function runHunt(box, cfg) {
    var u = U(), alive = LOLO.Nav.alive(), A = LOLO.Audio, round = 0, stars = 0, mistakes = 0;
    function startRound() {
      if (!alive()) return;
      box.innerHTML = '';
      var t = pick(poolLetters(cfg.pool)), need = 3, found = 0;
      var cells = [];
      for (var k = 0; k < need; k++) cells.push({ l: t, ok: true });
      var others = shuffle(distractors(t, null, 6).concat(shuffle(allLetters().filter(function (x) { return x.id !== t.id; }))));
      var seen = 0; others.forEach(function (x) { if (seen < 9) { cells.push({ l: x, ok: false }); seen++; } });
      cells = shuffle(cells);
      var prog = h('div', { class: 'progress-bar' }, h('i')); prog.firstChild.style.width = Math.round(round / cfg.rounds * 100) + '%';
      var counter = h('div', { class: 'sub' }, '🌸 وَجَدْنَا: 0 / ' + need);
      var garden = h('div', { class: 'garden' });
      cells.forEach(function (c, n) {
        var col = pick(PET);
        var f = h('button', { class: 'flower' }, glyph(c.l.ch));
        f.style.setProperty('--c1', col[0]); f.style.setProperty('--c2', col[1]); f.style.setProperty('--d', (n * 0.17) + 's');
        f.addEventListener('click', function () {
          if (f.classList.contains('found')) return;
          if (c.ok) {
            f.classList.add('found'); found++; stars++; A.sfx('correct'); u.FX.burstAt(f, ['🌸', '✨', '🦋']); u.awardStar(f);
            counter.textContent = '🌸 وَجَدْنَا: ' + found + ' / ' + need;
            if (found === need) {
              u.Guide.phrase('correct', { state: 'jump' }).then(function () { if (alive()) { round++; if (round >= cfg.rounds) finish(); else startRound(); } });
            } else u.Guide.phrase('correct', { state: 'clap' });
          } else {
            mistakes++; f.classList.remove('wig'); void f.offsetWidth; f.classList.add('wig'); A.sfx('wrong');
            var nt = V().notThis(c.l); u.Guide.say(nt.text, { key: nt.key, state: 'encourage' });
          }
        });
        garden.appendChild(f);
      });
      box.append(prog, h('div', { class: 'card q-card' }, h('p', { class: 'q-prompt' }, 'ابْحَثُوا عَنْ حَرْفِ  «' + t.ch + '»'), counter), garden);
      var hs = V().hunt(t); u.Guide.say(hs.text, { key: hs.key, state: 'walk' });
    }
    function finish() { var res = { stars: stars, perfect: mistakes === 0, mistakes: mistakes, rounds: cfg.rounds * 3 }; if (cfg.embedded) cfg.onDone(res); else showResult(box, cfg, res); }
    startRound();
  }

  /* ==========================================================
     GAME 8 — LISTEN AND REPEAT (microphone is optional)
     ========================================================== */
  function normAr(s) { return String(s || '').replace(/[ً-ٰٟـ]/g, '').replace(/[إأآ]/g, 'ا').replace(/ى/g, 'ي').replace(/\s+/g, '').toLowerCase(); }
  function runRepeat(box, cfg) {
    var u = U(), alive = LOLO.Nav.alive(), A = LOLO.Audio, v = V();
    var items = [], pool = poolLetters(cfg.pool);
    shuffle(pool).slice(0, 2).forEach(function (l) { items.push({ show: l.ch, snd: v.name(l), expect: [l.name, l.ch] }); });
    shuffle(pool).slice(0, 2).forEach(function (l) { var k = pick(['fatha', 'damma', 'kasra']); items.push({ show: LOLO.syllable(l, k), snd: v.syl(l, k), expect: [LOLO.syllable(l, k)] }); });
    shuffle(pool).slice(0, 2).forEach(function (l) { var k = pick(['longa', 'longu', 'longi']); items.push({ show: LOLO.syllable(l, k), snd: v.syl(l, k), expect: [LOLO.syllable(l, k)] }); });
    items = items.slice(0, cfg.rounds); var i = 0, stars = 0;
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;

    function show() {
      if (!alive()) return;
      var it = items[i]; box.innerHTML = '';
      var prog = h('div', { class: 'progress-bar' }, h('i')); prog.firstChild.style.width = Math.round(i / items.length * 100) + '%';
      var fb = h('div', { class: 'sub' }, 'اسْتَمِعْ ثُمَّ كَرِّرْ بِصَوْتٍ عَالٍ');
      var listen = h('button', { class: 'speaker', 'aria-label': 'استمع', onclick: function () { A.sfx('pop'); A.say(it.snd.key, it.snd.text); } }, '🔊');
      var done = h('button', { class: 'btn mint', onclick: function () { complete(true); } }, '✅ قُلْتُهَا!');
      var btns = h('div', { class: 'row-btns' }, done);
      if (SR) {
        var mic = h('button', { class: 'btn mic-btn' }, '🎤 كَرِّرْ'); mic.addEventListener('click', function () { listenMic(mic, fb, it); });
        btns.insertBefore(mic, done);
      }
      box.append(prog, h('div', { class: 'card q-card repeat-card' }, h('div', { class: 'glyph' }, it.show), listen, fb), btns,
        h('p', { class: 'sub' }, SR ? 'الميكروفون اختياريّ — يمكنكم الضغط على «قلتها» في أي وقت.' : 'قُولُوا الصَّوْتَ بِصَوْتٍ عَالٍ ثُمَّ اضْغَطُوا «قُلْتُهَا».'));
      var intro = v.say ? LOLO.V.say('sayTogether', 0) : null;
      u.Guide.say(intro.text, { key: intro.key, state: 'smile' }).then(function (ok) { if (ok && alive()) return A.say(it.snd.key, it.snd.text); });
    }
    function listenMic(mic, fb, it) {
      try {
        var r = new SR(); r.lang = 'ar-SA'; r.interimResults = false; r.maxAlternatives = 3;
        mic.classList.add('rec'); fb.textContent = '🎤 أَسْمَعُكُم...';
        r.onresult = function (e) {
          mic.classList.remove('rec');
          var heard = ''; for (var k = 0; k < e.results[0].length; k++) heard += ' ' + e.results[0][k].transcript;
          var h2 = normAr(heard), ok = it.expect.some(function (x) { var n = normAr(x); return n && h2.indexOf(n) >= 0; });
          fb.textContent = ok ? '🌟 نُطْقٌ رَائِع!' : 'نُطْقٌ جَمِيل! اسْتَمِعْ مَرَّةً أُخْرَى وَجَرِّبْ.';
          if (ok) complete(false); else u.Guide.phrase('encourage', { state: 'encourage' });
        };
        r.onerror = function () { mic.classList.remove('rec'); fb.textContent = 'الميكروفون غير متاح الآن — اضغط «قلتها»'; };
        r.onend = function () { mic.classList.remove('rec'); };
        r.start();
      } catch (e) { fb.textContent = 'الميكروفون غير متاح — اضغط «قلتها»'; }
    }
    function complete() {
      A.sfx('correct'); u.awardStar(box.querySelector('.card')); u.FX.burstAt(box.querySelector('.card'), ['⭐', '🎶', '✨']); stars++;
      u.Guide.phrase('repeatOk', { state: 'clap' }).then(function () {
        if (!alive()) return; i++;
        if (i >= items.length) { var res = { stars: stars, perfect: true, mistakes: 0, rounds: items.length }; if (cfg.embedded) cfg.onDone(res); else showResult(box, cfg, res); } else show();
      });
    }
    show();
  }

  /* ==========================================================
     Public API
     ========================================================== */
  var R = function () { return LOLO.ROUNDS; };
  G.run = function (id, box, opts) {
    opts = opts || {};
    var cfg = { gameId: id, embedded: !!opts.embedded, onDone: opts.onDone, pool: opts.pool, origOpts: opts, rounds: opts.rounds || R()[id] || 6 };
    var g = LOLO.GAMES.filter(function (x) { return x.id === id; })[0];
    box.innerHTML = '';
    switch (id) {
      case 'find':      cfg.scene = 'find'; cfg.gen = function () { return Q.find(cfg.pool); }; return runChoice(box, cfg);
      case 'listen':    cfg.gen = function () { return Q.listen(cfg.pool); }; return runChoice(box, cfg);
      case 'harakat':   cfg.gen = function () { return Q.harakat(cfg.pool); }; return runChoice(box, cfg);
      case 'word':      cfg.gen = function () { return Q.word(cfg.pool); }; return runChoice(box, cfg);
      case 'challenge': { var order = shuffle(['find', 'listen', 'harakat', 'word', 'concept', 'long', 'find', 'listen', 'harakat', 'word', 'long', 'concept']);
                          cfg.gen = function (i) { return Q[order[i % order.length]](cfg.pool); }; return runChoice(box, cfg); }
      case 'match':     return runMatch(box, cfg);
      case 'hunt':      return runHunt(box, cfg);
      case 'repeat':    return runRepeat(box, cfg);
    }
  };
  /* level quiz: custom generator list */
  G.quiz = function (box, o) {
    var cfg = { gameId: 'levelquiz', embedded: true, onDone: o.onDone, pool: o.pool, rounds: o.rounds || R().levelQuiz };
    cfg.gen = function (i) {
      var kinds = o.kinds || ['find', 'listen', 'harakat', 'word'];
      var k = kinds[i % kinds.length];
      return Q[k](o.pool, o);
    };
    return runChoice(box, cfg);
  };
  LOLO.Games = G;
})();
