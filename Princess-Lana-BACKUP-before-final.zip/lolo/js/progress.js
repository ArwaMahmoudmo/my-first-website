/* ==========================================================
   js/progress.js — saves the child's progress in the browser
   (localStorage). Nothing is ever sent anywhere.
   Stars are only ever added, never removed.
   ========================================================== */
(function () {
  var KEY = 'lolo.progress.v1';
  var listeners = [];

  function fresh() {
    return {
      v: 1, stars: 0,
      lettersLearned: [], vowelsDone: [], longsDone: [],
      levels: {},            // { L1: {done:true, stars:5} }
      gamesPlayed: {},       // { find: 3 }
      gamesTotal: 0, perfectGames: 0,
      badges: [], created: Date.now(), lastPlayed: Date.now(),
      settings: { volume: 0.85, music: true, muted: false }
    };
  }
  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) { var o = JSON.parse(raw); var d = fresh(); for (var k in d) if (o[k] === undefined) o[k] = d[k]; return o; }
    } catch (e) { /* private mode etc. */ }
    return fresh();
  }
  var P = load();
  function save() { try { P.lastPlayed = Date.now(); localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) {} }
  function emit(type, data) { listeners.forEach(function (fn) { try { fn(type, data); } catch (e) {} }); }
  function addUnique(arr, v) { if (arr.indexOf(v) < 0) { arr.push(v); return true; } return false; }

  var Progress = {
    get: function () { return P; },
    on: function (fn) { listeners.push(fn); },
    addStars: function (n) { P.stars += Math.max(0, n | 0); save(); emit('stars', P.stars); return this.checkBadges(); },
    learnLetter: function (id) { if (addUnique(P.lettersLearned, id)) { save(); emit('letter', id); return this.checkBadges(); } return []; },
    doneVowel: function (id) { if (addUnique(P.vowelsDone, id)) { save(); emit('vowel', id); return this.checkBadges(); } return []; },
    doneLong: function (id) { if (addUnique(P.longsDone, id)) { save(); emit('long', id); return this.checkBadges(); } return []; },
    gamePlayed: function (id, perfect) {
      P.gamesPlayed[id] = (P.gamesPlayed[id] || 0) + 1; P.gamesTotal++;
      if (perfect) P.perfectGames++;
      save(); emit('game', id); return this.checkBadges();
    },
    completeLevel: function (id, stars) {
      var old = P.levels[id] || { done: false, stars: 0 };
      P.levels[id] = { done: true, stars: Math.max(old.stars, stars | 0) };
      save(); emit('level', id); return this.checkBadges();
    },
    isLevelDone: function (id) { return !!(P.levels[id] && P.levels[id].done); },
    isLevelUnlocked: function (index) {
      if (index === 0) return true;
      return this.isLevelDone(LOLO.LEVELS[index - 1].id);
    },
    nextLevelIndex: function () {
      for (var i = 0; i < LOLO.LEVELS.length; i++) if (!this.isLevelDone(LOLO.LEVELS[i].id)) return i;
      return LOLO.LEVELS.length - 1;
    },
    levelsDone: function () { return LOLO.LEVELS.filter(function (l) { return Progress.isLevelDone(l.id); }).length; },
    checkBadges: function () {
      var fresh = [];
      LOLO.BADGES.forEach(function (b) {
        if (P.badges.indexOf(b.id) < 0 && b.test(P)) { P.badges.push(b.id); fresh.push(b); }
      });
      if (fresh.length) { save(); emit('badges', fresh); }
      return fresh;
    },
    setSetting: function (k, v) { P.settings[k] = v; save(); },
    reset: function () { P = fresh(); save(); emit('reset'); }
  };
  window.LOLO = window.LOLO || {};
  LOLO.Progress = Progress;
})();
